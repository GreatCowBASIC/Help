#include "mainwindow.h"
#include "ui_mainwindow.h"

#include <QMessageBox>
#include <QFileDialog>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    this->setWindowFlags(windowFlags() &~ (Qt::WindowMinMaxButtonsHint));

    QRegExp regx("[1-9][0-9]+$");

    QValidator *validator1 = new QRegExpValidator(regx, ui->lineEdit_XSIZE );
    ui->lineEdit_XSIZE->setValidator(validator1);
    QValidator *validator2 = new QRegExpValidator(regx, ui->lineEdit_HSPW );
    ui->lineEdit_HSPW->setValidator(validator2);
    QValidator *validator3 = new QRegExpValidator(regx, ui->lineEdit_HSBP );
    ui->lineEdit_HSBP->setValidator(validator3);
    QValidator *validator4 = new QRegExpValidator(regx, ui->lineEdit_HSFP );
    ui->lineEdit_HSFP->setValidator(validator4);

    QValidator *validator5 = new QRegExpValidator(regx, ui->lineEdit_YSIZE );
    ui->lineEdit_YSIZE->setValidator(validator5);
    QValidator *validator6 = new QRegExpValidator(regx, ui->lineEdit_VSPW );
    ui->lineEdit_VSPW->setValidator(validator6);
    QValidator *validator7 = new QRegExpValidator(regx, ui->lineEdit_VSBP );
    ui->lineEdit_VSBP->setValidator(validator7);
    QValidator *validator8 = new QRegExpValidator(regx, ui->lineEdit_VSFP );
    ui->lineEdit_VSFP->setValidator(validator8);

    QValidator *validator9 = new QRegExpValidator(regx, ui->lineEdit_FlashAddr );
    ui->lineEdit_FlashAddr->setValidator(validator9);
    QValidator *validator10 = new QRegExpValidator(regx, ui->lineEdit_PageSize );
    ui->lineEdit_PageSize->setValidator(validator10);

    QValidator *validator11 = new QRegExpValidator(regx, ui->lineEdit_CCLKOD );
    ui->lineEdit_CCLKOD->setValidator(validator11);
    QValidator *validator12 = new QRegExpValidator(regx, ui->lineEdit_CCLKR );
    ui->lineEdit_CCLKR->setValidator(validator12);
    QValidator *validator13 = new QRegExpValidator(regx, ui->lineEdit_CCLK );
    ui->lineEdit_CCLK->setValidator(validator13);

    QValidator *validator14 = new QRegExpValidator(regx, ui->lineEdit_MCLKOD );
    ui->lineEdit_MCLKOD->setValidator(validator14);
    QValidator *validator15 = new QRegExpValidator(regx, ui->lineEdit_MCLKR );
    ui->lineEdit_MCLKR->setValidator(validator15);
    QValidator *validator16 = new QRegExpValidator(regx, ui->lineEdit_MCLK );
    ui->lineEdit_MCLK->setValidator(validator16);

    QValidator *validator17 = new QRegExpValidator(regx, ui->lineEdit_SCLKOD );
    ui->lineEdit_SCLKOD->setValidator(validator17);
    QValidator *validator18 = new QRegExpValidator(regx, ui->lineEdit_SCLKR );
    ui->lineEdit_SCLKR->setValidator(validator18);
    QValidator *validator19 = new QRegExpValidator(regx, ui->lineEdit_SCLK );
    ui->lineEdit_SCLK->setValidator(validator19);

    QValidator *validator20 = new QRegExpValidator(regx, ui->lineEdit_PPre );
    ui->lineEdit_PPre->setValidator(validator20);
    QValidator *validator21 = new QRegExpValidator(regx, ui->lineEdit_PWMT );
    ui->lineEdit_PWMT->setValidator(validator21);
    QValidator *validator22 = new QRegExpValidator(regx, ui->lineEdit_PWM );
    ui->lineEdit_PWM->setValidator(validator22);

    ui->comboBox_LCDIF->clear();
    ui->comboBox_LCDIF->addItem("16bitsTFT");
    ui->comboBox_LCDIF->addItem("18bitsTFT");
    ui->comboBox_LCDIF->addItem("24bitsTFT");
    ui->comboBox_LCDIF->setCurrentIndex(0);

    ui->comboBox_LCDRGB->clear();
    ui->comboBox_LCDRGB->addItem("RGB");
    ui->comboBox_LCDRGB->addItem("RBG");
    ui->comboBox_LCDRGB->addItem("GRB");
    ui->comboBox_LCDRGB->addItem("GBR");
    ui->comboBox_LCDRGB->addItem("BRG");
    ui->comboBox_LCDRGB->addItem("BGR");
    ui->comboBox_LCDRGB->setCurrentIndex(0);

    ui->comboBox_ColorIF->clear();
    ui->comboBox_ColorIF->addItem("8bpp");
    ui->comboBox_ColorIF->addItem("16bpp");
    ui->comboBox_ColorIF->addItem("24bpp");
    ui->comboBox_ColorIF->setCurrentIndex(1);

    ui->comboBox_SPIReadCmd->clear();
    ui->comboBox_SPIReadCmd->addItem("03h");
    ui->comboBox_SPIReadCmd->addItem("0Bh");
    ui->comboBox_SPIReadCmd->addItem("1Bh");
    ui->comboBox_SPIReadCmd->addItem("3Bh");
    ui->comboBox_SPIReadCmd->addItem("BBh");
    ui->comboBox_SPIReadCmd->setCurrentIndex(0);

    ui->comboBox_FlashAddrMode->clear();
    ui->comboBox_FlashAddrMode->addItem("24bits");
    ui->comboBox_FlashAddrMode->addItem("32bits");
    ui->comboBox_FlashAddrMode->setCurrentIndex(0);

    ui->comboBox_CANVASMODE->clear();
    ui->comboBox_CANVASMODE->addItem("Linear-8bits");
    ui->comboBox_CANVASMODE->addItem("Linear-16bits");
    ui->comboBox_CANVASMODE->addItem("Block-8bpp");
    ui->comboBox_CANVASMODE->addItem("Block-16bpp");
    ui->comboBox_CANVASMODE->addItem("Block-24bpp");
    ui->comboBox_CANVASMODE->setCurrentIndex(3);

    ui->comboBox_Speed->clear();
    ui->comboBox_Speed->addItem("DIV 2");
    ui->comboBox_Speed->addItem("DIV 4");
    ui->comboBox_Speed->addItem("DIV 6");
    ui->comboBox_Speed->addItem("DIV 8");
    ui->comboBox_Speed->addItem("DIV 10");
    ui->comboBox_Speed->addItem("DIV 12");
    ui->comboBox_Speed->addItem("DIV 14");
    ui->comboBox_Speed->addItem("DIV 16");
    ui->comboBox_Speed->setCurrentIndex(1);

    ui->comboBox_SPI->clear();
    ui->comboBox_SPI->addItem("SPI0");
    ui->comboBox_SPI->addItem("SPI1");
    ui->comboBox_SPI->setCurrentIndex(1);


}

MainWindow::~MainWindow()
{
    delete ui;
}


void MainWindow::on_pushButton_2_clicked()
{
    this->close();
}

void MainWindow::Get_Setting_From_GUI(void)
{
    QString tStr;

    LCD_XSIZE_TFT = ui->lineEdit_XSIZE->text().toInt();
    LCD_YSIZE_TFT = ui->lineEdit_YSIZE->text().toInt();
    LCD_VBPD = ui->lineEdit_VSBP->text().toInt();
    LCD_VFPD = ui->lineEdit_VSFP->text().toInt();
    LCD_VSPW = ui->lineEdit_VSPW->text().toInt();
    LCD_HBPD = ui->lineEdit_HSBP->text().toInt();
    LCD_HFPD = ui->lineEdit_HSFP->text().toInt();
    LCD_HSPW = ui->lineEdit_HSPW->text().toInt();

    switch(ui->comboBox_LCDIF->currentIndex()) //01h -- bit4:3
    {
        case 0: LCD_IF_Format = 2; break;
        case 1: LCD_IF_Format = 1; break;
        case 2: LCD_IF_Format = 0; break;
        default: LCD_IF_Format = 0; break;
    }

    switch(ui->comboBox_LCDRGB->currentIndex())//12h -- bit2:0
    {
        case 0: LCD_RGB_Format= 0; break;
        case 1: LCD_RGB_Format= 1; break;
        case 2: LCD_RGB_Format= 2; break;
        case 3: LCD_RGB_Format= 3; break;
        case 4: LCD_RGB_Format= 4; break;
        case 5: LCD_RGB_Format= 5; break;
        case 6: LCD_RGB_Format= 6; break;
        default: LCD_RGB_Format= 0; break;
    }

    switch(ui->comboBox_ColorIF->currentIndex())//10h -- bit3:2
    {
        case 0: LCD_Color_Format = 0; break;
        case 1: LCD_Color_Format = 1; break;
        case 2: LCD_Color_Format = 2; break;
        default: LCD_Color_Format = 1; break;
    }

    //5Eh -- bit2:  0- Block mode, 1- Linear mode
    //5Eh -- bit1:0  00b- 8bpp,01b- 16bpp, 1xb- 24bpp
    //5Eh -- bit1:0  x0b- 8bits内存数据读写，x1b- 16bits内存数据读写
    switch(ui->comboBox_CANVASMODE->currentIndex())
    {
        case 0: LCD_Linear_Mode = 0x04;	break;
        case 1: LCD_Linear_Mode = 0x05;	break;
        case 2: LCD_Linear_Mode = 0x00;	break;
        case 3: LCD_Linear_Mode = 0x01;	break;
        case 4: LCD_Linear_Mode = 0x02;	break;
        default: LCD_Linear_Mode= 0x02;	break;
    }

    if(ui->checkBox_PCLK->isChecked()==true)
        PCLK_P = 1;  //下降元
    else	PCLK_P = 0;

    if(ui->checkBox_HSYNC->isChecked()==true)
        HSYNC_P = 1;
    else  HSYNC_P = 0;

    if(ui->checkBox_VSYNC->isChecked()==true)
        VSYNC_P = 1;
    else 	VSYNC_P = 0;

    if(ui->checkBox_DEP->isChecked()==true)
        DE_P = 1;
    else  DE_P = 0;

    if(ui->checkBox_DEM->isChecked()==true)
            DE_MODE_SELECT = 1;
    else  DE_MODE_SELECT = 0;

    switch(ui->comboBox_FlashAddrMode->currentIndex())//B7h -- bit5
    {
        case 0: SPI_Addr_Mode= 0; break;
        case 1: SPI_Addr_Mode= 1; break;
        default: SPI_Addr_Mode= 0;break;
    }

    switch(ui->comboBox_SPI->currentIndex())
    {
        case 0: SPI_IF_ID = 0; break;
        case 1: SPI_IF_ID = 1; break;
        default: SPI_IF_ID = 0; break;
    }

    switch(ui->comboBox_SPIReadCmd->currentIndex())
    {
        case 0: SPI_Read_Cmd = 0x00; break;
        case 1: SPI_Read_Cmd = 0x04; break;
        case 2: SPI_Read_Cmd = 0x08; break;
        case 3: SPI_Read_Cmd = 0x02; break;
        case 4: SPI_Read_Cmd = 0x03; break;
        default: SPI_Read_Cmd = 0x00; break;
    }

    SPI_Logo_Addr = ui->lineEdit_FlashAddr->text().toInt();

    SPI_Page_Size = 256;
    /*switch(ui->comboBox_PageSize->currentIndex())
    {
        case 0: SPI_Page_Size = 256; break;
        case 1: SPI_Page_Size = 512; break;
        case 2: SPI_Page_Size = 2048; break;
        default: SPI_Page_Size = 256; break;
    }*/

    //------------------------------------
    CCLK = ui->lineEdit_CCLK->text().toInt();
    //if(CCLK>100) CCLK = 100;

    CCLKOD = ui->lineEdit_CCLKOD->text().toInt();
    if(CCLKOD>3) CCLKOD = 3;

    CCLKR = ui->lineEdit_CCLKR->text().toInt();
    if(CCLKR>31) CCLKR = 31;
    if(CCLKR<2)  CCLKR = 2;

    //-------------------------------------
    MCLK = ui->lineEdit_MCLK->text().toInt();
    //if(MCLK>133) MCLK = 133;

    MCLKOD = ui->lineEdit_MCLKOD->text().toInt();
    if(MCLKOD>3) MCLKOD = 3;

    MCLKR = ui->lineEdit_MCLKR->text().toInt();
    if(MCLKR>31) MCLKR = 31;
    if(MCLKR<2)  MCLKR = 2;

    //-------------------------------------
    SCLK = ui->lineEdit_SCLK->text().toInt();
    //if(SCLK>80) SCLK = 80;

    SCLKOD = ui->lineEdit_SCLKOD->text().toInt();
    if(SCLKOD>3) SCLKOD = 3;

    SCLKR = ui->lineEdit_SCLKR->text().toInt();
    if(SCLKR>31) SCLKR = 31;
    if(SCLKR<2)  SCLKR = 2;

      //For PWM1 -----------------------------------------------
    PwmPre = ui->lineEdit_PPre->text().toInt();
    if(PwmPre>255) PwmPre = 255;

    PwmTime = ui->lineEdit_PWMT->text().toInt();
    if(PwmTime>65535) PwmTime = 65535;

    PwmVal = ui->lineEdit_PWM->text().toInt();
    if(PwmVal>PwmTime) PwmVal = PwmTime;

    ui->lineEdit_PPre->setText(IntToStr(PwmPre));
    ui->lineEdit_PWMT->setText(IntToStr(PwmTime));
    ui->lineEdit_PWM->setText(IntToStr(PwmVal));

}

void MainWindow::LT768_PLL_Initial(int tCCLK, int tMCLK)
{
    int temp, temp1;
    unsigned short lpllOD_sclk, lpllOD_cclk, lpllOD_mclk;
    unsigned short lpllR_sclk, lpllR_cclk, lpllR_mclk;
    unsigned short lpllN_sclk, lpllN_cclk, lpllN_mclk;

    QString tStr;

    /*
    temp = (LCD_HBPD + LCD_HFPD + LCD_HSPW + LCD_XSIZE_TFT) * (LCD_VBPD + LCD_VFPD + LCD_VSPW+LCD_YSIZE_TFT) * 60;
    temp1 = (temp%1000000)/100000;
    if(temp1>5)
         temp = temp / 1000000 + 1;
    else temp = temp / 1000000;


    SCLK = temp;
       */
//	tStr = EditCCLK->Text;
//	CCLK = StrToInt(tStr);
//	if(CCLK>100) CCLK = 100;
//
//	tStr = EditMCLK->Text;
//	MCLK = StrToInt(tStr);
//	if(MCLK>133) MCLK = 133;

//	if(SCLK > 80)	SCLK = 80;

    lpllOD_sclk = SCLKOD;
    lpllOD_cclk = CCLKOD;
    lpllOD_mclk = MCLKOD;
    lpllR_sclk  = SCLKR;
    lpllR_cclk  = CCLKR;
    lpllR_mclk  = MCLKR;
    lpllN_mclk  = MCLK;
    lpllN_cclk  = CCLK;
    lpllN_sclk  = SCLK;

    ui->lineEdit_CCLK->setText(IntToStr(CCLK));
    ui->lineEdit_CCLKOD->setText(IntToStr(CCLKOD));
    ui->lineEdit_CCLKR->setText(IntToStr(CCLKR));

    ui->lineEdit_MCLK->setText(IntToStr(MCLK));
    ui->lineEdit_MCLKOD->setText(IntToStr(MCLKOD));
    ui->lineEdit_MCLKR->setText(IntToStr(MCLKR));

    ui->lineEdit_SCLKOD->setText(IntToStr(SCLKOD));
    ui->lineEdit_SCLKR->setText(IntToStr(SCLKR));

    //LCD_CmdWrite(0x05);
    //LCD_DataWrite((lpllOD_sclk<<6) | (lpllR_sclk<<1) | ((lpllN_sclk>>8)&0x1));
    LT768_WriteReg(0x05,(lpllOD_sclk<<6) | (lpllR_sclk<<1) | ((lpllN_sclk>>8)&0x1));

    //LCD_CmdWrite(0x06);
    //LCD_DataWrite(lpllN_sclk);
    LT768_WriteReg(0x06,lpllN_sclk);

    //LCD_CmdWrite(0x07);
    //LCD_DataWrite((lpllOD_mclk<<6) | (lpllR_mclk<<1) | ((lpllN_mclk>>8)&0x1));
    LT768_WriteReg(0x07,(lpllOD_mclk<<6) | (lpllR_mclk<<1) | ((lpllN_mclk>>8)&0x1));

    //LCD_CmdWrite(0x08);
    //LCD_DataWrite(lpllN_mclk);
    LT768_WriteReg(0x08,lpllN_mclk);

    //LCD_CmdWrite(0x09);
    //LCD_DataWrite((lpllOD_cclk<<6) | (lpllR_cclk<<1) | ((lpllN_cclk>>8)&0x1));
    LT768_WriteReg(0x09,(lpllOD_cclk<<6) | (lpllR_cclk<<1) | ((lpllN_cclk>>8)&0x1));

    //LCD_CmdWrite(0x0a);
    //LCD_DataWrite(lpllN_cclk);
    LT768_WriteReg(0x0A,lpllN_cclk);

    //LCD_CmdWrite(0x00);
    //LCD_DataWrite(0x80);
    LT768_WriteReg(0x00,0x80);
}
//---------------------------------------------------------------------------
void MainWindow::Set_LCD_Panel(void)
{
    unsigned char u8Tmp;

    //LCD_Color_Format,DE_MODE_SELECT
    LT768_WriteReg(0x10,(LCD_Color_Format<<2)|DE_MODE_SELECT);	//10h -- bit3:2 , bit0

    //PCLK_Falling();	       	//REG[12h]:下降沿
    //VSCAN_T_to_B();	        //REG[12h]:从上到下
    //PDATA_Set_RGB();        //REG[12h]:Select RGB output
    //LCD_RGB_Format
    //PCLK_P
    if(PCLK_P==1)
        u8Tmp = (0x80 | LCD_RGB_Format);
    else  u8Tmp = (0x00 | LCD_RGB_Format); 	//PCLK上升沿捕捉数据
    LT768_WriteReg(0x12, u8Tmp);	//12h

    reg12H_Val = u8Tmp;

    //HSYNC_Low_Active();     //REG[13h]:
    //VSYNC_Low_Active();     //REG[13h]:
    //DE_High_Active();       //REG[13h]:
    //HSYNC_P,VSYNC_P,DE_P
    u8Tmp = 0x00;
    if(HSYNC_P==1) u8Tmp |= 0x80;
    if(VSYNC_P==1) u8Tmp |= 0x40;
    if(DE_P == 1)  u8Tmp |= 0x20;
    LT768_WriteReg(0x13, u8Tmp);	//13h

    //LCD_HorizontalWidth_VerticalHeight(LCD_XSIZE_TFT ,LCD_YSIZE_TFT);
    u8Tmp=(LCD_XSIZE_TFT/8)-1;
    LT768_WriteReg(0x14, u8Tmp);	//14h

    u8Tmp=LCD_XSIZE_TFT%8;
    LT768_WriteReg(0x15, u8Tmp);	//15h

    u8Tmp=(LCD_YSIZE_TFT-1)&0xFF;
    LT768_WriteReg(0x1A, u8Tmp);	//1Ah

    u8Tmp=((LCD_YSIZE_TFT-1)>>8)&0xFF;
    LT768_WriteReg(0x1B, u8Tmp);	//1Bh

    //LCD_Horizontal_Non_Display(LCD_HBPD);
    if(LCD_HBPD<8)
    {
        LT768_WriteReg(0x16, 0x00);		//16h
        LT768_WriteReg(0x17, LCD_HBPD);	//17h
    }
    else
    {
        u8Tmp=(LCD_HBPD/8)-1;
        LT768_WriteReg(0x16, u8Tmp);		//16h
        u8Tmp=LCD_HBPD%8;
        LT768_WriteReg(0x17, u8Tmp);		//17h
    }

    //LCD_HSYNC_Start_Position(LCD_HFPD);
    if(LCD_HFPD<8)
    {
        LT768_WriteReg(0x18, 0x00);		//18h
    }
    else
    {
        u8Tmp = (LCD_HFPD/8)-1;
        LT768_WriteReg(0x18, u8Tmp);		//18h
    }

    //LCD_HSYNC_Pulse_Width(LCD_HSPW);
    if(LCD_HSPW<8)
    {
        LT768_WriteReg(0x19, 0x00);		//19h
    }
    else
    {
        u8Tmp =(LCD_HSPW/8)-1;
        LT768_WriteReg(0x19, u8Tmp);		//19h
    }

    //LCD_Vertical_Non_Display(LCD_VBPD);
      u8Tmp = (LCD_VBPD - 1)&0xFF;
    LT768_WriteReg(0x1C, u8Tmp);			//1Ch
    u8Tmp = ((LCD_VBPD - 1)>>8)&0xFF;
    LT768_WriteReg(0x1D, u8Tmp);			//1Dh

    //LCD_VSYNC_Start_Position(LCD_VFPD);
      u8Tmp = LCD_VFPD-1;
    LT768_WriteReg(0x1E, u8Tmp);			//1Eh

    //LCD_VSYNC_Pulse_Width(LCD_VSPW);
    u8Tmp = LCD_VSPW - 1;
    LT768_WriteReg(0x1F, u8Tmp);			//1Fh
}

void MainWindow::Update_Logo_Bin_Buf(void)
{
    unsigned char u8T;
    int tpageAddr,sdram_itv;

    pos=0;
    // Addr: 'h0000
    //61 72 77 63 77 62 78 67 // ID
    logo_bin_buf[pos++] = 0x61;
    logo_bin_buf[pos++] = 0x72;
    logo_bin_buf[pos++] = 0x77;
    logo_bin_buf[pos++] = 0x63;
    logo_bin_buf[pos++] = 0x77;
    logo_bin_buf[pos++] = 0x62;
    logo_bin_buf[pos++] = 0x78;
    logo_bin_buf[pos++] = 0x67;

    //初始化 PLL
    //11 05 13 8A // REG_WR（'h05, 'h8A）向寄存器 REG[05] 写入 0x8A
    //11 06 13 41 // REG_WR（'h06, 'h41）
    //11 07 13 8A // REG_WR（'h07, 'h8A）
    //11 08 13 64 // REG_WR（'h08, 'h64)
    //11 09 13 8A // REG_WR（'h09, 'h8A）
    //11 0A 13 64 // REG_WR（'h0A, 'h64）
    //11 00 13 80 // REG_WR（'h00, 'h80）
    //if(CCLK>80)
    //    LT768_PLL_Initial(80,100);
    //else  LT768_PLL_Initial(CCLK,MCLK);

    LT768_PLL_Initial(CCLK,MCLK);

    LT768_Wait_AA(4);	//old = 100

    //11 01 13 82 // REG_WR（'h01, 'h82）
    LT768_WriteReg(0x01,0x82 | (LCD_IF_Format<<3));

    //11 01 12 82 // REG_WR（'h01, 'h82）
    LT768_ReaddReg(0x01,0x82 | (LCD_IF_Format<<3));

    //11 02 13 40 // REG_WR（'h02, 'h40）
    LT768_WriteReg(0x02,0x40);

    //AA AA AA AA // 空挃令
    LT768_Wait_AA(4);
    //---------------------------------------------------------------------
      //初始化显示内存
    //11 E0 13 29 // REG_WR（'hE0, 'h29）
      LT768_WriteReg(0xE0,0x29);

    //11 E1 13 03 // REG_WR（'hE1, 'h03）
    LT768_WriteReg(0xE1,0x03);

    sdram_itv  = (64000000 / 8192) / (1000/MCLK) ;
    sdram_itv -=2;

    //11 E2 13 0B // REG_WR（'hE2, 'h0B）
    LT768_WriteReg(0xE2,sdram_itv);

    //11 E3 13 03 // REG_WR（'hE3, 'h03）
      LT768_WriteReg(0xE3,sdram_itv >>8);

    //11 E4 13 01 // REG_WR（'hE4, 'h01）
      LT768_WriteReg(0xE4,0x01);

    //AA AA AA AA // 空挃令
    LT768_Wait_AA(10);
    //---------------------------------------------------------------------
      //设置 LCD 屏
    //11 10 13 04 // REG_WR（'h10, 'h04）
    //11 12 13 85 // REG_WR（'h12, 'h85）
    //11 13 13 03 // REG_WR（'h13, 'h03）
    //11 14 13 7F // REG_WR（'h14, 'h7F）
    //11 15 13 00 // REG_WR（'h15, 'h00）
    //11 1A 13 FF // REG_WR（'h1A, 'hFF）
    //11 1B 13 02 // REG_WR（'h1B, 'h02）
    Set_LCD_Panel();
    //---------------------------------------------------------------------
    //SPI速度设置

    switch(ui->comboBox_Speed->currentIndex())
    {
        case 0: LT768_WriteReg(0xBB,0x00); break;	//DIV 2
        case 1: LT768_WriteReg(0xBB,0x01); break;	//DIV 4
        case 2: LT768_WriteReg(0xBB,0x02); break;	//DIV 6
        case 3: LT768_WriteReg(0xBB,0x03); break;	//DIV 8
        case 4: LT768_WriteReg(0xBB,0x04); break;	//DIV 10
        case 5: LT768_WriteReg(0xBB,0x05); break;	//DIV 12
        case 6: LT768_WriteReg(0xBB,0x06); break;	//DIV 14
        case 7: LT768_WriteReg(0xBB,0x07); break;	//DIV 16
        default: LT768_WriteReg(0xBB,0x01); break;
    }


    //---------------------------------------------------------------------
    //设置主窗口
    //11 20 13 00 // REG_WR（'h20, 'h00）
    //11 21 13 00 // REG_WR（'h21, 'h00）
    LT768_WriteReg(0x20,0x00);
    LT768_WriteReg(0x21,0x00);

    //11 22 13 00 // REG_WR（'h22, 'h00）
    //11 23 13 00 // REG_WR（'h23, 'h00）
    LT768_WriteReg(0x22,0x00);
    LT768_WriteReg(0x23,0x00);

    //11 24 13 00 // REG_WR（'h24, 'h00）
    //11 25 13 04 // REG_WR（'h25, 'h04）
    LT768_WriteReg(0x24,LCD_XSIZE_TFT&0xFF);
    LT768_WriteReg(0x25,(LCD_XSIZE_TFT>>8)&0xFF);

    //11 26 13 00 // REG_WR（'h26, 'h00）
    //11 27 13 00 // REG_WR（'h27, 'h00）
    LT768_WriteReg(0x26,0x00);
    LT768_WriteReg(0x27,0x00);

    //11 28 13 00 // REG_WR（'h28, 'h00）
    //11 29 13 00 // REG_WR（'h29, 'h00）
    LT768_WriteReg(0x28,0x00);
    LT768_WriteReg(0x29,0x00);

    //AA AA AA AA // 空挃令
    LT768_Wait_AA(4);

    //---------------------------------------------------------------------
    //设置底图
    //11 50 13 00 // REG_WR（'h50, 'h00）
    //11 51 13 00 // REG_WR（'h51, 'h00）
    LT768_WriteReg(0x50,0x00);
    LT768_WriteReg(0x51,0x00);

    //11 52 13 00 // REG_WR（'h52, 'h00）
    //11 53 13 00 // REG_WR（'h53, 'h00）
    LT768_WriteReg(0x52,0x00);
    LT768_WriteReg(0x53,0x00);

    //11 54 13 00 // REG_WR（'h54, 'h00）
    //11 55 13 04 // REG_WR（'h55, 'h04）
    LT768_WriteReg(0x54,LCD_XSIZE_TFT&0xFF);
    LT768_WriteReg(0x55,(LCD_XSIZE_TFT>>8)&0xFF);

    //---------------------------------------------------------------------
    //设置活劢窗口
    //11 56 13 00 // REG_WR（'h56, 'h00）
    //11 57 13 00 // REG_WR（'h57, 'h00）
    LT768_WriteReg(0x56,0x00);
    LT768_WriteReg(0x57,0x00);
    //11 58 13 00 // REG_WR（'h58, 'h00）
    //11 59 13 00 // REG_WR（'h59, 'h00）
    LT768_WriteReg(0x58,0x00);
    LT768_WriteReg(0x59,0x00);

    //11 5A 13 00 // REG_WR（'h5A, 'h00）
    //11 5B 13 04 // REG_WR（'h5B, 'h04）
    LT768_WriteReg(0x5A,LCD_XSIZE_TFT&0xFF);
    LT768_WriteReg(0x5B,(LCD_XSIZE_TFT>>8)&0xFF);
    //11 5C 13 00 // REG_WR（'h5C, 'h00）
    //11 5D 13 03 // REG_WR（'h5D, 'h03）
    LT768_WriteReg(0x5C,LCD_YSIZE_TFT&0xFF);
    LT768_WriteReg(0x5D,(LCD_YSIZE_TFT>>8)&0xFF);

    //11 5E 13 02 // REG_WR（'h5E, 'h02）
      LT768_WriteReg(0x5E,LCD_Linear_Mode);  //Zyy ????????????????????????????????????????????

    //---------------------------------------------------------------------
    //设置 DMA 从 FLAHS 传输数据到显示内存
    //11 BC 13 00 // REG_WR（'hBC, 'h00）
    //11 BD 13 02 // REG_WR（'hBD, 'h02）
    //11 BE 13 00 // REG_WR（'hBE, 'h00）
    //11 BF 13 00 // REG_WR（'hBF, 'h00）
    //SPI_Logo_Addr
    LT768_WriteReg(0xBC, SPI_Logo_Addr&0xFF);
    LT768_WriteReg(0xBD,(SPI_Logo_Addr>>8)&0xFF);
    LT768_WriteReg(0xBE,(SPI_Logo_Addr>>16)&0xFF);
    LT768_WriteReg(0xBF,(SPI_Logo_Addr>>24)&0xFF);

    //11 C0 13 00 // REG_WR（'hC0,’h00）
    //11 C1 13 00 // REG_WR（'hC1 ,’h00）
    LT768_WriteReg(0xC0,0x00);
    LT768_WriteReg(0xC1,0x00);

    //11 C2 13 00 // REG_WR（'hC2, 'h00）
    //11 C3 13 00 // REG_WR（'hC3, 'h00）
    LT768_WriteReg(0xC2,0x00);
    LT768_WriteReg(0xC3,0x00);

    //11 C6 13 00 // REG_WR（'hC6, 'h00）
    //11 C7 13 04 // REG_WR（'hC7, 'h04）
    LT768_WriteReg(0xC6,LCD_XSIZE_TFT&0xFF);
    LT768_WriteReg(0xC7,(LCD_XSIZE_TFT>>8)&0xFF);

    //11 C8 13 00 // REG_WR（'hC8, 'h00）
    //11 C9 13 03 // REG_WR（'hC9, 'h03）
    LT768_WriteReg(0xC8,LCD_YSIZE_TFT&0xFF);
    LT768_WriteReg(0xC9,(LCD_YSIZE_TFT>>8)&0xFF);

    //11 CA 13 00 // REG_WR（'hCA, 'h00）
    //11 CB 13 04 // REG_WR（'hCB, 'h04）
    LT768_WriteReg(0xCA,LCD_XSIZE_TFT&0xFF);
    LT768_WriteReg(0xCB,(LCD_XSIZE_TFT>>8)&0xFF);

    //11 B7 13 C0 // REG_WR（'hB7, 'hC0）
    //SPI_IF_ID,SPI_Addr_Mode,SPI_Read_Cmd
    if(SPI_IF_ID == 1)
        u8T = 0xC0;
    else	u8T = 0x40;
    if(SPI_Addr_Mode == 1) u8T |= 0x20;
    u8T |= SPI_Read_Cmd;
    LT768_WriteReg(0xB7,u8T);

    /*
    if(CheckBox128M->Checked==true)
    {
        if(SPI_Page_Size == 2048)
        {
                LT768_WriteReg(0xB8,0x0F);
            //AA AA AA AA // 空挃令
            LT768_Wait_AA(4);

            LT768_WriteReg(0xB8,0xB0);
            //AA AA AA AA // 空挃令
            LT768_Wait_AA(4);

            LT768_WriteReg(0xB8,0x10);
            //AA AA AA AA // 空挃令
            LT768_Wait_AA(4);
        }
        tpageAddr = SPI_Logo_Addr/SPI_Page_Size;	//大于128M的Flash要发送PageAddr

        LT768_WriteReg(0xB8,0x13);
        //AA AA AA AA // 空挃令
        LT768_Wait_AA(4);

        LT768_WriteReg(0xB8,(tpageAddr>>16)&0xFF);
        //AA AA AA AA // 空挃令
        LT768_Wait_AA(4);

        LT768_WriteReg(0xB8,(tpageAddr>>8)&0xFF);
        //AA AA AA AA // 空挃令
        LT768_Wait_AA(4);

        LT768_WriteReg(0xB8,tpageAddr&0xFF);
        //AA AA AA AA // 空挃令
        LT768_Wait_AA(4);
    }  */

    //11 B6 13 01 // REG_WR（'hB6, 'h01）
    LT768_WriteReg(0xB6,0x01);
    //AA AA AA AA // 空挃令
    LT768_Wait_AA(4);

    //----------------------------------------------------------
    //LT768_PLL_Initial(CCLK,MCLK);
    //LT768_Wait_AA(10);
    //768x display on-------------------------------------------
    LT768_WriteReg(0x12,reg12H_Val | 0x40);
    LT768_Wait_AA(4);
    //PWM1 ouput------------------------------------------------
    LT768_WriteReg(0x84, PwmPre);	//CCLK/200 = 500K
    LT768_WriteReg(0x85, 0x0a);

    LT768_WriteReg(0x87, 0x00);

    //LT768_WriteReg(0x88, 0x4b);  //For PWM0
    //LT768_WriteReg(0x89, 0x00);
    //LT768_WriteReg(0x8A, 0x04);
    //LT768_WriteReg(0x8B, 0x00);

    LT768_WriteReg(0x8C, PwmTime&0xFF);
    LT768_WriteReg(0x8D, (PwmTime>>8)&0xFF);

    LT768_WriteReg(0x8E, PwmVal);
    LT768_WriteReg(0x8F, (PwmVal>>8)&0xFF);

    LT768_WriteReg(0x86, 0x30);	//PWM1 enable,PWM0 disable
    //----------------------------------------------------------
      LT768_Wait_AA(4);
    //11 B6 12 00 // REG_WR（'hB6, 'h00）
    //LT768_ReaddReg(0xB6,0x00);

    //00 // 离开
    logo_bin_buf[pos++] = 0x00;
}

void MainWindow::Show_Logo_Bin_Buf(void)
{
    int i,j;
    QString tStr;

    tStr ="";
    for(i=0;i<8;i++)tStr = tStr + IntToHex((int)logo_bin_buf[i]&0xFF,2)+" ";
    tStr = tStr + "//ID \r\n";
    j=8;

    for(i=0;i<(pos-8);i++)
    {
        if((i>0)&&((i%4)==0)) tStr = tStr + "\r\n";
        tStr = tStr + IntToHex((int)logo_bin_buf[i+8]&0xFF,2)+" ";
    }
    ui->textEdit->setText(tStr);
    //Memo1->Text = tStr;
}

//---------------------------------------------------------------------------
void MainWindow::LT768_WriteReg(unsigned char regAddr,unsigned char regVal)
{
    logo_bin_buf[pos++] = 0x11;
    logo_bin_buf[pos++] = regAddr;
    logo_bin_buf[pos++] = 0x13;
    logo_bin_buf[pos++] = regVal;
}
//---------------------------------------------------------------------------
void MainWindow::LT768_ReaddReg(unsigned char regAddr,unsigned char regVal)
{
    logo_bin_buf[pos++] = 0x11;
    logo_bin_buf[pos++] = regAddr;
    logo_bin_buf[pos++] = 0x12;
    logo_bin_buf[pos++] = regVal;
}
//---------------------------------------------------------------------------
void MainWindow::LT768_Wait_AA(int times)
{
    int i;

    for(i=0;i<times;i++) logo_bin_buf[pos++] = 0xAA;
}

void MainWindow::on_pushButton_clicked()
{
    QString fileName;
    //QString str,tmpStr;

    Get_Setting_From_GUI();
    Update_Logo_Bin_Buf();
    Show_Logo_Bin_Buf();


    fileName = QFileDialog::getSaveFileName(this,
                                                tr("Save bin files"),
                                                 "./Bootloader.bin",
                                                tr("file(*.bin)"));
    if(!fileName.isEmpty())
    {
        QFile file(fileName);

        if(!file.open(QIODevice::WriteOnly | QIODevice::Append)) //以读写切追加写入Append
        {
            ShowMessage("打开文件失败");
            return ;
        }
        else
        {
            file.write((char *)logo_bin_buf,pos);
            file.close();
        }
    }

    ShowMessage("OK");
}

void MainWindow::ShowMessage(QString qStr)
{
    QMessageBox mesg;
    mesg.about(this,tr("Message"),qStr);
}

QString MainWindow::IntToHex(int val,int bits)
{
    QString numStr;
    QString reStr;

    //reStr = "0x";
    numStr = QString::number(val&0xFFFFFFFF,16);
    numStr = numStr.toUpper();
    if(numStr.length()<bits)
    {
        for(int i=0;i<(bits-numStr.length());i++) reStr +="0";
    }

    return (reStr+numStr);
}

QString MainWindow::IntToStr(int val)
{
    QString numStr;

    numStr = QString::number(val,10);

    return numStr;
}
