#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:
    void on_pushButton_2_clicked();

    void on_pushButton_clicked();

private:
    Ui::MainWindow *ui;

    int pos;
    int CCLK,CCLKOD,CCLKR;
    int MCLK,MCLKOD,MCLKR;
    int SCLK,SCLKOD,SCLKR;
    int LCD_XSIZE_TFT;
    int LCD_YSIZE_TFT;
    int LCD_VBPD;
    int LCD_VFPD;
    int LCD_VSPW;
    int LCD_HBPD;
    int LCD_HFPD;
    int LCD_HSPW;

    int LCD_IF_Format;
    int LCD_RGB_Format;
    int LCD_Color_Format;
    int LCD_Linear_Mode;

    int PCLK_P,HSYNC_P,VSYNC_P,DE_P,DE_MODE_SELECT;

    unsigned char reg12H_Val;

    int PwmPre,PwmTime,PwmVal;

    int SPI_Logo_Addr;
    int SPI_IF_ID,SPI_Addr_Mode,SPI_Read_Cmd,SPI_Page_Size;

    unsigned char logo_bin_buf[1024];

    void ShowMessage(QString qStr);
    QString IntToHex(int val,int bits);
    QString IntToStr(int val);
    void Get_Setting_From_GUI(void);
    void LT768_PLL_Initial(int tCCLK, int tMCLK);
    void Set_LCD_Panel(void);

    void Update_Logo_Bin_Buf(void);
    void Show_Logo_Bin_Buf(void);
    void LT768_WriteReg(unsigned char regAddr,unsigned char regVal);
    void LT768_ReaddReg(unsigned char regAddr,unsigned char regVal);
    void LT768_Wait_AA(int times);


};
#endif // MAINWINDOW_H
