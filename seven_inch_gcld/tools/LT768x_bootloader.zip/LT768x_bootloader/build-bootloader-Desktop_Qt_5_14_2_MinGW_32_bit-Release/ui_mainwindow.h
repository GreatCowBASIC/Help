/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.14.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QCheckBox>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QTextEdit>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralwidget;
    QGridLayout *gridLayout;
    QTextEdit *textEdit;
    QGroupBox *groupBox;
    QGroupBox *groupBox_2;
    QLineEdit *lineEdit_XSIZE;
    QLineEdit *lineEdit_HSPW;
    QLineEdit *lineEdit_HSBP;
    QLineEdit *lineEdit_HSFP;
    QLabel *label;
    QLabel *label_2;
    QLabel *label_3;
    QLabel *label_4;
    QGroupBox *groupBox_3;
    QLineEdit *lineEdit_YSIZE;
    QLineEdit *lineEdit_VSPW;
    QLineEdit *lineEdit_VSFP;
    QLabel *label_5;
    QLabel *label_6;
    QLabel *label_7;
    QLabel *label_8;
    QLineEdit *lineEdit_VSBP;
    QGroupBox *groupBox_4;
    QComboBox *comboBox_LCDIF;
    QComboBox *comboBox_LCDRGB;
    QComboBox *comboBox_ColorIF;
    QLabel *label_9;
    QLabel *label_10;
    QLabel *label_11;
    QGroupBox *groupBox_5;
    QCheckBox *checkBox_PCLK;
    QCheckBox *checkBox_HSYNC;
    QCheckBox *checkBox_VSYNC;
    QCheckBox *checkBox_DEP;
    QCheckBox *checkBox_DEM;
    QGroupBox *groupBox_6;
    QLabel *label_12;
    QLabel *label_13;
    QLabel *label_14;
    QLabel *label_15;
    QLabel *label_16;
    QLabel *label_17;
    QLabel *label_18;
    QComboBox *comboBox_SPIReadCmd;
    QComboBox *comboBox_FlashAddrMode;
    QComboBox *comboBox_CANVASMODE;
    QComboBox *comboBox_Speed;
    QComboBox *comboBox_SPI;
    QLineEdit *lineEdit_FlashAddr;
    QLineEdit *lineEdit_PageSize;
    QGroupBox *groupBox_7;
    QLabel *label_19;
    QLabel *label_20;
    QLabel *label_21;
    QLabel *label_22;
    QLabel *label_23;
    QLabel *label_24;
    QLabel *label_25;
    QLabel *label_26;
    QLabel *label_27;
    QLineEdit *lineEdit_CCLKOD;
    QLineEdit *lineEdit_CCLKR;
    QLineEdit *lineEdit_CCLK;
    QLineEdit *lineEdit_MCLKR;
    QLineEdit *lineEdit_MCLK;
    QLineEdit *lineEdit_SCLK;
    QLineEdit *lineEdit_SCLKOD;
    QLineEdit *lineEdit_MCLKOD;
    QLineEdit *lineEdit_SCLKR;
    QGroupBox *groupBox_8;
    QLabel *label_28;
    QLabel *label_29;
    QLabel *label_30;
    QLineEdit *lineEdit_PPre;
    QLineEdit *lineEdit_PWMT;
    QLineEdit *lineEdit_PWM;
    QPushButton *pushButton;
    QPushButton *pushButton_2;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QString::fromUtf8("MainWindow"));
        MainWindow->resize(968, 709);
        centralwidget = new QWidget(MainWindow);
        centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
        gridLayout = new QGridLayout(centralwidget);
        gridLayout->setObjectName(QString::fromUtf8("gridLayout"));
        textEdit = new QTextEdit(centralwidget);
        textEdit->setObjectName(QString::fromUtf8("textEdit"));
        textEdit->setMinimumSize(QSize(394, 691));
        textEdit->setStyleSheet(QString::fromUtf8("background-color: rgb(150, 150, 150);"));
        textEdit->setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOn);

        gridLayout->addWidget(textEdit, 0, 0, 1, 1);

        groupBox = new QGroupBox(centralwidget);
        groupBox->setObjectName(QString::fromUtf8("groupBox"));
        groupBox->setEnabled(true);
        QSizePolicy sizePolicy(QSizePolicy::Fixed, QSizePolicy::Minimum);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(groupBox->sizePolicy().hasHeightForWidth());
        groupBox->setSizePolicy(sizePolicy);
        groupBox->setMinimumSize(QSize(550, 0));
        groupBox_2 = new QGroupBox(groupBox);
        groupBox_2->setObjectName(QString::fromUtf8("groupBox_2"));
        groupBox_2->setGeometry(QRect(20, 20, 251, 151));
        lineEdit_XSIZE = new QLineEdit(groupBox_2);
        lineEdit_XSIZE->setObjectName(QString::fromUtf8("lineEdit_XSIZE"));
        lineEdit_XSIZE->setGeometry(QRect(130, 20, 100, 23));
        lineEdit_HSPW = new QLineEdit(groupBox_2);
        lineEdit_HSPW->setObjectName(QString::fromUtf8("lineEdit_HSPW"));
        lineEdit_HSPW->setGeometry(QRect(130, 50, 100, 23));
        lineEdit_HSBP = new QLineEdit(groupBox_2);
        lineEdit_HSBP->setObjectName(QString::fromUtf8("lineEdit_HSBP"));
        lineEdit_HSBP->setGeometry(QRect(130, 80, 100, 23));
        lineEdit_HSFP = new QLineEdit(groupBox_2);
        lineEdit_HSFP->setObjectName(QString::fromUtf8("lineEdit_HSFP"));
        lineEdit_HSFP->setGeometry(QRect(130, 110, 100, 23));
        label = new QLabel(groupBox_2);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(20, 20, 91, 20));
        label_2 = new QLabel(groupBox_2);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setGeometry(QRect(21, 50, 101, 20));
        label_3 = new QLabel(groupBox_2);
        label_3->setObjectName(QString::fromUtf8("label_3"));
        label_3->setGeometry(QRect(20, 80, 91, 20));
        label_4 = new QLabel(groupBox_2);
        label_4->setObjectName(QString::fromUtf8("label_4"));
        label_4->setGeometry(QRect(21, 110, 101, 20));
        groupBox_3 = new QGroupBox(groupBox);
        groupBox_3->setObjectName(QString::fromUtf8("groupBox_3"));
        groupBox_3->setGeometry(QRect(290, 20, 251, 151));
        lineEdit_YSIZE = new QLineEdit(groupBox_3);
        lineEdit_YSIZE->setObjectName(QString::fromUtf8("lineEdit_YSIZE"));
        lineEdit_YSIZE->setGeometry(QRect(140, 20, 100, 23));
        lineEdit_VSPW = new QLineEdit(groupBox_3);
        lineEdit_VSPW->setObjectName(QString::fromUtf8("lineEdit_VSPW"));
        lineEdit_VSPW->setGeometry(QRect(140, 50, 100, 23));
        lineEdit_VSFP = new QLineEdit(groupBox_3);
        lineEdit_VSFP->setObjectName(QString::fromUtf8("lineEdit_VSFP"));
        lineEdit_VSFP->setGeometry(QRect(140, 110, 100, 23));
        label_5 = new QLabel(groupBox_3);
        label_5->setObjectName(QString::fromUtf8("label_5"));
        label_5->setGeometry(QRect(30, 20, 101, 20));
        label_6 = new QLabel(groupBox_3);
        label_6->setObjectName(QString::fromUtf8("label_6"));
        label_6->setGeometry(QRect(30, 50, 101, 20));
        label_7 = new QLabel(groupBox_3);
        label_7->setObjectName(QString::fromUtf8("label_7"));
        label_7->setGeometry(QRect(30, 80, 101, 20));
        label_8 = new QLabel(groupBox_3);
        label_8->setObjectName(QString::fromUtf8("label_8"));
        label_8->setGeometry(QRect(30, 110, 101, 20));
        lineEdit_VSBP = new QLineEdit(groupBox_3);
        lineEdit_VSBP->setObjectName(QString::fromUtf8("lineEdit_VSBP"));
        lineEdit_VSBP->setGeometry(QRect(140, 80, 100, 23));
        groupBox_4 = new QGroupBox(groupBox);
        groupBox_4->setObjectName(QString::fromUtf8("groupBox_4"));
        groupBox_4->setGeometry(QRect(20, 180, 251, 141));
        comboBox_LCDIF = new QComboBox(groupBox_4);
        comboBox_LCDIF->setObjectName(QString::fromUtf8("comboBox_LCDIF"));
        comboBox_LCDIF->setGeometry(QRect(136, 30, 100, 24));
        comboBox_LCDRGB = new QComboBox(groupBox_4);
        comboBox_LCDRGB->setObjectName(QString::fromUtf8("comboBox_LCDRGB"));
        comboBox_LCDRGB->setGeometry(QRect(136, 65, 100, 24));
        comboBox_ColorIF = new QComboBox(groupBox_4);
        comboBox_ColorIF->setObjectName(QString::fromUtf8("comboBox_ColorIF"));
        comboBox_ColorIF->setGeometry(QRect(136, 100, 100, 24));
        label_9 = new QLabel(groupBox_4);
        label_9->setObjectName(QString::fromUtf8("label_9"));
        label_9->setGeometry(QRect(10, 40, 111, 16));
        label_10 = new QLabel(groupBox_4);
        label_10->setObjectName(QString::fromUtf8("label_10"));
        label_10->setGeometry(QRect(10, 75, 111, 16));
        label_11 = new QLabel(groupBox_4);
        label_11->setObjectName(QString::fromUtf8("label_11"));
        label_11->setGeometry(QRect(10, 110, 121, 16));
        groupBox_5 = new QGroupBox(groupBox);
        groupBox_5->setObjectName(QString::fromUtf8("groupBox_5"));
        groupBox_5->setGeometry(QRect(290, 180, 251, 141));
        checkBox_PCLK = new QCheckBox(groupBox_5);
        checkBox_PCLK->setObjectName(QString::fromUtf8("checkBox_PCLK"));
        checkBox_PCLK->setGeometry(QRect(20, 30, 171, 19));
        checkBox_PCLK->setChecked(true);
        checkBox_HSYNC = new QCheckBox(groupBox_5);
        checkBox_HSYNC->setObjectName(QString::fromUtf8("checkBox_HSYNC"));
        checkBox_HSYNC->setGeometry(QRect(20, 50, 191, 19));
        checkBox_VSYNC = new QCheckBox(groupBox_5);
        checkBox_VSYNC->setObjectName(QString::fromUtf8("checkBox_VSYNC"));
        checkBox_VSYNC->setGeometry(QRect(20, 70, 201, 19));
        checkBox_DEP = new QCheckBox(groupBox_5);
        checkBox_DEP->setObjectName(QString::fromUtf8("checkBox_DEP"));
        checkBox_DEP->setGeometry(QRect(20, 90, 211, 19));
        checkBox_DEM = new QCheckBox(groupBox_5);
        checkBox_DEM->setObjectName(QString::fromUtf8("checkBox_DEM"));
        checkBox_DEM->setGeometry(QRect(20, 110, 211, 19));
        groupBox_6 = new QGroupBox(groupBox);
        groupBox_6->setObjectName(QString::fromUtf8("groupBox_6"));
        groupBox_6->setGeometry(QRect(20, 330, 521, 141));
        label_12 = new QLabel(groupBox_6);
        label_12->setObjectName(QString::fromUtf8("label_12"));
        label_12->setGeometry(QRect(10, 32, 121, 16));
        label_13 = new QLabel(groupBox_6);
        label_13->setObjectName(QString::fromUtf8("label_13"));
        label_13->setGeometry(QRect(10, 58, 121, 16));
        label_14 = new QLabel(groupBox_6);
        label_14->setObjectName(QString::fromUtf8("label_14"));
        label_14->setGeometry(QRect(10, 85, 121, 20));
        label_15 = new QLabel(groupBox_6);
        label_15->setObjectName(QString::fromUtf8("label_15"));
        label_15->setGeometry(QRect(10, 110, 91, 16));
        label_16 = new QLabel(groupBox_6);
        label_16->setObjectName(QString::fromUtf8("label_16"));
        label_16->setGeometry(QRect(270, 32, 151, 16));
        label_17 = new QLabel(groupBox_6);
        label_17->setObjectName(QString::fromUtf8("label_17"));
        label_17->setGeometry(QRect(270, 58, 141, 16));
        label_18 = new QLabel(groupBox_6);
        label_18->setObjectName(QString::fromUtf8("label_18"));
        label_18->setGeometry(QRect(270, 85, 141, 16));
        comboBox_SPIReadCmd = new QComboBox(groupBox_6);
        comboBox_SPIReadCmd->setObjectName(QString::fromUtf8("comboBox_SPIReadCmd"));
        comboBox_SPIReadCmd->setGeometry(QRect(136, 30, 101, 22));
        comboBox_FlashAddrMode = new QComboBox(groupBox_6);
        comboBox_FlashAddrMode->setObjectName(QString::fromUtf8("comboBox_FlashAddrMode"));
        comboBox_FlashAddrMode->setEnabled(false);
        comboBox_FlashAddrMode->setGeometry(QRect(136, 56, 101, 22));
        comboBox_CANVASMODE = new QComboBox(groupBox_6);
        comboBox_CANVASMODE->setObjectName(QString::fromUtf8("comboBox_CANVASMODE"));
        comboBox_CANVASMODE->setEnabled(false);
        comboBox_CANVASMODE->setGeometry(QRect(136, 82, 101, 22));
        comboBox_Speed = new QComboBox(groupBox_6);
        comboBox_Speed->setObjectName(QString::fromUtf8("comboBox_Speed"));
        comboBox_Speed->setGeometry(QRect(136, 108, 101, 22));
        comboBox_SPI = new QComboBox(groupBox_6);
        comboBox_SPI->setObjectName(QString::fromUtf8("comboBox_SPI"));
        comboBox_SPI->setGeometry(QRect(420, 30, 87, 22));
        lineEdit_FlashAddr = new QLineEdit(groupBox_6);
        lineEdit_FlashAddr->setObjectName(QString::fromUtf8("lineEdit_FlashAddr"));
        lineEdit_FlashAddr->setGeometry(QRect(420, 56, 87, 21));
        lineEdit_PageSize = new QLineEdit(groupBox_6);
        lineEdit_PageSize->setObjectName(QString::fromUtf8("lineEdit_PageSize"));
        lineEdit_PageSize->setEnabled(false);
        lineEdit_PageSize->setGeometry(QRect(420, 82, 87, 21));
        lineEdit_PageSize->setReadOnly(true);
        groupBox_7 = new QGroupBox(groupBox);
        groupBox_7->setObjectName(QString::fromUtf8("groupBox_7"));
        groupBox_7->setGeometry(QRect(20, 466, 521, 121));
        label_19 = new QLabel(groupBox_7);
        label_19->setObjectName(QString::fromUtf8("label_19"));
        label_19->setGeometry(QRect(40, 30, 72, 15));
        label_20 = new QLabel(groupBox_7);
        label_20->setObjectName(QString::fromUtf8("label_20"));
        label_20->setGeometry(QRect(40, 60, 61, 16));
        label_21 = new QLabel(groupBox_7);
        label_21->setObjectName(QString::fromUtf8("label_21"));
        label_21->setGeometry(QRect(40, 90, 61, 16));
        label_22 = new QLabel(groupBox_7);
        label_22->setObjectName(QString::fromUtf8("label_22"));
        label_22->setGeometry(QRect(210, 30, 72, 15));
        label_23 = new QLabel(groupBox_7);
        label_23->setObjectName(QString::fromUtf8("label_23"));
        label_23->setGeometry(QRect(210, 60, 72, 15));
        label_24 = new QLabel(groupBox_7);
        label_24->setObjectName(QString::fromUtf8("label_24"));
        label_24->setGeometry(QRect(210, 90, 72, 15));
        label_25 = new QLabel(groupBox_7);
        label_25->setObjectName(QString::fromUtf8("label_25"));
        label_25->setGeometry(QRect(380, 30, 72, 15));
        label_26 = new QLabel(groupBox_7);
        label_26->setObjectName(QString::fromUtf8("label_26"));
        label_26->setGeometry(QRect(380, 60, 72, 15));
        label_27 = new QLabel(groupBox_7);
        label_27->setObjectName(QString::fromUtf8("label_27"));
        label_27->setGeometry(QRect(380, 90, 72, 15));
        lineEdit_CCLKOD = new QLineEdit(groupBox_7);
        lineEdit_CCLKOD->setObjectName(QString::fromUtf8("lineEdit_CCLKOD"));
        lineEdit_CCLKOD->setGeometry(QRect(120, 28, 50, 23));
        lineEdit_CCLKR = new QLineEdit(groupBox_7);
        lineEdit_CCLKR->setObjectName(QString::fromUtf8("lineEdit_CCLKR"));
        lineEdit_CCLKR->setGeometry(QRect(120, 60, 50, 23));
        lineEdit_CCLK = new QLineEdit(groupBox_7);
        lineEdit_CCLK->setObjectName(QString::fromUtf8("lineEdit_CCLK"));
        lineEdit_CCLK->setGeometry(QRect(120, 90, 50, 23));
        lineEdit_MCLKR = new QLineEdit(groupBox_7);
        lineEdit_MCLKR->setObjectName(QString::fromUtf8("lineEdit_MCLKR"));
        lineEdit_MCLKR->setGeometry(QRect(290, 60, 50, 23));
        lineEdit_MCLK = new QLineEdit(groupBox_7);
        lineEdit_MCLK->setObjectName(QString::fromUtf8("lineEdit_MCLK"));
        lineEdit_MCLK->setGeometry(QRect(290, 90, 50, 23));
        lineEdit_SCLK = new QLineEdit(groupBox_7);
        lineEdit_SCLK->setObjectName(QString::fromUtf8("lineEdit_SCLK"));
        lineEdit_SCLK->setGeometry(QRect(460, 90, 50, 23));
        lineEdit_SCLKOD = new QLineEdit(groupBox_7);
        lineEdit_SCLKOD->setObjectName(QString::fromUtf8("lineEdit_SCLKOD"));
        lineEdit_SCLKOD->setGeometry(QRect(460, 30, 50, 23));
        lineEdit_MCLKOD = new QLineEdit(groupBox_7);
        lineEdit_MCLKOD->setObjectName(QString::fromUtf8("lineEdit_MCLKOD"));
        lineEdit_MCLKOD->setGeometry(QRect(290, 30, 50, 23));
        lineEdit_SCLKR = new QLineEdit(groupBox_7);
        lineEdit_SCLKR->setObjectName(QString::fromUtf8("lineEdit_SCLKR"));
        lineEdit_SCLKR->setGeometry(QRect(460, 60, 50, 23));
        groupBox_8 = new QGroupBox(groupBox);
        groupBox_8->setObjectName(QString::fromUtf8("groupBox_8"));
        groupBox_8->setGeometry(QRect(20, 590, 521, 51));
        label_28 = new QLabel(groupBox_8);
        label_28->setObjectName(QString::fromUtf8("label_28"));
        label_28->setGeometry(QRect(40, 25, 72, 15));
        label_29 = new QLabel(groupBox_8);
        label_29->setObjectName(QString::fromUtf8("label_29"));
        label_29->setGeometry(QRect(210, 25, 72, 15));
        label_30 = new QLabel(groupBox_8);
        label_30->setObjectName(QString::fromUtf8("label_30"));
        label_30->setGeometry(QRect(380, 20, 72, 15));
        lineEdit_PPre = new QLineEdit(groupBox_8);
        lineEdit_PPre->setObjectName(QString::fromUtf8("lineEdit_PPre"));
        lineEdit_PPre->setGeometry(QRect(120, 20, 50, 23));
        lineEdit_PWMT = new QLineEdit(groupBox_8);
        lineEdit_PWMT->setObjectName(QString::fromUtf8("lineEdit_PWMT"));
        lineEdit_PWMT->setGeometry(QRect(290, 20, 50, 23));
        lineEdit_PWM = new QLineEdit(groupBox_8);
        lineEdit_PWM->setObjectName(QString::fromUtf8("lineEdit_PWM"));
        lineEdit_PWM->setGeometry(QRect(460, 20, 50, 23));
        pushButton = new QPushButton(groupBox);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));
        pushButton->setGeometry(QRect(130, 650, 93, 28));
        pushButton_2 = new QPushButton(groupBox);
        pushButton_2->setObjectName(QString::fromUtf8("pushButton_2"));
        pushButton_2->setGeometry(QRect(340, 650, 93, 28));

        gridLayout->addWidget(groupBox, 0, 1, 1, 1);

        MainWindow->setCentralWidget(centralwidget);

        retranslateUi(MainWindow);

        comboBox_LCDIF->setCurrentIndex(-1);


        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QCoreApplication::translate("MainWindow", "Creat bootloader in spi NorFlash", nullptr));
        groupBox->setTitle(QCoreApplication::translate("MainWindow", "Parameter", nullptr));
        groupBox_2->setTitle(QCoreApplication::translate("MainWindow", "HS", nullptr));
        lineEdit_XSIZE->setText(QCoreApplication::translate("MainWindow", "1024", nullptr));
        lineEdit_HSPW->setText(QCoreApplication::translate("MainWindow", "20", nullptr));
        lineEdit_HSBP->setText(QCoreApplication::translate("MainWindow", "140", nullptr));
        lineEdit_HSFP->setText(QCoreApplication::translate("MainWindow", "160", nullptr));
        label->setText(QCoreApplication::translate("MainWindow", "Hs Size(X):  ", nullptr));
        label_2->setText(QCoreApplication::translate("MainWindow", "Pulse Width:  ", nullptr));
        label_3->setText(QCoreApplication::translate("MainWindow", "Back-Porch:  ", nullptr));
        label_4->setText(QCoreApplication::translate("MainWindow", "Front-Porch:  ", nullptr));
        groupBox_3->setTitle(QCoreApplication::translate("MainWindow", "VS", nullptr));
        lineEdit_YSIZE->setText(QCoreApplication::translate("MainWindow", "600", nullptr));
        lineEdit_VSPW->setText(QCoreApplication::translate("MainWindow", "3", nullptr));
        lineEdit_VSFP->setText(QCoreApplication::translate("MainWindow", "12", nullptr));
        label_5->setText(QCoreApplication::translate("MainWindow", "Vs Size(Y):  ", nullptr));
        label_6->setText(QCoreApplication::translate("MainWindow", "Pulse Width:  ", nullptr));
        label_7->setText(QCoreApplication::translate("MainWindow", "Back-Porch:  ", nullptr));
        label_8->setText(QCoreApplication::translate("MainWindow", "Front-Porch:  ", nullptr));
        lineEdit_VSBP->setText(QCoreApplication::translate("MainWindow", "20", nullptr));
        groupBox_4->setTitle(QCoreApplication::translate("MainWindow", "LCD RGB IF", nullptr));
        comboBox_LCDIF->setCurrentText(QString());
        label_9->setText(QCoreApplication::translate("MainWindow", "LCD Interface: ", nullptr));
        label_10->setText(QCoreApplication::translate("MainWindow", "LCD IF RGB :  ", nullptr));
        label_11->setText(QCoreApplication::translate("MainWindow", "Main Win Color:  ", nullptr));
        groupBox_5->setTitle(QCoreApplication::translate("MainWindow", "Mode Select", nullptr));
        checkBox_PCLK->setText(QCoreApplication::translate("MainWindow", "PCLK Fall Active", nullptr));
        checkBox_HSYNC->setText(QCoreApplication::translate("MainWindow", "HSYNC High Active  ", nullptr));
        checkBox_VSYNC->setText(QCoreApplication::translate("MainWindow", "VSYNC High Active   ", nullptr));
        checkBox_DEP->setText(QCoreApplication::translate("MainWindow", "DE Low Active  ", nullptr));
        checkBox_DEM->setText(QCoreApplication::translate("MainWindow", "DE Mode", nullptr));
        groupBox_6->setTitle(QCoreApplication::translate("MainWindow", "SPI Flash", nullptr));
        label_12->setText(QCoreApplication::translate("MainWindow", "Read Command :   ", nullptr));
        label_13->setText(QCoreApplication::translate("MainWindow", "Address Mode :   ", nullptr));
        label_14->setText(QCoreApplication::translate("MainWindow", "In Linear Mode:   ", nullptr));
        label_15->setText(QCoreApplication::translate("MainWindow", "SPI Speed:   ", nullptr));
        label_16->setText(QCoreApplication::translate("MainWindow", "768 SPI Interface: ", nullptr));
        label_17->setText(QCoreApplication::translate("MainWindow", "Picture Address :  ", nullptr));
        label_18->setText(QCoreApplication::translate("MainWindow", "Flash Page Size:   ", nullptr));
        lineEdit_FlashAddr->setText(QCoreApplication::translate("MainWindow", "512", nullptr));
        lineEdit_PageSize->setText(QCoreApplication::translate("MainWindow", "256", nullptr));
        groupBox_7->setTitle(QCoreApplication::translate("MainWindow", "PLL", nullptr));
        label_19->setText(QCoreApplication::translate("MainWindow", "CCLK_OD:  ", nullptr));
        label_20->setText(QCoreApplication::translate("MainWindow", "CCLK_R: ", nullptr));
        label_21->setText(QCoreApplication::translate("MainWindow", "CCLK_N:  ", nullptr));
        label_22->setText(QCoreApplication::translate("MainWindow", "MCLK_OD:  ", nullptr));
        label_23->setText(QCoreApplication::translate("MainWindow", "MCLK_R:   ", nullptr));
        label_24->setText(QCoreApplication::translate("MainWindow", "MCLK_N:  ", nullptr));
        label_25->setText(QCoreApplication::translate("MainWindow", "SCLK_OD:  ", nullptr));
        label_26->setText(QCoreApplication::translate("MainWindow", "SCLK_R:   ", nullptr));
        label_27->setText(QCoreApplication::translate("MainWindow", "SCLK_N:  ", nullptr));
        lineEdit_CCLKOD->setText(QCoreApplication::translate("MainWindow", "3", nullptr));
        lineEdit_CCLKR->setText(QCoreApplication::translate("MainWindow", "5", nullptr));
        lineEdit_CCLK->setText(QCoreApplication::translate("MainWindow", "160", nullptr));
        lineEdit_MCLKR->setText(QCoreApplication::translate("MainWindow", "5", nullptr));
        lineEdit_MCLK->setText(QCoreApplication::translate("MainWindow", "160", nullptr));
        lineEdit_SCLK->setText(QCoreApplication::translate("MainWindow", "100", nullptr));
        lineEdit_SCLKOD->setText(QCoreApplication::translate("MainWindow", "3", nullptr));
        lineEdit_MCLKOD->setText(QCoreApplication::translate("MainWindow", "3", nullptr));
        lineEdit_SCLKR->setText(QCoreApplication::translate("MainWindow", "5", nullptr));
        groupBox_8->setTitle(QCoreApplication::translate("MainWindow", "PWM1", nullptr));
        label_28->setText(QCoreApplication::translate("MainWindow", "PWM Pre:   ", nullptr));
        label_29->setText(QCoreApplication::translate("MainWindow", "PWM(T):   ", nullptr));
        label_30->setText(QCoreApplication::translate("MainWindow", "PWM(%):   ", nullptr));
        lineEdit_PPre->setText(QCoreApplication::translate("MainWindow", "19", nullptr));
        lineEdit_PWMT->setText(QCoreApplication::translate("MainWindow", "100", nullptr));
        lineEdit_PWM->setText(QCoreApplication::translate("MainWindow", "70", nullptr));
        pushButton->setText(QCoreApplication::translate("MainWindow", "Creat", nullptr));
        pushButton_2->setText(QCoreApplication::translate("MainWindow", "Close", nullptr));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
