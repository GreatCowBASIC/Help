#ifndef LT768_Basic_h
#define LT768_Basic_h
#include "Arduino.h"
#include <Wire.h>
#include <SPI.h>

#define Arduino_SPI     1 //1:use SPI to drive LT768
#define Arduino_IIC     0 //1:use IIC to drive LT768

#define LCD_XSIZE_TFT    1024
#define LCD_YSIZE_TFT    600

#define LCD_VBPD         20
#define LCD_VFPD         12
#define LCD_VSPW         3
#define LCD_HBPD         140
#define LCD_HFPD         160
#define LCD_HSPW         20

#define LCD_PCLK_Falling_Rising     1      // 1:FallingEdge    0:RisingEdge
#define LCD_HSYNC_Active_Polarity   0      // 1:HighLevel    0:LowLevel
#define LCD_VSYNC_Active_Polarity   0      // 1:HighLevel    0:LowLevel
#define LCD_DE_Active_Polarity      1      // 1:HighLevel    0:LowLevel

#define  cSetb0    0x01
#define cSetb1    0x02
#define cSetb2    0x04
#define cSetb3    0x08
#define cSetb4    0x10
#define cSetb5    0x20
#define cSetb6    0x40
#define cSetb7    0x80
#define cClrb0    0xfe
#define cClrb1    0xfd
#define cClrb2    0xfb
#define cClrb3    0xf7
#define cClrb4    0xef
#define cClrb5    0xdf
#define cClrb6    0xbf
#define cClrb7    0x7f

#define Blue           0x001F
#define Red            0xF800
#define Green          0x07E0

class LT768Basic
{
	private:
		
	public:
	void SPIInit();
	void SPISetCs(int cs);
	unsigned char SPIRwByte(unsigned char value);
	void SPI_CmdWrite(int cmd);
	void SPI_DataWrite(int data);
	void SPI_DataWrite_Pixel(int data);
	int SPI_StatusRead(void);
	int SPI_DataRead(void);
	void SPI_RegisterWrite(unsigned char Cmd,unsigned char Data);
	unsigned char SPI_RegisterRead(unsigned char Cmd);
	void IICInit();	
	void IIC_CmdWrite(int cmd);
	void IIC_DataWrite(int data);
	void IIC_DataWrite_Pixel(int data);
	int IIC_StatusRead(void);
	int IIC_DataRead(void);
	void IIC_RegisterWrite(unsigned char Cmd,unsigned char Data);
	unsigned char IIC_RegisterRead(unsigned char Cmd);
	void Parallel_Init(void);
	void LCD_CmdWrite(unsigned char cmd);
	void LCD_DataWrite(unsigned char data);
	void LCD_DataWrite_Pixel(unsigned int data);
	unsigned char LCD_StatusRead(void);
	unsigned int LCD_DataRead(void);
	void LCD_RegisterWrite(unsigned char Cmd,unsigned char Data);
	unsigned char LCD_RegisterRead(unsigned char Cmd);
	void Check_SDRAM_Ready(void);
	void TFT_16bit(void);
	void Host_Bus_16bit(void);
	void RGB_16b_16bpp(void);
	void MemRead_Left_Right_Top_Down(void);
	void Graphic_Mode(void);
	void Memory_Select_SDRAM(void);
	void HSCAN_L_to_R(void);
	void VSCAN_T_to_B(void);
	void PDATA_Set_RGB(void);
	void PCLK_Rising(void);
	void PCLK_Falling(void);
	void HSYNC_Low_Active(void);
	void HSYNC_High_Active(void);
	void VSYNC_Low_Active(void);
	void VSYNC_High_Active(void);
	void DE_Low_Active(void);
	void DE_High_Active(void);
	void Set_PCLK(unsigned char val);
	void Set_HSYNC_Active(unsigned char val);
	void Set_VSYNC_Active(unsigned char val);
	void Set_DE_Active(unsigned char val);
	void LCD_HorizontalWidth_VerticalHeight(unsigned short WX,unsigned short HY);
	void LCD_Horizontal_Non_Display(unsigned short WX);
	void LCD_HSYNC_Start_Position(unsigned short WX);
	void LCD_HSYNC_Pulse_Width(unsigned short WX);
	void LCD_Vertical_Non_Display(unsigned short HY);
	void LCD_VSYNC_Start_Position(unsigned short HY);
	void LCD_VSYNC_Pulse_Width(unsigned short HY);
	void Select_Main_Window_16bpp(void);
	void Memory_XY_Mode(void); 
	void Memory_16bpp_Mode(void);
	void MemWrite_Left_Right_Top_Down(void);
	void LT768_HW_Reset(void);
	void System_Check_Temp(void);
	void LT768_PLL_Initial(void);
	void LT768_SDRAM_initail(void);
	void LT768_initial(void);
	void Display_ON(void);
	void Main_Image_Start_Address(unsigned long Addr);
	void Main_Image_Width(unsigned short WX);
	void Main_Window_Start_XY(unsigned short WX,unsigned short HY);
	void Canvas_Image_Start_address(unsigned long Addr);
	void Canvas_image_width(unsigned short WX);
	void Active_Window_XY(unsigned short WX,unsigned short HY);
	void Active_Window_WH(unsigned short WX,unsigned short HY);
	void Foreground_color_65k(unsigned short temp);
	void Square_Start_XY(unsigned short WX,unsigned short HY);
	void Square_End_XY(unsigned short WX,unsigned short HY);
	void Check_Busy_Draw(void);
	void Start_Square_Fill(void);
	void Check_2D_Busy(void);
	void LT768_DrawSquare_Fill(unsigned short X1,unsigned short Y1,unsigned short X2,unsigned short Y2,unsigned long ForegroundColor);
	void Enable_SFlash_SPI(void);
	void Select_SFI_0(void);
	void Select_SFI_1(void);
	void Select_SFI_DMA_Mode(void);
	void SPI_Clock_Period(unsigned char temp);
	void Goto_Pixel_XY(unsigned short WX,unsigned short HY);
	void SFI_DMA_Destination_Upper_Left_Corner(unsigned short WX,unsigned short HY);
	void SFI_DMA_Transfer_Width_Height(unsigned short WX,unsigned short HY);
	void SFI_DMA_Source_Width(unsigned short WX);
	void SFI_DMA_Source_Start_Address(unsigned long Addr);
	void Start_SFI_DMA(void);
	void Check_Busy_SFI_DMA(void);
	void LT768_DMA_24bit_Block
	(
	 unsigned char SCS
	,unsigned char Clk
	,unsigned short X1
	,unsigned short Y1
	,unsigned short X_W
	,unsigned short Y_H
	,unsigned short P_W
	,unsigned long Addr
	);
};
extern LT768Basic LT768_Basic;
#endif