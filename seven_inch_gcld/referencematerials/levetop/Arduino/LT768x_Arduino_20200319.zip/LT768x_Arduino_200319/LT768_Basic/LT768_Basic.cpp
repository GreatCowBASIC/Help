#include "Arduino.h"
#include "LT768_Basic.h"
#include <Wire.h>
#include <SPI.h>

// ------------------------------------------------------------ SPI Drive --------------------------------------------------------------------
#if Arduino_SPI
void LT768Basic::SPIInit()
{
	pinMode(53, OUTPUT);
	SPI.beginTransaction(SPISettings(8000000, MSBFIRST, SPI_MODE0));
	SPI.begin();
}
void LT768Basic::SPISetCs(int cs)
{
	if(cs)
		digitalWrite(53,HIGH);
	else
	  digitalWrite(53,LOW);
}
unsigned char LT768Basic::SPIRwByte(unsigned char value)
{
	unsigned char rec;
	rec = SPI.transfer(value);
	return rec;
}
void LT768Basic::SPI_CmdWrite(int cmd)
{
  LT768_Basic.SPISetCs(0);    //SS_RESET;
  LT768_Basic.SPIRwByte(0x00);
  LT768_Basic.SPIRwByte(cmd);
  LT768_Basic.SPISetCs(1);    //SS_SET;
}
void LT768Basic::SPI_DataWrite(int data)
{
  LT768_Basic.SPISetCs(0);    //SS_RESET;
  LT768_Basic.SPIRwByte(0x80);
  LT768_Basic.SPIRwByte(data);
  LT768_Basic.SPISetCs(1);    //SS_SET;
}
void LT768Basic::SPI_DataWrite_Pixel(int data)
{
  LT768_Basic.SPISetCs(0);    //SS_RESET;
  LT768_Basic.SPIRwByte(0x80);
  LT768_Basic.SPIRwByte(data);
  LT768_Basic.SPISetCs(1);    //SS_SET;
  
  LT768_Basic.SPISetCs(0);    //SS_RESET;
  LT768_Basic.SPIRwByte(0x80);
  LT768_Basic.SPIRwByte(data>>8);
  LT768_Basic.SPISetCs(1);    //SS_SET;
}
int LT768Basic::SPI_StatusRead(void)
{
  int temp = 0;
  LT768_Basic.SPISetCs(0);    //SS_RESET;
  LT768_Basic.SPIRwByte(0x40);
  temp = LT768_Basic.SPIRwByte(0x00);
  LT768_Basic.SPISetCs(1);    //SS_SET;
  return temp;
}

int LT768Basic::SPI_DataRead(void)
{
  int temp = 0;
  LT768_Basic.SPISetCs(0);    //SS_RESET;
  LT768_Basic.SPIRwByte(0xc0);
  temp = LT768_Basic.SPIRwByte(0x00);
  LT768_Basic.SPISetCs(1);    //SS_SET;
  return temp;
}
#endif
// ------------------------------------------------------------ IIC Drive --------------------------------------------------------------------
#if Arduino_IIC
void LT768Basic::IICInit()
{
	Wire.begin();
	Wire.setClock(400000);
}
void LT768Basic::IIC_CmdWrite(int cmd)
{
  Wire.beginTransmission(0x1e);
  Wire.write(cmd);
  Wire.endTransmission();
}
void LT768Basic::IIC_DataWrite(int data)
{
  Wire.beginTransmission(0x1f);
  Wire.write(data);
  Wire.endTransmission();
}
void LT768Basic::IIC_DataWrite_Pixel(int data)
{
  Wire.beginTransmission(0x1f);
  Wire.write(data);
  Wire.endTransmission();

  Wire.beginTransmission(0x1f);
  Wire.write(data>>8);
  Wire.endTransmission();
}
int LT768Basic::IIC_StatusRead(void)
{
  int temp = 0; 
  temp = Wire.requestFrom(0x1e,1);
  while(Wire.available())
  { 
    temp = Wire.read();
  }
  return temp;
}

int LT768Basic::IIC_DataRead(void)
{
  int temp = 0;   
  temp = Wire.requestFrom(0x1f,1);
  while(Wire.available())
  { 
    temp = Wire.read();
  }
  return temp;
}
#endif
//-----------------------------------------------------------------------------------------------------------------------------------

void LT768Basic::Parallel_Init(void)
{
	#if Arduino_SPI
	LT768_Basic.SPIInit();
	#endif
	
	#if Arduino_IIC
	LT768_Basic.IICInit();
	#endif
}
void LT768Basic::LCD_CmdWrite(unsigned char cmd)
{
	#if Arduino_SPI
	LT768_Basic.SPI_CmdWrite(cmd);
	#endif
	
	#if Arduino_IIC
	LT768_Basic.IIC_CmdWrite(cmd);
	#endif
}

void LT768Basic::LCD_DataWrite(unsigned char data)
{
	#if Arduino_SPI
	LT768_Basic.SPI_DataWrite(data);
	#endif
	
	#if Arduino_IIC
	LT768_Basic.IIC_DataWrite(data);
	#endif
}

void LT768Basic::LCD_DataWrite_Pixel(unsigned int data)
{
	#if Arduino_SPI
	LT768_Basic.SPI_DataWrite_Pixel(data);
	#endif
	
	#if Arduino_IIC
	LT768_Basic.IIC_DataWrite_Pixel(data);
	#endif
}


unsigned char LT768Basic::LCD_StatusRead(void)
{
	unsigned char temp = 0;
	
	#if Arduino_SPI
	temp = LT768_Basic.SPI_StatusRead();
	#endif
	
	#if Arduino_IIC
	temp = LT768_Basic.IIC_StatusRead();
	#endif
	
	return temp;
}

unsigned int LT768Basic::LCD_DataRead(void)
{
	unsigned int temp = 0;

	#if Arduino_SPI
	temp = LT768_Basic.SPI_DataRead();
	#endif
	
	#if Arduino_IIC
	temp = LT768_Basic.IIC_DataRead();
	#endif
	
	return temp;
}
void LT768Basic::LCD_RegisterWrite(unsigned char Cmd,unsigned char Data)
{
	LT768_Basic.LCD_CmdWrite(Cmd);
	LT768_Basic.LCD_DataWrite(Data);
}  
//---------------------//
unsigned char LT768Basic::LCD_RegisterRead(unsigned char Cmd)
{
	unsigned char temp;
	
	LT768_Basic.LCD_CmdWrite(Cmd);
	temp=LT768_Basic.LCD_DataRead();
	return temp;
}


void LT768Basic::Check_SDRAM_Ready(void)
{
/*  0: SDRAM is not ready for access
  1: SDRAM is ready for access    */  
  unsigned char temp;
  do
  {
    temp=LT768_Basic.LCD_StatusRead();
  }
  while( (temp&0x04) == 0x00 );
}
void LT768Basic::TFT_16bit(void)
{
  unsigned char temp;
  LT768_Basic.LCD_CmdWrite(0x01);
  temp = LT768_Basic.LCD_DataRead();
  temp |= cSetb4;
    temp &= cClrb3;
  LT768_Basic.LCD_DataWrite(temp);  
}
void LT768Basic::Host_Bus_16bit(void)
{
/*  Parallel Host Data Bus Width Selection
    0: 8-bit Parallel Host Data Bus.
    1: 16-bit Parallel Host Data Bus.*/
  unsigned char temp;
  LT768_Basic.LCD_CmdWrite(0x01);
  temp = LT768_Basic.LCD_DataRead();
  temp |= cSetb0;
  LT768_Basic.LCD_DataWrite(temp);
}
void LT768Basic::RGB_16b_16bpp(void)
{
  unsigned char temp;
  LT768_Basic.LCD_CmdWrite(0x02);
  temp = LT768_Basic.LCD_DataRead();
  temp &= cClrb7;
  temp |= cSetb6;
  LT768_Basic.LCD_DataWrite(temp);
}
void LT768Basic::MemRead_Left_Right_Top_Down(void)
{
  unsigned char temp;
  LT768_Basic.LCD_CmdWrite(0x02);
  temp = LT768_Basic.LCD_DataRead();
  temp &= cClrb5;
  temp &= cClrb4;
  LT768_Basic.LCD_DataWrite(temp);
}
void LT768Basic::Graphic_Mode(void)
{
  unsigned char temp;
  LT768_Basic.LCD_CmdWrite(0x03);
  temp = LT768_Basic.LCD_DataRead();
    temp &= cClrb2;
  LT768_Basic.LCD_DataWrite(temp);
}
void LT768Basic::Memory_Select_SDRAM(void)
{
  unsigned char temp;
  LT768_Basic.LCD_CmdWrite(0x03);
  temp = LT768_Basic.LCD_DataRead();
    temp &= cClrb1;
    temp &= cClrb0; // B
  LT768_Basic.LCD_DataWrite(temp);
}
void LT768Basic::HSCAN_L_to_R(void)
{
/*  
Horizontal Scan Direction
0 : From Left to Right
1 : From Right to Left
PIP window will be disabled when HDIR set as 1.
*/
  unsigned char temp;
  
  LT768_Basic.LCD_CmdWrite(0x12);
  temp = LT768_Basic.LCD_DataRead();
  temp &= cClrb4;
  LT768_Basic.LCD_DataWrite(temp);
}
void LT768Basic::VSCAN_T_to_B(void)
{
/*  
Vertical Scan direction
0 : From Top to Bottom
1 : From bottom to Top
PIP window will be disabled when VDIR set as 1.
*/
  unsigned char temp;
  
  LT768_Basic.LCD_CmdWrite(0x12);
  temp = LT768_Basic.LCD_DataRead();
  temp &= cClrb3;
  LT768_Basic.LCD_DataWrite(temp);
}
void LT768Basic::PDATA_Set_RGB(void)
{
/*  
parallel PDATA[23:0] Output Sequence
000b : RGB.
001b : RBG.
010b : GRB.
011b : GBR.
100b : BRG.
101b : BGR.
*/
  unsigned char temp;
  
  LT768_Basic.LCD_CmdWrite(0x12);
  temp = LT768_Basic.LCD_DataRead();
    temp &=0xf8;
  LT768_Basic.LCD_DataWrite(temp);
}
void LT768Basic::PCLK_Rising(void)   
{
/*
PCLK Inversion
0: PDAT, DE, HSYNC etc. Drive(/ change) at PCLK falling edge.
1: PDAT, DE, HSYNC etc. Drive(/ change) at PCLK rising edge.
*/
  unsigned char temp;
  LT768_Basic.LCD_CmdWrite(0x12);
  temp = LT768_Basic.LCD_DataRead();
    temp &= cClrb7;
  LT768_Basic.LCD_DataWrite(temp);
}
void LT768Basic::PCLK_Falling(void)
{
/*
PCLK Inversion
0: PDAT, DE, HSYNC etc. Drive(/ change) at PCLK falling edge.
1: PDAT, DE, HSYNC etc. Drive(/ change) at PCLK rising edge.
*/
  unsigned char temp;
  LT768_Basic.LCD_CmdWrite(0x12);
  temp = LT768_Basic.LCD_DataRead();
    temp |= cSetb7;
  LT768_Basic.LCD_DataWrite(temp);
}
void LT768Basic::HSYNC_Low_Active(void)
{
/*  
HSYNC Polarity
0 : Low active.
1 : High active.
*/
  unsigned char temp;
  
  LT768_Basic.LCD_CmdWrite(0x13);
  temp = LT768_Basic.LCD_DataRead();
  temp &= cClrb7;
  LT768_Basic.LCD_DataWrite(temp);
}
void LT768Basic::HSYNC_High_Active(void)
{
/*  
HSYNC Polarity
0 : Low active.
1 : High active.
*/
  unsigned char temp;
  
  LT768_Basic.LCD_CmdWrite(0x13);
  temp = LT768_Basic.LCD_DataRead();   
  temp |= cSetb7;
  LT768_Basic.LCD_DataWrite(temp);
}
void LT768Basic::VSYNC_Low_Active(void)
{
/*  
VSYNC Polarity
0 : Low active.
1 : High active.
*/
  unsigned char temp;
  
  LT768_Basic.LCD_CmdWrite(0x13);
  temp = LT768_Basic.LCD_DataRead();
  temp &= cClrb6; 
  LT768_Basic.LCD_DataWrite(temp);
}
void LT768Basic::VSYNC_High_Active(void)
{
/*  
VSYNC Polarity
0 : Low active.
1 : High active.
*/
  unsigned char temp;
  
  LT768_Basic.LCD_CmdWrite(0x13);
  temp = LT768_Basic.LCD_DataRead();
  temp |= cSetb6;
  LT768_Basic.LCD_DataWrite(temp);
}
void LT768Basic::DE_Low_Active(void)
{
/*  
DE Polarity
0 : High active.
1 : Low active.
*/
  unsigned char temp;
  
  LT768_Basic.LCD_CmdWrite(0x13);
  temp = LT768_Basic.LCD_DataRead();
    temp |= cSetb5;
  LT768_Basic.LCD_DataWrite(temp);
}
void LT768Basic::DE_High_Active(void)
{
/*  
DE Polarity
0 : High active.
1 : Low active.
*/
  unsigned char temp;
  
  LT768_Basic.LCD_CmdWrite(0x13);
  temp = LT768_Basic.LCD_DataRead();
  temp &= cClrb5;
  LT768_Basic.LCD_DataWrite(temp);
}
void LT768Basic::Set_PCLK(unsigned char val)
{
  if(val == 1)  LT768_Basic.PCLK_Falling();
  else      LT768_Basic.PCLK_Rising();
}

void LT768Basic::Set_HSYNC_Active(unsigned char val)
{
  if(val == 1)  LT768_Basic.HSYNC_High_Active();
  else      LT768_Basic.HSYNC_Low_Active();
}

void LT768Basic::Set_VSYNC_Active(unsigned char val)
{
  if(val == 1)  LT768_Basic.VSYNC_High_Active();
  else      LT768_Basic.VSYNC_Low_Active();
}

void LT768Basic::Set_DE_Active(unsigned char val)
{
  if(val == 1)  LT768_Basic.DE_High_Active();
  else      LT768_Basic.DE_Low_Active();
}
void LT768Basic::LCD_HorizontalWidth_VerticalHeight(unsigned short WX,unsigned short HY)
{
  unsigned char temp;
  if(WX<8)
    {
  LT768_Basic.LCD_CmdWrite(0x14);
  LT768_Basic.LCD_DataWrite(0x00);
    
  LT768_Basic.LCD_CmdWrite(0x15);
  LT768_Basic.LCD_DataWrite(WX);
    
    temp=HY-1;
  LT768_Basic.LCD_CmdWrite(0x1A);
  LT768_Basic.LCD_DataWrite(temp);
      
  temp=(HY-1)>>8;
  LT768_Basic.LCD_CmdWrite(0x1B);
  LT768_Basic.LCD_DataWrite(temp);
  }
  else
  {
    temp=(WX/8)-1;
  LT768_Basic.LCD_CmdWrite(0x14);
  LT768_Basic.LCD_DataWrite(temp);
    
    temp=WX%8;
  LT768_Basic.LCD_CmdWrite(0x15);
  LT768_Basic.LCD_DataWrite(temp);
    
    temp=HY-1;
  LT768_Basic.LCD_CmdWrite(0x1A);
  LT768_Basic.LCD_DataWrite(temp);
      
  temp=(HY-1)>>8;
  LT768_Basic.LCD_CmdWrite(0x1B);
  LT768_Basic.LCD_DataWrite(temp);
  }
}
//[16h][17h]=========================================================================
void LT768Basic::LCD_Horizontal_Non_Display(unsigned short WX)
{
  unsigned char temp;
  if(WX<8)
  {
  LT768_Basic.LCD_CmdWrite(0x16);
  LT768_Basic.LCD_DataWrite(0x00);
    
  LT768_Basic.LCD_CmdWrite(0x17);
  LT768_Basic.LCD_DataWrite(WX);
  }
  else
  {
    temp=(WX/8)-1;
  LT768_Basic.LCD_CmdWrite(0x16);
  LT768_Basic.LCD_DataWrite(temp);
    
    temp=WX%8;
  LT768_Basic.LCD_CmdWrite(0x17);
  LT768_Basic.LCD_DataWrite(temp);
  } 
}
//[18h]=========================================================================
void LT768Basic::LCD_HSYNC_Start_Position(unsigned short WX)
{
  unsigned char temp;
  if(WX<8)
  {
  LT768_Basic.LCD_CmdWrite(0x18);
  LT768_Basic.LCD_DataWrite(0x00);
  }
  else
  {
    temp=(WX/8)-1;
  LT768_Basic.LCD_CmdWrite(0x18);
  LT768_Basic.LCD_DataWrite(temp);  
  }
}
//[19h]=========================================================================
void LT768Basic::LCD_HSYNC_Pulse_Width(unsigned short WX)
{
  unsigned char temp;
  if(WX<8)
  {
  LT768_Basic.LCD_CmdWrite(0x19);
  LT768_Basic.LCD_DataWrite(0x00);
  }
  else
  {
    temp=(WX/8)-1;
  LT768_Basic.LCD_CmdWrite(0x19);
  LT768_Basic.LCD_DataWrite(temp);  
  }
}
//[1Ch][1Dh]=========================================================================
void LT768Basic::LCD_Vertical_Non_Display(unsigned short HY)
{
  unsigned char temp;
    temp=HY-1;
  LT768_Basic.LCD_CmdWrite(0x1C);
  LT768_Basic.LCD_DataWrite(temp);

  LT768_Basic.LCD_CmdWrite(0x1D);
  LT768_Basic.LCD_DataWrite(temp>>8);
}
//[1Eh]=========================================================================
void LT768Basic::LCD_VSYNC_Start_Position(unsigned short HY)
{
  unsigned char temp;
    temp=HY-1;
  LT768_Basic.LCD_CmdWrite(0x1E);
  LT768_Basic.LCD_DataWrite(temp);
}
//[1Fh]=========================================================================
void LT768Basic::LCD_VSYNC_Pulse_Width(unsigned short HY)
{
  unsigned char temp;
    temp=HY-1;
  LT768_Basic.LCD_CmdWrite(0x1F);
  LT768_Basic.LCD_DataWrite(temp);
}
void LT768Basic::Memory_XY_Mode(void) 
{
  unsigned char temp;

  LT768_Basic.LCD_CmdWrite(0x5E);
  temp = LT768_Basic.LCD_DataRead();
  temp &= cClrb2;
  LT768_Basic.LCD_DataWrite(temp);
}
void LT768Basic::Memory_16bpp_Mode(void)  
{
  unsigned char temp;

  LT768_Basic.LCD_CmdWrite(0x5E);
  temp = LT768_Basic.LCD_DataRead();
  temp &= cClrb1;
  temp |= cSetb0;
  LT768_Basic.LCD_DataWrite(temp);
}
void LT768Basic::Select_Main_Window_16bpp(void)
{
  unsigned char temp;
  LT768_Basic.LCD_CmdWrite(0x10);
  temp = LT768_Basic.LCD_DataRead();
    temp &= cClrb3;
    temp |= cSetb2;
  LT768_Basic.LCD_DataWrite(temp);
}
void LT768Basic::Main_Image_Start_Address(unsigned long Addr) 
{
/*
[20h] Main Image Start Address[7:2]
[21h] Main Image Start Address[15:8]
[22h] Main Image Start Address [23:16]
[23h] Main Image Start Address [31:24]
*/
  LT768_Basic.LCD_RegisterWrite(0x20,Addr);
  LT768_Basic.LCD_RegisterWrite(0x21,Addr>>8);
  LT768_Basic.LCD_RegisterWrite(0x22,Addr>>16);
  LT768_Basic.LCD_RegisterWrite(0x23,Addr>>24);
}
void LT768Basic::Main_Image_Width(unsigned short WX)  
{
/*
[24h] Main Image Width [7:0]
[25h] Main Image Width [12:8]
Unit: Pixel.
It must be divisible by 4. MIW Bit [1:0] tie to ��0�� internally.
The value is physical pixel number. Maximum value is 8188 pixels
*/
  LT768_Basic.LCD_RegisterWrite(0x24,WX);
  LT768_Basic.LCD_RegisterWrite(0x25,WX>>8);
}
//[26h][27h][28h][29h]=========================================================================
void LT768Basic::Main_Window_Start_XY(unsigned short WX,unsigned short HY)  
{
/*
[26h] Main Window Upper-Left corner X-coordination [7:0]
[27h] Main Window Upper-Left corner X-coordination [12:8]
Reference Main Image coordination.
Unit: Pixel
It must be divisible by 4. MWULX Bit [1:0] tie to ��0�� internally.
X-axis coordination plus Horizontal display width cannot large than 8188.

[28h] Main Window Upper-Left corner Y-coordination [7:0]
[29h] Main Window Upper-Left corner Y-coordination [12:8]
Reference Main Image coordination.
Unit: Pixel
Range is between 0 and 8191.
*/
  LT768_Basic.LCD_RegisterWrite(0x26,WX);
  LT768_Basic.LCD_RegisterWrite(0x27,WX>>8);

  LT768_Basic.LCD_RegisterWrite(0x28,HY);
  LT768_Basic.LCD_RegisterWrite(0x29,HY>>8);
}
void LT768Basic::Canvas_Image_Start_address(unsigned long Addr) 
{
/*
[50h] Start address of Canvas [7:0]
[51h] Start address of Canvas [15:8]
[52h] Start address of Canvas [23:16]
[53h] Start address of Canvas [31:24]
*/
  LT768_Basic.LCD_RegisterWrite(0x50,Addr);
  LT768_Basic.LCD_RegisterWrite(0x51,Addr>>8);
  LT768_Basic.LCD_RegisterWrite(0x52,Addr>>16);
  LT768_Basic.LCD_RegisterWrite(0x53,Addr>>24);
}
//[54h][55h]=========================================================================
void LT768Basic::Canvas_image_width(unsigned short WX)  
{
/*
[54h] Canvas image width [7:2]
[55h] Canvas image width [12:8]
*/
  LT768_Basic.LCD_RegisterWrite(0x54,WX);
  LT768_Basic.LCD_RegisterWrite(0x55,WX>>8);
}
//[56h][57h][58h][59h]=========================================================================
void LT768Basic::Active_Window_XY(unsigned short WX,unsigned short HY)  
{
/*
[56h] Active Window Upper-Left corner X-coordination [7:0]
[57h] Active Window Upper-Left corner X-coordination [12:8]
[58h] Active Window Upper-Left corner Y-coordination [7:0]
[59h] Active Window Upper-Left corner Y-coordination [12:8]
*/
  LT768_Basic.LCD_RegisterWrite(0x56,WX);
  LT768_Basic.LCD_RegisterWrite(0x57,WX>>8);
  
  LT768_Basic.LCD_RegisterWrite(0x58,HY);
  LT768_Basic.LCD_RegisterWrite(0x59,HY>>8);
}
//[5Ah][5Bh][5Ch][5Dh]=========================================================================
void LT768Basic::Active_Window_WH(unsigned short WX,unsigned short HY)  
{
/*
[5Ah] Width of Active Window [7:0]
[5Bh] Width of Active Window [12:8]
[5Ch] Height of Active Window [7:0]
[5Dh] Height of Active Window [12:8]
*/
  LT768_Basic.LCD_RegisterWrite(0x5A,WX);
  LT768_Basic.LCD_RegisterWrite(0x5B,WX>>8);
 
  LT768_Basic.LCD_RegisterWrite(0x5C,HY);
  LT768_Basic.LCD_RegisterWrite(0x5D,HY>>8);
}
void LT768Basic::Foreground_color_65k(unsigned short temp)
{
    LT768_Basic.LCD_CmdWrite(0xD2);
  LT768_Basic.LCD_DataWrite(temp>>8);
 
    LT768_Basic.LCD_CmdWrite(0xD3);
  LT768_Basic.LCD_DataWrite(temp>>3);
  
    LT768_Basic.LCD_CmdWrite(0xD4);
  LT768_Basic.LCD_DataWrite(temp<<3);
}
void LT768Basic::Square_Start_XY(unsigned short WX,unsigned short HY)
{
/*
[68h] Draw Line/Square/Triangle Start X-coordination [7:0]
[69h] Draw Line/Square/Triangle Start X-coordination [12:8]
[6Ah] Draw Line/Square/Triangle Start Y-coordination [7:0]
[6Bh] Draw Line/Square/Triangle Start Y-coordination [12:8]
*/
  LT768_Basic.LCD_CmdWrite(0x68);
  LT768_Basic.LCD_DataWrite(WX);

  LT768_Basic.LCD_CmdWrite(0x69);
  LT768_Basic.LCD_DataWrite(WX>>8);

  LT768_Basic.LCD_CmdWrite(0x6A);
  LT768_Basic.LCD_DataWrite(HY);

  LT768_Basic.LCD_CmdWrite(0x6B);
  LT768_Basic.LCD_DataWrite(HY>>8);
}

void LT768Basic::Square_End_XY(unsigned short WX,unsigned short HY)
{
/*
[6Ch] Draw Line/Square/Triangle End X-coordination [7:0]
[6Dh] Draw Line/Square/Triangle End X-coordination [12:8]
[6Eh] Draw Line/Square/Triangle End Y-coordination [7:0]
[6Fh] Draw Line/Square/Triangle End Y-coordination [12:8]
*/
  LT768_Basic.LCD_CmdWrite(0x6C);
  LT768_Basic.LCD_DataWrite(WX);

  LT768_Basic.LCD_CmdWrite(0x6D);
  LT768_Basic.LCD_DataWrite(WX>>8);

  LT768_Basic.LCD_CmdWrite(0x6E);
  LT768_Basic.LCD_DataWrite(HY);

  LT768_Basic.LCD_CmdWrite(0x6F);
  LT768_Basic.LCD_DataWrite(HY>>8);
}
void LT768Basic::Check_Busy_Draw(void)
{
  unsigned char temp;
  do
  {
    temp=LT768_Basic.LCD_StatusRead();
  }
  while(temp&0x08);

}
void LT768Basic::Start_Square_Fill(void)
{
  LT768_Basic.LCD_CmdWrite(0x76);
  LT768_Basic.LCD_DataWrite(0xE0);//B1110_XXXX
  LT768_Basic.Check_Busy_Draw();
}
void LT768Basic::Check_2D_Busy(void)
{
  do
  {
    
  }
  while( LT768_Basic.LCD_StatusRead()&0x08 );
}



void LT768Basic::LT768_DrawSquare_Fill
(
 unsigned short X1                
,unsigned short Y1              
,unsigned short X2                
,unsigned short Y2              
,unsigned long ForegroundColor   
)
{
  LT768_Basic.Foreground_color_65k(ForegroundColor);
  LT768_Basic.Square_Start_XY(X1,Y1);
  LT768_Basic.Square_End_XY(X2,Y2);
  LT768_Basic.Start_Square_Fill();
  LT768_Basic.Check_2D_Busy();
}




void LT768Basic::Enable_SFlash_SPI(void)
{
/*  Serial Flash SPI Interface Enable/Disable
    0: Disable
    1: Enable*/
  unsigned char temp;
  LT768_Basic.LCD_CmdWrite(0x01);
  temp = LT768_Basic.LCD_DataRead();
  temp |= cSetb1;
  LT768_Basic.LCD_DataWrite(temp);     
}
void LT768Basic::Select_SFI_0(void)
{
/*[bit7]
Serial Flash/ROM I/F # Select
0: Serial Flash/ROM 0 I/F is selected.
1: Serial Flash/ROM 1 I/F is selected.
*/
  unsigned char temp;
  LT768_Basic.LCD_CmdWrite(0xB7);
  temp = LT768_Basic.LCD_DataRead();
    temp &= cClrb7;
  LT768_Basic.LCD_DataWrite(temp);
}
void LT768Basic::Select_SFI_1(void)
{
/*[bit7]
Serial Flash/ROM I/F # Select
0: Serial Flash/ROM 0 I/F is selected.
1: Serial Flash/ROM 1 I/F is selected.
*/
  unsigned char temp;
  LT768_Basic.LCD_CmdWrite(0xB7);
  temp = LT768_Basic.LCD_DataRead();
    temp |= cSetb7;
  LT768_Basic.LCD_DataWrite(temp);
}
void LT768Basic::Select_SFI_DMA_Mode(void)
{
/*[bit6]
Serial Flash /ROM Access Mode
0: Font mode �V for external cgrom
1: DMA mode �V for cgram , pattern , bootstart image or osd
*/
  unsigned char temp;
  LT768_Basic.LCD_CmdWrite(0xB7);
  temp = LT768_Basic.LCD_DataRead();
    temp |= cSetb6;
  LT768_Basic.LCD_DataWrite(temp);
}
void LT768Basic::SPI_Clock_Period(unsigned char temp)
{
   LT768_Basic.LCD_CmdWrite(0xBB);
   LT768_Basic.LCD_DataWrite(temp);
} 
void LT768Basic::Goto_Pixel_XY(unsigned short WX,unsigned short HY) 
{
/*
[Write]: Set Graphic Read/Write position
[Read]: Current Graphic Read/Write position
Read back is Read position or Write position depends on
REG[5Eh] bit3, Select to read back Graphic Read/Write position.
When DPRAM Linear mode:Graphic Read/Write Position [31:24][23:16][15:8][7:0]
When DPRAM Active window mode:Graphic Read/Write 
Horizontal Position [12:8][7:0], 
Vertical Position [12:8][7:0].
Reference Canvas image coordination. Unit: Pixel
*/
  LT768_Basic.LCD_RegisterWrite(0x5F,WX);
  LT768_Basic.LCD_RegisterWrite(0x60,WX>>8);
  
  LT768_Basic.LCD_RegisterWrite(0x61,HY);
  LT768_Basic.LCD_RegisterWrite(0x62,HY>>8);
}
void LT768Basic::SFI_DMA_Destination_Upper_Left_Corner(unsigned short WX,unsigned short HY)
{
/*
C0h
This register defines DMA Destination Window Upper-Left corner 
X-coordination [7:0] on Canvas area. 
When REG DMACR bit 1 = 1 (Block Mode) 
This register defines Destination address [7:2] in SDRAM. 
C1h
When REG DMACR bit 1 = 0 (Linear Mode) 
This register defines DMA Destination Window Upper-Left corner 
X-coordination [12:8] on Canvas area. 
When REG DMACR bit 1 = 1 (Block Mode) 
This register defines Destination address [15:8] in SDRAM.
C2h
When REG DMACR bit 1 = 0 (Linear Mode) 
This register defines DMA Destination Window Upper-Left corner
Y-coordination [7:0] on Canvas area. 
When REG DMACR bit 1 = 1 (Block Mode) 
This register defines Destination address [23:16] in SDRAM. 
C3h
When REG DMACR bit 1 = 0 (Linear Mode) 
This register defines DMA Destination Window Upper-Left corner 
Y-coordination [12:8] on Canvas area. 
When REG DMACR bit 1 = 1 (Block Mode) 
This register defines Destination address [31:24] in SDRAM. 
*/
 
  LT768_Basic.LCD_CmdWrite(0xC0);
  LT768_Basic.LCD_DataWrite(WX);
  LT768_Basic.LCD_CmdWrite(0xC1);
  LT768_Basic.LCD_DataWrite(WX>>8);
 
  LT768_Basic.LCD_CmdWrite(0xC2);
  LT768_Basic.LCD_DataWrite(HY);
  LT768_Basic.LCD_CmdWrite(0xC3);
  LT768_Basic.LCD_DataWrite(HY>>8);
}
void LT768Basic::SFI_DMA_Transfer_Width_Height(unsigned short WX,unsigned short HY)
{
/*
When REG DMACR bit 1 = 0 (Linear Mode)
DMA Transfer Number [7:0][15:8][23:16][31:24]

When REG DMACR bit 1 = 1 (Block Mode)
DMA Block Width [7:0][15:8]
DMA Block HIGH[7:0][15:8]
*/
  LT768_Basic.LCD_CmdWrite(0xC6);
  LT768_Basic.LCD_DataWrite(WX);
  LT768_Basic.LCD_CmdWrite(0xC7);
  LT768_Basic.LCD_DataWrite(WX>>8);

  LT768_Basic.LCD_CmdWrite(0xC8);
  LT768_Basic.LCD_DataWrite(HY);
  LT768_Basic.LCD_CmdWrite(0xC9);
  LT768_Basic.LCD_DataWrite(HY>>8);
}
void LT768Basic::SFI_DMA_Source_Width(unsigned short WX)
{
/*
DMA Source Picture Width [7:0][12:8]
Unit: pixel
*/
  LT768_Basic.LCD_CmdWrite(0xCA);
  LT768_Basic.LCD_DataWrite(WX);
  LT768_Basic.LCD_CmdWrite(0xCB);
  LT768_Basic.LCD_DataWrite(WX>>8);
}
void LT768Basic::SFI_DMA_Source_Start_Address(unsigned long Addr)
{
/*
DMA Source START ADDRESS
This bits index serial flash address [7:0][15:8][23:16][31:24]
*/
  LT768_Basic.LCD_CmdWrite(0xBC);
  LT768_Basic.LCD_DataWrite(Addr);
  LT768_Basic.LCD_CmdWrite(0xBD);
  LT768_Basic.LCD_DataWrite(Addr>>8);
  LT768_Basic.LCD_CmdWrite(0xBE);
  LT768_Basic.LCD_DataWrite(Addr>>16);
  LT768_Basic.LCD_CmdWrite(0xBF);
  LT768_Basic.LCD_DataWrite(Addr>>24);
}
void LT768Basic::Start_SFI_DMA(void)
{
  unsigned char temp;
  LT768_Basic.LCD_CmdWrite(0xB6);
  temp = LT768_Basic.LCD_DataRead();
    temp |= cSetb0;
  LT768_Basic.LCD_DataWrite(temp);
}
void LT768Basic::Check_Busy_SFI_DMA(void)
{
  LT768_Basic.LCD_CmdWrite(0xB6);
  do
  {   
  }while((LT768_Basic.LCD_DataRead()&0x01)==0x01);
}
void LT768Basic::LT768_DMA_24bit_Block
(
 unsigned char SCS         // Select SPI : SCS��0       SCS��1
,unsigned char Clk         // SPI Clock = System Clock /{(Clk+1)*2}
,unsigned short X1         // Transfer to SDRAM address:X1
,unsigned short Y1         // Transfer to SDRAM address:Y1
,unsigned short X_W        // DMA data width
,unsigned short Y_H        // DMA data height
,unsigned short P_W        // Picture's width
,unsigned long Addr        // Flash address
)
{
  LT768_Basic.Enable_SFlash_SPI();                            
  if(SCS == 0)  LT768_Basic.Select_SFI_0();                   // Select SPI0
  if(SCS == 1)  LT768_Basic.Select_SFI_1();                   // Select SPI1
	
  LT768_Basic.Memory_XY_Mode();                     
  LT768_Basic.Select_SFI_DMA_Mode();                          // Select SPI DMA mode
  LT768_Basic.SPI_Clock_Period(Clk);                          // Select SPI clock

  LT768_Basic.Goto_Pixel_XY(X1,Y1);                           // Setting the location of memory in the graphic mode
  LT768_Basic.SFI_DMA_Destination_Upper_Left_Corner(X1,Y1);   // DMA destination(SDRAM address)
  LT768_Basic.SFI_DMA_Transfer_Width_Height(X_W,Y_H);         // Setting Block data: width&height
  LT768_Basic.SFI_DMA_Source_Width(P_W);                      // Setting the width of the source data
  LT768_Basic.SFI_DMA_Source_Start_Address(Addr);             // Setting the FLASH address of the source data

  LT768_Basic.Start_SFI_DMA();                                
  LT768_Basic.Check_Busy_SFI_DMA();                        
}
void LT768Basic::MemWrite_Left_Right_Top_Down(void)
{
  unsigned char temp;
  LT768_Basic.LCD_CmdWrite(0x02);
  temp = LT768_Basic.LCD_DataRead();
  temp &= cClrb2;
  temp &= cClrb1;
  LT768_Basic.LCD_DataWrite(temp);
}
void LT768Basic::LT768_HW_Reset(void)
{
	pinMode(22, OUTPUT);
  digitalWrite(22, LOW);
  delay(500);
  digitalWrite(22, HIGH);
  delay(500);
}
void LT768Basic::System_Check_Temp(void)
{
  unsigned char i=0,j=0;
  unsigned char temp=0;
  unsigned char system_ok=0;
  do
  {
    j = LT768_Basic.LCD_StatusRead();
    if((j&0x02)==0x00)    
    {
      delay(2);                  //MCU too fast, necessary
      LT768_Basic.LCD_CmdWrite(0x01);
      delay(2);                  //MCU too fast, necessary
      temp = LT768_Basic.LCD_DataRead();
      if((temp & 0x80) == 0x80)       //Check CCR register's PLL is ready or not
      {
        system_ok=1;
        i=0;
      }
      else
      {
        delay(2); //MCU too fast, necessary
        LT768_Basic.LCD_CmdWrite(0x01);
        delay(2); //MCU too fast, necessary
        LT768_Basic.LCD_DataWrite(0x80);
      }
    }
    else
    {
      system_ok=0;
      i++;
    }
    if(system_ok==0 && i==5)
    {
      LT768_Basic.LT768_HW_Reset(); //note1
      i=0;
    }
  }while(system_ok==0);
}

void LT768Basic::LT768_PLL_Initial(void) 
{
	unsigned short lpllOD_sclk, lpllOD_cclk, lpllOD_mclk;
	unsigned short lpllR_sclk, lpllR_cclk, lpllR_mclk;
	unsigned short lpllN_sclk, lpllN_cclk, lpllN_mclk;

	//Fout = Fin*(N/R)/OD
	//Fout = 10*N/(2*5) = N
	lpllOD_sclk = 2;
	lpllOD_cclk = 2;
	lpllOD_mclk = 2;
	lpllR_sclk  = 5;
	lpllR_cclk  = 5;
	lpllR_mclk  = 5;
	lpllN_sclk  = 60;   // TFT PCLK out put frequency:65
	lpllN_cclk  = 100;    // Core CLK:100
	lpllN_mclk  = 100;    // SRAM CLK:100
	  
	LT768_Basic.LCD_CmdWrite(0x05);
	LT768_Basic.LCD_DataWrite((lpllOD_sclk<<6) | (lpllR_sclk<<1) | ((lpllN_sclk>>8)&0x1));
	LT768_Basic.LCD_CmdWrite(0x07);
	LT768_Basic.LCD_DataWrite((lpllOD_mclk<<6) | (lpllR_mclk<<1) | ((lpllN_mclk>>8)&0x1));
	LT768_Basic.LCD_CmdWrite(0x09);
	LT768_Basic.LCD_DataWrite((lpllOD_cclk<<6) | (lpllR_cclk<<1) | ((lpllN_cclk>>8)&0x1));

	LT768_Basic.LCD_CmdWrite(0x06);
	LT768_Basic.LCD_DataWrite(lpllN_sclk);
	LT768_Basic.LCD_CmdWrite(0x08);
	LT768_Basic.LCD_DataWrite(lpllN_mclk);
	LT768_Basic.LCD_CmdWrite(0x0a);
	LT768_Basic.LCD_DataWrite(lpllN_cclk);

	LT768_Basic.LCD_CmdWrite(0x00);
	delayMicroseconds(1);
	LT768_Basic.LCD_DataWrite(0x80);

	delay(1);
	
	//set pwm0 pwm1 100%
	LT768_Basic.LCD_CmdWrite(0x85);
	LT768_Basic.LCD_DataWrite(0x0a);
	LT768_Basic.LCD_CmdWrite(0x88);
	LT768_Basic.LCD_DataWrite(0x64);
	LT768_Basic.LCD_CmdWrite(0x8a);
	LT768_Basic.LCD_DataWrite(0x64);
	LT768_Basic.LCD_CmdWrite(0x8c);
	LT768_Basic.LCD_DataWrite(0x64);
	LT768_Basic.LCD_CmdWrite(0x8e);
	LT768_Basic.LCD_DataWrite(0x64);
	LT768_Basic.LCD_CmdWrite(0x86);
	LT768_Basic.LCD_DataWrite(0x33);
}


void LT768Basic::LT768_SDRAM_initail(void)
{
  unsigned short sdram_itv;
  
  LT768_Basic.LCD_RegisterWrite(0xe0,0x29);      
  LT768_Basic.LCD_RegisterWrite(0xe1,0x03); //CAS:2=0x02�ACAS:3=0x03
  sdram_itv = (64000000 / 8192) / (1000/60) ;
  sdram_itv-=2;

  LT768_Basic.LCD_RegisterWrite(0xe2,sdram_itv);
  LT768_Basic.LCD_RegisterWrite(0xe3,sdram_itv >>8);
  LT768_Basic.LCD_RegisterWrite(0xe4,0x01);
  LT768_Basic.Check_SDRAM_Ready();
  delay(1);
}


void LT768Basic::LT768_initial(void)
{

    LT768_Basic.LT768_PLL_Initial();
  
    LT768_Basic.LT768_SDRAM_initail();

//**[01h]**//
    LT768_Basic.TFT_16bit();
  LT768_Basic.Host_Bus_16bit(); //Host bus 16bit
      
//**[02h]**//
  LT768_Basic.RGB_16b_16bpp();
  LT768_Basic.MemWrite_Left_Right_Top_Down(); 
      
//**[03h]**//
  LT768_Basic.Graphic_Mode();
  LT768_Basic.Memory_Select_SDRAM();

  LT768_Basic.HSCAN_L_to_R();     //REG[12h]:from left to right
  LT768_Basic.VSCAN_T_to_B();       //REG[12h]:from top to bottom
  LT768_Basic.PDATA_Set_RGB();        //REG[12h]:Select RGB output

  LT768_Basic.Set_PCLK(LCD_PCLK_Falling_Rising);   //LCD_PCLK_Falling_Rising
  LT768_Basic.Set_HSYNC_Active(LCD_HSYNC_Active_Polarity);
  LT768_Basic.Set_VSYNC_Active(LCD_VSYNC_Active_Polarity);
  LT768_Basic.Set_DE_Active(LCD_DE_Active_Polarity);
 
  LT768_Basic.LCD_HorizontalWidth_VerticalHeight(LCD_XSIZE_TFT ,LCD_YSIZE_TFT);
  LT768_Basic.LCD_Horizontal_Non_Display(LCD_HBPD);                          
  LT768_Basic.LCD_HSYNC_Start_Position(LCD_HFPD);                              
  LT768_Basic.LCD_HSYNC_Pulse_Width(LCD_HSPW);                              
  LT768_Basic.LCD_Vertical_Non_Display(LCD_VBPD);                               
  LT768_Basic.LCD_VSYNC_Start_Position(LCD_VFPD);                               
  LT768_Basic.LCD_VSYNC_Pulse_Width(LCD_VSPW);                              
      
  LT768_Basic.Select_Main_Window_16bpp();

  LT768_Basic.Memory_XY_Mode(); //Block mode (X-Y coordination addressing)
  LT768_Basic.Memory_16bpp_Mode();
  LT768_Basic.Select_Main_Window_16bpp();
}
void LT768Basic::Display_ON(void)
{
/*  
Display ON/OFF
0b: Display Off.
1b: Display On.
*/
  unsigned char temp;
  
  LT768_Basic.LCD_CmdWrite(0x12);
  temp = LT768_Basic.LCD_DataRead();
  temp |= cSetb6;
  LT768_Basic.LCD_DataWrite(temp);
}
LT768Basic LT768_Basic=LT768Basic();
