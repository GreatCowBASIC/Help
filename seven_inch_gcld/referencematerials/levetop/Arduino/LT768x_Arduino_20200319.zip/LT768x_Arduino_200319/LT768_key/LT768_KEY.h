#ifndef LT768_KEY_h
#define LT768_KEY_h

#include "Arduino.h"
#include <SPI.h>

#define KEY1_PRES 1
#define KEY2_PRES 2

class LT768KEY
{
	private:
		
	public:
	void KEY_Init();
	unsigned char Scan_Key(void);
	void Waiting_Key(void);
	unsigned char Scan_Key_delay(unsigned int t);
	unsigned char Scan_FunctionKey(void);
};
extern LT768KEY LT768_KEY;
#endif
