#include "Arduino.h"
#include "LT768_KEY.h"
#include <SPI.h>

const int buttonPin1 = 2;
const int buttonPin2 = 3;
int KEY1 = 0,KEY2 = 0;

void LT768KEY::KEY_Init()
{
	pinMode(buttonPin1,INPUT);
  pinMode(buttonPin2,INPUT);
}
unsigned char LT768KEY::Scan_Key(void)
{
  static unsigned char key_up=1;//Button is not pressed
  KEY1 = digitalRead(buttonPin1);
  KEY2 = digitalRead(buttonPin2);
  if(key_up&&(KEY1==HIGH||KEY2==HIGH))
  {
    delay(10);//Eliminate jitter
    key_up=0;
    if(KEY1==HIGH)             return KEY1_PRES;
    else if(KEY2==HIGH)        return KEY2_PRES;
  }
  else if(KEY1==LOW&&KEY2==LOW)
  {
    key_up=1;
  }
  return 0;//No button pressed
}

void LT768KEY::Waiting_Key(void)
{
  unsigned char key = 0;
  do
  {
    key = LT768_KEY.Scan_Key();
  }
  while(key == 0);
}
unsigned char LT768KEY::Scan_Key_delay(unsigned int t)
{
  unsigned char key = 0;
  unsigned int i = 0;
  for(i = 0 ; i < t ; i++)
  {
    delay(1);
    key = LT768_KEY.Scan_Key();
    if(key == KEY1_PRES)  return 1;
    if(key == KEY2_PRES)  return 1;
  }
  return 0;
}
unsigned char LT768KEY::Scan_FunctionKey(void)
{
  unsigned char key = 0;
  unsigned char state1 = 0;
  unsigned char state2 = 0;
  unsigned int key1_count = 0;
  unsigned int key2_count = 0;

  while(1)
  {
    delay(1);
    key = LT768_KEY.Scan_Key();
    
    if((state1==0)&&(state2==0))
    {
      if((key == KEY1_PRES)||(key == KEY2_PRES))
      {
        if(key == KEY1_PRES)      state1 = 1;
        else if(key == KEY2_PRES) state2 = 1;
      }
    }
    
    if(state1 == 1)
    {
      if(KEY1 == HIGH)
      {
        key1_count++;
      }
      else
      {
        break;
      }
    }
    else if(state2 == 1)
    {
      if(KEY2 == HIGH)
      {
        key2_count++;
      }
      else
      {
        break;
      }
    }
  }
  
  if(key1_count >= 500)                       return 3;
  else if((key1_count>0) && (key1_count<500)) return 1;
  
  if(key2_count >= 500)                       return 3;
  else if((key2_count>0) && (key2_count<500)) return 2;
  
  return 0;
}
LT768KEY LT768_KEY=LT768KEY();