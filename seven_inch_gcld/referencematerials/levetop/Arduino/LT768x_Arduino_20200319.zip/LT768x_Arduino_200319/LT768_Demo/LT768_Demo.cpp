#include "Arduino.h"
#include "LT768_LCD.h"
#include "LT768.h"
#include "LT768_Lib.h"
#include "LT768_Demo.h"
#include "LT768_KEY.h"
#include <SPI.h>
#include <Wire.h>

const unsigned char gImage_pen_il[256] = { /* 0X00,0X02,0X20,0X00,0X20,0X00, */
0XAA,0XAA,0XAA,0XAA,0XAA,0XAA,0XAA,0XAA,0XAA,0XAA,0XAA,0XAA,0XAA,0XAA,0XAA,0XAA,
0X96,0XAA,0XAA,0XAA,0XAA,0XAA,0XAA,0XAA,0X91,0X6A,0XAA,0XAA,0XAA,0XAA,0XAA,0XAA,
0XA4,0X15,0XAA,0XAA,0XAA,0XAA,0XAA,0XAA,0XA4,0X00,0X6A,0XAA,0XAA,0XAA,0XAA,0XAA,
0XA9,0X01,0X1A,0XAA,0XAA,0XAA,0XAA,0XAA,0XA9,0X00,0X46,0XAA,0XAA,0XAA,0XAA,0XAA,
0XAA,0X40,0X51,0XAA,0XAA,0XAA,0XAA,0XAA,0XAA,0X90,0X14,0X6A,0XAA,0XAA,0XAA,0XAA,
0XAA,0XA4,0X05,0X1A,0XAA,0XAA,0XAA,0XAA,0XAA,0XA9,0X01,0X46,0XAA,0XAA,0XAA,0XAA,
0XAA,0XAA,0X40,0X51,0XAA,0XAA,0XAA,0XAA,0XAA,0XAA,0X90,0X14,0X6A,0XAA,0XAA,0XAA,
0XAA,0XAA,0XA4,0X05,0X1A,0XAA,0XAA,0XAA,0XAA,0XAA,0XA9,0X01,0X46,0XAA,0XAA,0XAA,
0XAA,0XAA,0XAA,0X40,0X51,0XAA,0XAA,0XAA,0XAA,0XAA,0XAA,0X90,0X14,0X69,0XAA,0XAA,
0XAA,0XAA,0XAA,0XA4,0X01,0X14,0X6A,0XAA,0XAA,0XAA,0XAA,0XA9,0X00,0X44,0X1A,0XAA,
0XAA,0XAA,0XAA,0XAA,0X40,0X11,0X06,0XAA,0XAA,0XAA,0XAA,0XAA,0X90,0X04,0X41,0XAA,
0XAA,0XAA,0XAA,0XAA,0XA4,0X01,0X10,0X6A,0XAA,0XAA,0XAA,0XAA,0XA9,0X00,0X44,0X1A,
0XAA,0XAA,0XAA,0XAA,0XAA,0X40,0X11,0X1A,0XAA,0XAA,0XAA,0XAA,0XAA,0X90,0X04,0X1A,
0XAA,0XAA,0XAA,0XAA,0XAA,0XA4,0X01,0X1A,0XAA,0XAA,0XAA,0XAA,0XAA,0XA9,0X00,0X1A,
0XAA,0XAA,0XAA,0XAA,0XAA,0XAA,0X40,0X6A,0XAA,0XAA,0XAA,0XAA,0XAA,0XAA,0X95,0XAA,
0XAA,0XAA,0XAA,0XAA,0XAA,0XAA,0XAA,0XAA,0XAA,0XAA,0XAA,0XAA,0XAA,0XAA,0XAA,0XAA,
};

const unsigned char gImage_arrow_il[256] = { /* 0X00,0X02,0X20,0X00,0X20,0X00, */
0XAA,0XAA,0XAA,0XAA,0XAA,0XAA,0XAA,0XAA,0X6A,0XAA,0XAA,0XAA,0XAA,0XAA,0XAA,0XAA,
0X5A,0XAA,0XAA,0XAA,0XAA,0XAA,0XAA,0XAA,0X46,0XAA,0XAA,0XAA,0XAA,0XAA,0XAA,0XAA,
0X41,0XAA,0XAA,0XAA,0XAA,0XAA,0XAA,0XAA,0X40,0X6A,0XAA,0XAA,0XAA,0XAA,0XAA,0XAA,
0X40,0X1A,0XAA,0XAA,0XAA,0XAA,0XAA,0XAA,0X40,0X06,0XAA,0XAA,0XAA,0XAA,0XAA,0XAA,
0X40,0X01,0XAA,0XAA,0XAA,0XAA,0XAA,0XAA,0X40,0X00,0X6A,0XAA,0XAA,0XAA,0XAA,0XAA,
0X40,0X00,0X1A,0XAA,0XAA,0XAA,0XAA,0XAA,0X40,0X00,0X06,0XAA,0XAA,0XAA,0XAA,0XAA,
0X40,0X00,0X01,0XAA,0XAA,0XAA,0XAA,0XAA,0X40,0X00,0X00,0X6A,0XAA,0XAA,0XAA,0XAA,
0X40,0X00,0X00,0X1A,0XAA,0XAA,0XAA,0XAA,0X40,0X00,0X00,0X06,0XAA,0XAA,0XAA,0XAA,
0X40,0X00,0X00,0X01,0XAA,0XAA,0XAA,0XAA,0X40,0X00,0X00,0X00,0X6A,0XAA,0XAA,0XAA,
0X40,0X00,0X15,0X55,0X5A,0XAA,0XAA,0XAA,0X40,0X10,0X1A,0XAA,0XAA,0XAA,0XAA,0XAA,
0X40,0X64,0X06,0XAA,0XAA,0XAA,0XAA,0XAA,0X41,0XA4,0X06,0XAA,0XAA,0XAA,0XAA,0XAA,
0X46,0XA9,0X01,0XAA,0XAA,0XAA,0XAA,0XAA,0X5A,0XA9,0X01,0XAA,0XAA,0XAA,0XAA,0XAA,
0X6A,0XAA,0X40,0X6A,0XAA,0XAA,0XAA,0XAA,0XAA,0XAA,0X40,0X6A,0XAA,0XAA,0XAA,0XAA,
0XAA,0XAA,0X90,0X1A,0XAA,0XAA,0XAA,0XAA,0XAA,0XAA,0X90,0X1A,0XAA,0XAA,0XAA,0XAA,
0XAA,0XAA,0XA4,0X06,0XAA,0XAA,0XAA,0XAA,0XAA,0XAA,0XA4,0X06,0XAA,0XAA,0XAA,0XAA,
0XAA,0XAA,0XA9,0X5A,0XAA,0XAA,0XAA,0XAA,0XAA,0XAA,0XAA,0XAA,0XAA,0XAA,0XAA,0XAA,
};

const unsigned char gImage_busy_im[256] = { /* 0X00,0X02,0X20,0X00,0X20,0X00, */
0XAA,0XAA,0XAA,0XAA,0XAA,0XAA,0XAA,0XAA,0XAA,0XAA,0XAA,0XAA,0XAA,0XAA,0XAA,0XAA,
0XAA,0XAA,0XAA,0XAA,0XAA,0XAA,0XAA,0XAA,0XAA,0XAA,0X55,0X55,0X55,0X55,0X6A,0XAA,
0XAA,0XAA,0X54,0X00,0X00,0X05,0X6A,0XAA,0XAA,0XAA,0X55,0X55,0X55,0X55,0X6A,0XAA,
0XAA,0XAA,0X94,0X00,0X00,0X05,0XAA,0XAA,0XAA,0XAA,0X94,0X00,0X00,0X05,0XAA,0XAA,
0XAA,0XAA,0X94,0X44,0X44,0X45,0XAA,0XAA,0XAA,0XAA,0X94,0X11,0X11,0X05,0XAA,0XAA,
0XAA,0XAA,0X95,0X04,0X44,0X15,0XAA,0XAA,0XAA,0XAA,0XA5,0X41,0X10,0X56,0XAA,0XAA,
0XAA,0XAA,0XA9,0X50,0X41,0X5A,0XAA,0XAA,0XAA,0XAA,0XAA,0X54,0X05,0X6A,0XAA,0XAA,
0XAA,0XAA,0XAA,0X94,0X05,0XAA,0XAA,0XAA,0XAA,0XAA,0XAA,0X94,0X05,0XAA,0XAA,0XAA,
0XAA,0XAA,0XAA,0X94,0X45,0XAA,0XAA,0XAA,0XAA,0XAA,0XAA,0X94,0X05,0XAA,0XAA,0XAA,
0XAA,0XAA,0XAA,0X50,0X01,0X6A,0XAA,0XAA,0XAA,0XAA,0XA9,0X40,0X40,0X5A,0XAA,0XAA,
0XAA,0XAA,0XA5,0X00,0X10,0X16,0XAA,0XAA,0XAA,0XAA,0X94,0X00,0X00,0X05,0XAA,0XAA,
0XAA,0XAA,0X94,0X04,0X44,0X05,0XAA,0XAA,0XAA,0XAA,0X94,0X11,0X11,0X05,0XAA,0XAA,
0XAA,0XAA,0X94,0X44,0X44,0X45,0XAA,0XAA,0XAA,0XAA,0X95,0X11,0X11,0X15,0XAA,0XAA,
0XAA,0XAA,0X55,0X55,0X55,0X55,0X6A,0XAA,0XAA,0XAA,0X54,0X00,0X00,0X05,0X6A,0XAA,
0XAA,0XAA,0X55,0X55,0X55,0X55,0X6A,0XAA,0XAA,0XAA,0XAA,0XAA,0XAA,0XAA,0XAA,0XAA,
0XAA,0XAA,0XAA,0XAA,0XAA,0XAA,0XAA,0XAA,0XAA,0XAA,0XAA,0XAA,0XAA,0XAA,0XAA,0XAA,
};

const unsigned char gImage_no_im[256] = { /* 0X00,0X02,0X20,0X00,0X20,0X00, */
0XAA,0XAA,0XAA,0XAA,0XAA,0XAA,0XAA,0XAA,0XAA,0XAA,0XAA,0XAA,0XAA,0XAA,0XAA,0XAA,
0XAA,0XAA,0XAA,0XAA,0XAA,0XAA,0XAA,0XAA,0XAA,0XAA,0XAA,0X95,0X55,0XAA,0XAA,0XAA,
0XAA,0XAA,0XA9,0X40,0X00,0X5A,0XAA,0XAA,0XAA,0XAA,0X94,0X00,0X00,0X05,0XAA,0XAA,
0XAA,0XAA,0X40,0X00,0X00,0X00,0X6A,0XAA,0XAA,0XA9,0X00,0X15,0X55,0X00,0X1A,0XAA,
0XAA,0XA4,0X00,0X6A,0XAA,0X50,0X06,0XAA,0XAA,0XA4,0X00,0X6A,0XAA,0XA4,0X06,0XAA,
0XAA,0X90,0X00,0X1A,0XAA,0XA9,0X01,0XAA,0XAA,0X90,0X10,0X06,0XAA,0XA9,0X01,0XAA,
0XAA,0X40,0X64,0X01,0XAA,0XAA,0X40,0X6A,0XAA,0X40,0X69,0X00,0X6A,0XAA,0X40,0X6A,
0XAA,0X40,0X6A,0X40,0X1A,0XAA,0X40,0X6A,0XAA,0X40,0X6A,0X90,0X06,0XAA,0X40,0X6A,
0XAA,0X40,0X6A,0XA4,0X01,0XAA,0X40,0X6A,0XAA,0X40,0X6A,0XA9,0X00,0X6A,0X40,0X6A,
0XAA,0X40,0X6A,0XAA,0X40,0X1A,0X40,0X6A,0XAA,0X90,0X1A,0XAA,0X90,0X05,0X01,0XAA,
0XAA,0X90,0X1A,0XAA,0XA4,0X00,0X01,0XAA,0XAA,0XA4,0X06,0XAA,0XA9,0X00,0X06,0XAA,
0XAA,0XA4,0X01,0X6A,0XAA,0X40,0X06,0XAA,0XAA,0XA9,0X00,0X15,0X55,0X00,0X1A,0XAA,
0XAA,0XAA,0X40,0X00,0X00,0X00,0X6A,0XAA,0XAA,0XAA,0X94,0X00,0X00,0X05,0XAA,0XAA,
0XAA,0XAA,0XA9,0X40,0X00,0X5A,0XAA,0XAA,0XAA,0XAA,0XAA,0X95,0X55,0XAA,0XAA,0XAA,
0XAA,0XAA,0XAA,0XAA,0XAA,0XAA,0XAA,0XAA,0XAA,0XAA,0XAA,0XAA,0XAA,0XAA,0XAA,0XAA,
0XAA,0XAA,0XAA,0XAA,0XAA,0XAA,0XAA,0XAA,0XAA,0XAA,0XAA,0XAA,0XAA,0XAA,0XAA,0XAA,
};

void LT768Demo::StartUp_picture(void)
{
  LT768.Select_Main_Window_16bpp();
  LT768.Main_Image_Start_Address(layer1_start_addr);        
  LT768.Main_Image_Width(LCD_XSIZE_TFT);
  LT768.Main_Window_Start_XY(0,0);
  LT768.Canvas_Image_Start_address(layer1_start_addr);
  LT768.Canvas_image_width(LCD_XSIZE_TFT);
  LT768.Active_Window_XY(0,0);
  LT768.Active_Window_WH(LCD_XSIZE_TFT,LCD_YSIZE_TFT);
  LT768_Lib.LT768_DMA_24bit_Block(1,0,0,0,LCD_XSIZE_TFT,LCD_YSIZE_TFT,LCD_XSIZE_TFT,Picture_1_Addr);
}


void LT768Demo::Display_Levetop(void)
{
  LT768.Select_Main_Window_16bpp();
  LT768.Main_Image_Start_Address(layer2_start_addr);                
  LT768.Main_Image_Width(LCD_XSIZE_TFT);
  LT768.Canvas_Image_Start_address(layer2_start_addr);              
  LT768.Canvas_image_width(LCD_XSIZE_TFT);                 
  LT768.Active_Window_XY(0,0);
  LT768.Active_Window_WH(LCD_XSIZE_TFT,LCD_YSIZE_TFT);     
  LT768.Main_Window_Start_XY(0,0);               
  
  LT768_Lib.LT768_DMA_24bit_Block(1,0,0,0,LCD_XSIZE_TFT,LCD_YSIZE_TFT,LCD_XSIZE_TFT,Picture_2_Addr);
  LT768_KEY.Waiting_Key();
}


unsigned char LT768Demo::Draw_Circle_Ellipse(void)
{
  unsigned long i,j,h,c,z;
  unsigned long resx1,resy1;

  LT768.Select_Main_Window_16bpp();
  LT768.Main_Image_Start_Address(layer2_start_addr);         
  LT768.Main_Image_Width(LCD_XSIZE_TFT);
  LT768.Canvas_Image_Start_address(layer2_start_addr);       
  LT768.Canvas_image_width(LCD_XSIZE_TFT);                   
  LT768.Active_Window_XY(0,0);
  LT768.Active_Window_WH(LCD_XSIZE_TFT,LCD_YSIZE_TFT);       
  
  LT768.Main_Window_Start_XY(0,0);                           
  
  while(1)
  {
    //--------------------- Circle ------------------------
    LT768_Lib.LT768_DrawSquare_Fill(0,0,LCD_XSIZE_TFT,LCD_YSIZE_TFT,White);
    h=0;
    do
    {
      i=rand()%65536;                  //color
      resx1=rand()%LCD_XSIZE_TFT;      
      resy1=rand()%(LCD_YSIZE_TFT-24); 
      z=rand()%200;                    
      j=rand()%3;
      if(j) LT768_Lib.LT768_DrawCircle(resx1,resy1,z,i);        
      else  LT768_Lib.LT768_DrawCircle_Fill(resx1,resy1,z,i);   
      h++;
      if(LT768_KEY.Scan_Key_delay(120)) return 1;
    }
    while(h<20);

    h=0;
    do
    {
      i=rand()%65536;                  // color
      resx1=rand()%LCD_XSIZE_TFT;     
      resy1=rand()%(LCD_YSIZE_TFT-24); 
      z=rand()%200;                    
      j=rand()%3;
      if(j) LT768_Lib.LT768_DrawCircle(resx1,resy1,z,i);        
      else  LT768_Lib.LT768_DrawCircle_Fill(resx1,resy1,z,i);   
      h++;
      delay(1);
      if(LT768_KEY.Scan_Key() != 0) return 1;
    }
    while(h<2500);

    //--------------------- Ellipse ------------------------
    LT768_Lib.LT768_DrawSquare_Fill(0,0,LCD_XSIZE_TFT,LCD_YSIZE_TFT,White);
    h=0;
    do
    {
      i=rand()%65536;                  // color
      resx1=rand()%LCD_XSIZE_TFT;      
      resy1=rand()%(LCD_YSIZE_TFT-24); 
      z=rand()%200;                    
      c=rand()%200;                    
      j=rand()%3;
      if(j) LT768_Lib.LT768_DrawEllipse(resx1,resy1,z,c,i);        
      else  LT768_Lib.LT768_DrawEllipse_Fill(resx1,resy1,z,c,i);   
      h++;
      if(LT768_KEY.Scan_Key_delay(120)) return 1;
    }
    while(h<20);

    do
    {
      i=rand()%65536;                  // color
      resx1=rand()%LCD_XSIZE_TFT;      
      resy1=rand()%(LCD_YSIZE_TFT-24);
      z=rand()%200;                    
      c=rand()%200;                   
      j=rand()%3;
      if(j) LT768_Lib.LT768_DrawEllipse(resx1,resy1,z,c,i);       
      else  LT768_Lib.LT768_DrawEllipse_Fill(resx1,resy1,z,c,i);   
      h++;
      delay(1);
      if(LT768_KEY.Scan_Key() != 0) return 1;
    }
    while(h<2500);
  }
}

unsigned char LT768Demo::Draw_Line_Curve(void)
{
  unsigned long i,j,h,z,d,w;
  unsigned long resx1,resy1,resx2,resy2;

  LT768.Select_Main_Window_16bpp();
  LT768.Main_Image_Start_Address(layer2_start_addr);         
  LT768.Main_Image_Width(LCD_XSIZE_TFT);
  LT768.Canvas_Image_Start_address(layer2_start_addr);       
  LT768.Canvas_image_width(LCD_XSIZE_TFT);                   
  LT768.Active_Window_XY(0,0);
  LT768.Active_Window_WH(LCD_XSIZE_TFT,LCD_YSIZE_TFT);       
  
  LT768.Main_Window_Start_XY(0,0);                          

  while(1)
  {
    //----------------------- Line ------------------------
    LT768_Lib.LT768_DrawSquare_Fill(0,0,LCD_XSIZE_TFT,LCD_YSIZE_TFT,White);
    h=0;
    do
    {
      resx1=rand()%LCD_XSIZE_TFT;       
      resy1=rand()%(LCD_YSIZE_TFT);     
      resx2=rand()%LCD_XSIZE_TFT;       
      resy2=rand()%(LCD_YSIZE_TFT);     
      i=rand()%65536;// color
      w=rand()%20;

      LT768_Lib.LT768_DrawLine_Width(resx1,resy1+w,resx2,resy2+w,i,w);

      h++;
      if(LT768_KEY.Scan_Key_delay(120)) return 1;
    }
    while(h<20);

    h=0;
    do
    {
      resx1=rand()%LCD_XSIZE_TFT;       
      resy1=rand()%(LCD_YSIZE_TFT);    
      resx2=rand()%LCD_XSIZE_TFT;       
      resy2=rand()%(LCD_YSIZE_TFT);     
      i=rand()%65536;// color
      w=rand()%20;

      LT768_Lib.LT768_DrawLine_Width(resx1,resy1+w,resx2,resy2+w,i,w);

      h++;
      if(LT768_KEY.Scan_Key() != 0) return 1;
    }
    while(h<2500);
    
    //----------------------- Curve ------------------------
    
    LT768_Lib.LT768_DrawSquare_Fill(0,0,LCD_XSIZE_TFT,LCD_YSIZE_TFT,White);
    
    h=0;
    do
    {
      i=rand()%65536;                  
      resx1=rand()%LCD_XSIZE_TFT;      
      resy1=rand()%(LCD_YSIZE_TFT);    
      z=rand()%150;                    
      d=rand()%4;                      
      j=rand()%3;

      switch(d)
      {
        case 0:
            if(z>resx1) resx1 = 150;
            if(z>(600-resy1)) resy1 = 450;
            break;
        case 1:
            if(z>resx1) resx1 = 150;
            if(z>resy1) resy1 = 150;
            break;
        case 2:
            if(z>(1024-resx1))  resx1 = 875;
            if(z>resy1) resy1 = 150;
            break;
        case 3:
            if(z>(1024-resx1))  resx1 = 875;
            if(z>(600-resy1)) resy1 = 450;
            break;
        default:
            break;
      }

      if(j)   LT768_Lib.LT768_SelectDrawCurve(resx1,resy1,z,z,i,d);      
      else    LT768_Lib.LT768_SelectDrawCurve_Fill(resx1,resy1,z,z,i,d); 
      h++;
      if(LT768_KEY.Scan_Key_delay(120)) return 1;
    }
    while(h<20);

    h=0;
    do
    {
      i=rand()%65536;                   //color
      resx1=rand()%(LCD_XSIZE_TFT-150); 
      resy1=rand()%(LCD_YSIZE_TFT-150); 
      z=rand()%150;                     
      d=rand()%4;                       // dir
      j=rand()%3;

      switch(d)
      {
        case 0:
            if(z>resx1) resx1 = 150;
            if(z>(600-resy1)) resy1 = 450;
            break;
        case 1:
            if(z>resx1) resx1 = 150;
            if(z>resy1) resy1 = 150;
            break;
        case 2:
            if(z>(1024-resx1))  resx1 = 875;
            if(z>resy1) resy1 = 150;
            break;
        case 3:
            if(z>(1024-resx1))  resx1 = 875;
            if(z>(600-resy1)) resy1 = 450;
            break;
        default:
            break;
      }

      if(j)   LT768_Lib.LT768_SelectDrawCurve(resx1,resy1,z,z,i,d);      
      else    LT768_Lib.LT768_SelectDrawCurve_Fill(resx1,resy1,z,z,i,d); 
      h++;
      delay(1);
      if(LT768_KEY.Scan_Key() != 0) return 1;
    }
    while(h<2500);
  }
}

unsigned short LT768Demo::abs1(int val)
{
  if(val<0) val = -val;
  return val;
}

unsigned char LT768Demo::Draw_Rectangle(void)
{
  unsigned long i,j,h,z;
  unsigned long resx1,resy1,resx2,resy2;

  LT768.Select_Main_Window_16bpp();
  LT768.Main_Image_Start_Address(layer2_start_addr);        
  LT768.Main_Image_Width(LCD_XSIZE_TFT);
  LT768.Canvas_Image_Start_address(layer2_start_addr);       
  LT768.Canvas_image_width(LCD_XSIZE_TFT);                 
  LT768.Active_Window_XY(0,0);
  LT768.Active_Window_WH(LCD_XSIZE_TFT,LCD_YSIZE_TFT);    
  
  LT768.Main_Window_Start_XY(0,0);                         

  while(1)
  {
    // ---------------------------- Square -----------------------------
    LT768_Lib.LT768_DrawSquare_Fill(0,0,LCD_XSIZE_TFT,LCD_YSIZE_TFT,White);
    h=0;
    do
    {
      resx1=rand()%LCD_XSIZE_TFT;       
      resy1=rand()%(LCD_YSIZE_TFT);  
      resx2=rand()%LCD_XSIZE_TFT;       
      resy2=rand()%(LCD_YSIZE_TFT);  
      i=rand()%65536;                 
      j=rand()%3;
      if(j) LT768_Lib.LT768_DrawSquare(resx1,resy1,resx2,resy2,i);       
      else  LT768_Lib.LT768_DrawSquare_Fill(resx1,resy1,resx2,resy2,i);   
      h++;
      if(LT768_KEY.Scan_Key_delay(120)) return 1;
    }
    while(h<20);

    h=0;
    do
    {
      resx1=rand()%LCD_XSIZE_TFT;       
      resy1=rand()%(LCD_YSIZE_TFT);   
      resx2=rand()%LCD_XSIZE_TFT;       
      resy2=rand()%(LCD_YSIZE_TFT);    
      i=rand()%65536;                 
      j=rand()%3;
      if(j) LT768_Lib.LT768_DrawSquare(resx1,resy1,resx2,resy2,i);      
      else  LT768_Lib.LT768_DrawSquare_Fill(resx1,resy1,resx2,resy2,i);   
      h++;
      delay(1);
      if(LT768_KEY.Scan_Key() != 0) return 1;
    }
    while(h<2500);
    
    // ---------------------------- CircleSquare -----------------------------
    LT768_Lib.LT768_DrawSquare_Fill(0,0,LCD_XSIZE_TFT,LCD_YSIZE_TFT,White);
    h=0;
    do
    {
      resx1=rand()%(LCD_XSIZE_TFT-10);        
      resy1=rand()%(LCD_YSIZE_TFT-10);       
      resx2=rand()%(LCD_XSIZE_TFT-10);        
      resy2=rand()%(LCD_YSIZE_TFT-10);       
      i=rand()%65536;                         
      j=rand()%3;
      z=rand()%50;                        

      if(abs1(resx2-resx1)<(2*z)) z = 0;
      if(abs1(resy2-resy1)<(2*z)) z = 0;

      if(j) LT768_Lib.LT768_DrawCircleSquare(resx1,resy1,resx2,resy2,z,z,i);
      else  LT768_Lib.LT768_DrawCircleSquare_Fill(resx1,resy1,resx2,resy2,z,z,i);
      h++;
      if(LT768_KEY.Scan_Key_delay(120)) return 1;
    }
    while(h<20);

    h=0;
    do
    {
      resx1=rand()%(LCD_XSIZE_TFT-10);       
      resy1=rand()%(LCD_YSIZE_TFT-10);    
      resx2=rand()%(LCD_XSIZE_TFT-10);      
      resy2=rand()%(LCD_YSIZE_TFT-10);    
      i=rand()%65536;                        
      j=rand()%3;
      z=rand()%50;                     

      if(abs1(resx2-resx1)<(2*z)) z = 0;
      if(abs1(resy2-resy1)<(2*z)) z = 0;

      if(j) LT768_Lib.LT768_DrawCircleSquare(resx1,resy1,resx2,resy2,z,z,i);
      else  LT768_Lib.LT768_DrawCircleSquare_Fill(resx1,resy1,resx2,resy2,z,z,i);
      h++;
      delay(1);
      if(LT768_KEY.Scan_Key() != 0) return 1;
    }
    while(h<2500);
  }
}


unsigned char LT768Demo::Draw_Pentagon(void)
{
  unsigned char j = 0;
  unsigned long i,h;
  unsigned long resx1,resy1,resx2,resy2,resx3,resy3,resx4,resy4,resx5,resy5;
  
  LT768.Select_Main_Window_16bpp();
  LT768.Main_Image_Start_Address(layer2_start_addr);         
  LT768.Main_Image_Width(LCD_XSIZE_TFT);
  LT768.Canvas_Image_Start_address(layer2_start_addr);       
  LT768.Canvas_image_width(LCD_XSIZE_TFT);                   
  LT768.Active_Window_XY(0,0);
  LT768.Active_Window_WH(LCD_XSIZE_TFT,LCD_YSIZE_TFT);       
  
  LT768.Main_Window_Start_XY(0,0);                           

  while(1)
  {
    LT768_Lib.LT768_DrawSquare_Fill(0,0,LCD_XSIZE_TFT,LCD_YSIZE_TFT,White);
    h=0;
    do
    {
      resx1=rand()%LCD_XSIZE_TFT;       
      resy1=rand()%(LCD_YSIZE_TFT);     
      resx2=rand()%LCD_XSIZE_TFT;       
      resy2=rand()%(LCD_YSIZE_TFT);     
      resx3=rand()%LCD_XSIZE_TFT;       
      resy3=rand()%(LCD_YSIZE_TFT);     
      resx4=rand()%LCD_XSIZE_TFT;       
      resy4=rand()%(LCD_YSIZE_TFT);     
      resx5=rand()%LCD_XSIZE_TFT;       
      resy5=rand()%(LCD_YSIZE_TFT);     
      i=rand()%65536;// color
      j=rand()%3;

      if(j) LT768_Lib.LT768_DrawPentagon(resx1,resy1,resx2,resy2,resx3,resy3,resx4,resy4,resx5,resy5,i);        
      else  LT768_Lib.LT768_DrawPentagon_Fill(resx1,resy1,resx2,resy2,resx3,resy3,resx4,resy4,resx5,resy5,i);   

      h++;
      if(LT768_KEY.Scan_Key_delay(120)) return 1;
    }
    while(h<20);

    h=0;
    do
    {
      resx1=rand()%LCD_XSIZE_TFT;       
      resy1=rand()%(LCD_YSIZE_TFT);     
      resx2=rand()%LCD_XSIZE_TFT;       
      resy2=rand()%(LCD_YSIZE_TFT);     
      resx3=rand()%LCD_XSIZE_TFT;       
      resy3=rand()%(LCD_YSIZE_TFT);     
      resx4=rand()%LCD_XSIZE_TFT;       
      resy4=rand()%(LCD_YSIZE_TFT);     
      resx5=rand()%LCD_XSIZE_TFT;       
      resy5=rand()%(LCD_YSIZE_TFT);     
      i=rand()%65536;// color
      j=rand()%3;

      if(j) LT768_Lib.LT768_DrawPentagon(resx1,resy1,resx2,resy2,resx3,resy3,resx4,resy4,resx5,resy5,i);        
      else  LT768_Lib.LT768_DrawPentagon_Fill(resx1,resy1,resx2,resy2,resx3,resy3,resx4,resy4,resx5,resy5,i);   

      h++;
      delay(1);
      if(LT768_KEY.Scan_Key() != 0) return 1;
    }
    while(h<2500);
  }
}



unsigned char LT768Demo::Draw_Triangle(void)
{
  unsigned long i,j,h;
  unsigned long resx1,resy1,resx2,resy2,resx3,resy3;

  LT768.Select_Main_Window_16bpp();
  LT768.Main_Image_Start_Address(layer2_start_addr);         
  LT768.Main_Image_Width(LCD_XSIZE_TFT);
  LT768.Canvas_Image_Start_address(layer2_start_addr);       
  LT768.Canvas_image_width(LCD_XSIZE_TFT);                   
  LT768.Active_Window_XY(0,0);
  LT768.Active_Window_WH(LCD_XSIZE_TFT,LCD_YSIZE_TFT);       
  
  LT768.Main_Window_Start_XY(0,0);                           

  while(1)
  {
    LT768_Lib.LT768_DrawSquare_Fill(0,0,LCD_XSIZE_TFT,LCD_YSIZE_TFT,White);
    h=0;
    do
    {
      resx1=rand()%LCD_XSIZE_TFT;       
      resy1=rand()%(LCD_YSIZE_TFT);     
      resx2=rand()%LCD_XSIZE_TFT;       
      resy2=rand()%(LCD_YSIZE_TFT);     
      resx3=rand()%LCD_XSIZE_TFT;       
      resy3=rand()%(LCD_YSIZE_TFT);  
      i=rand()%65536;//color
      j=rand()%3;
      if(j) LT768_Lib.LT768_DrawTriangle(resx1,resy1,resx2,resy2,resx3,resy3,i);      
      else  LT768_Lib.LT768_DrawTriangle_Fill(resx1,resy1,resx2,resy2,resx3,resy3,i); 
      h++;
      if(LT768_KEY.Scan_Key_delay(120)) return 1;
    }
    while(h<20);

    h=0;
    do
    {
      resx1=rand()%LCD_XSIZE_TFT;       
      resy1=rand()%(LCD_YSIZE_TFT);     
      resx2=rand()%LCD_XSIZE_TFT;       
      resy2=rand()%(LCD_YSIZE_TFT);     
      resx3=rand()%LCD_XSIZE_TFT;       
      resy3=rand()%(LCD_YSIZE_TFT);  
      i=rand()%65536;//color
      j=rand()%3;
      if(j) LT768_Lib.LT768_DrawTriangle(resx1,resy1,resx2,resy2,resx3,resy3,i);      
      else  LT768_Lib.LT768_DrawTriangle_Fill(resx1,resy1,resx2,resy2,resx3,resy3,i); 
      h++;
      delay(1);
      if(LT768_KEY.Scan_Key() != 0) return 1;
    }
    while(h<2500);

  }
}


unsigned char LT768Demo::Draw_Polygon(void)
{
  unsigned char j = 0;
  unsigned long i,h;
  unsigned long resx1,resy1,resx2,resy2,resx3,resy3,resx4,resy4,resx5,resy5;
  
  LT768.Select_Main_Window_16bpp();
  LT768.Main_Image_Start_Address(layer2_start_addr);         
  LT768.Main_Image_Width(LCD_XSIZE_TFT);
  LT768.Canvas_Image_Start_address(layer2_start_addr);       
  LT768.Canvas_image_width(LCD_XSIZE_TFT);                   
  LT768.Active_Window_XY(0,0);
  LT768.Active_Window_WH(LCD_XSIZE_TFT,LCD_YSIZE_TFT);       
  
  LT768.Main_Window_Start_XY(0,0);                           

  while(1)
  {
    LT768_Lib.LT768_DrawSquare_Fill(0,0,LCD_XSIZE_TFT,LCD_YSIZE_TFT,White);
    h=0;
    do
    {
      resx1=rand()%LCD_XSIZE_TFT;       
      resy1=rand()%(LCD_YSIZE_TFT);     
      resx2=rand()%LCD_XSIZE_TFT;       
      resy2=rand()%(LCD_YSIZE_TFT);     
      resx3=rand()%LCD_XSIZE_TFT;       
      resy3=rand()%(LCD_YSIZE_TFT);     
      resx4=rand()%LCD_XSIZE_TFT;       
      resy4=rand()%(LCD_YSIZE_TFT);     
      resx5=rand()%LCD_XSIZE_TFT;       
      resy5=rand()%(LCD_YSIZE_TFT);     
      i=rand()%65536;// color
      j=rand()%3;

      if(j) LT768_Lib.LT768_DrawPentagon(resx1,resy1,resx2,resy2,resx3,resy3,resx4,resy4,resx5,resy5,i);        
      else  LT768_Lib.LT768_DrawPentagon_Fill(resx1,resy1,resx2,resy2,resx3,resy3,resx4,resy4,resx5,resy5,i);   

      h++;
      if(LT768_KEY.Scan_Key_delay(120)) return 1;
    }
    while(h<20);

    h=0;
    do
    {
      resx1=rand()%LCD_XSIZE_TFT;       
      resy1=rand()%(LCD_YSIZE_TFT);     
      resx2=rand()%LCD_XSIZE_TFT;       
      resy2=rand()%(LCD_YSIZE_TFT);     
      resx3=rand()%LCD_XSIZE_TFT;       
      resy3=rand()%(LCD_YSIZE_TFT);     
      resx4=rand()%LCD_XSIZE_TFT;       
      resy4=rand()%(LCD_YSIZE_TFT);     
      resx5=rand()%LCD_XSIZE_TFT;       
      resy5=rand()%(LCD_YSIZE_TFT);     
      i=rand()%65536;// color
      j=rand()%3;

      if(j) LT768_Lib.LT768_DrawPentagon(resx1,resy1,resx2,resy2,resx3,resy3,resx4,resy4,resx5,resy5,i);        
      else  LT768_Lib.LT768_DrawPentagon_Fill(resx1,resy1,resx2,resy2,resx3,resy3,resx4,resy4,resx5,resy5,i);   

      h++;
      delay(1);
      if(LT768_KEY.Scan_Key() != 0) return 1;
    }
    while(h<1500);
    
    LT768_Lib.LT768_DrawSquare_Fill(0,0,LCD_XSIZE_TFT,LCD_YSIZE_TFT,White);
    h=0;
    do
    {
      resx1=rand()%LCD_XSIZE_TFT;       
      resy1=rand()%(LCD_YSIZE_TFT);     
      resx2=rand()%LCD_XSIZE_TFT;       
      resy2=rand()%(LCD_YSIZE_TFT);     
      resx3=rand()%LCD_XSIZE_TFT;       
      resy3=rand()%(LCD_YSIZE_TFT);  
      i=rand()%65536;//color
      j=rand()%3;
      if(j) LT768_Lib.LT768_DrawTriangle(resx1,resy1,resx2,resy2,resx3,resy3,i);      
      else  LT768_Lib.LT768_DrawTriangle_Fill(resx1,resy1,resx2,resy2,resx3,resy3,i); 
      h++;
      if(LT768_KEY.Scan_Key_delay(120)) return 1;
    }
    while(h<20);

    h=0;
    do
    {
      resx1=rand()%LCD_XSIZE_TFT;       
      resy1=rand()%(LCD_YSIZE_TFT);     
      resx2=rand()%LCD_XSIZE_TFT;       
      resy2=rand()%(LCD_YSIZE_TFT);     
      resx3=rand()%LCD_XSIZE_TFT;       
      resy3=rand()%(LCD_YSIZE_TFT);  
      i=rand()%65536;//color
      j=rand()%3;
      if(j) LT768_Lib.LT768_DrawTriangle(resx1,resy1,resx2,resy2,resx3,resy3,i);      
      else  LT768_Lib.LT768_DrawTriangle_Fill(resx1,resy1,resx2,resy2,resx3,resy3,i); 
      h++;
      delay(1);
      if(LT768_KEY.Scan_Key() != 0) return 1;
    }
    while(h<1500);
  }
}

unsigned char NUM[20][3] = {{'0','\0'},{'1','\0'},{'2','\0'},{'3','\0'},{'4','\0'},{'5','\0'},{'6','\0'},{'7','\0'},{'8','\0'},{'9','\0'},
                 {'1','0','\0'},{'1','0','\0'},{'1','2','\0'},{'1','3','\0'},{'1','4','\0'},{'1','5','\0'},{'1','6','\0'},{'1','7','\0'},{'1','8','\0'},{'1','9','\0'}};


unsigned char LT768Demo::Draw_Table(void)
{
  unsigned char i1 = 0;
  unsigned char i2 = 1;
  unsigned char i3 = 2;
  unsigned char i4 = 3;
  unsigned char count = 0;

  LT768.Select_Main_Window_16bpp();
  LT768.Main_Image_Start_Address(layer2_start_addr);         
  LT768.Main_Image_Width(LCD_XSIZE_TFT);
  LT768.Canvas_Image_Start_address(layer2_start_addr);       
  LT768.Canvas_image_width(LCD_XSIZE_TFT);                   
  LT768.Active_Window_XY(0,0);
  LT768.Active_Window_WH(LCD_XSIZE_TFT,LCD_YSIZE_TFT);      
  LT768.Main_Window_Start_XY(0,0);                           

  LT768_Lib.LT768_DMA_24bit_Block(1,0,0,0,LCD_XSIZE_TFT,LCD_YSIZE_TFT,LCD_XSIZE_TFT,Picture_4_Addr);
  
  LT768.Font_Background_select_Transparency();
  
  LT768.Canvas_Image_Start_address(layer5_start_addr);
  LT768.Canvas_image_width(1024);
  LT768_Lib.LT768_MakeTable(10,10,70,40,7,4,Cyan,Blue2,Yellow,1,4,0);
    
    
  LT768.Canvas_Image_Start_address(layer6_start_addr);
  LT768.Canvas_image_width(1024);
  LT768_Lib.LT768_MakeTable(10,10,70,40,12,4,Magenta,Blue,Yellow,1,4,1);
  
  LT768_Lib.LT768_BTE_Memory_Copy(layer5_start_addr,1024,6,6,
                        layer5_start_addr,1024,6,6,
                        layer2_start_addr,1024,40,170,
                        0x0c,70*4+9,40*7+9
                       );
                         
  LT768_Lib.LT768_BTE_Memory_Copy(layer6_start_addr,1024,6,6,
                        layer6_start_addr,1024,6,6,
                        layer2_start_addr,1024,700,70,
                        0x0c,70*4+9,40*12+9
                       );
  
  while(1)
  {
    
    LT768.Canvas_Image_Start_address(layer3_start_addr);
    LT768.Canvas_image_width(1024);
    LT768_Lib.LT768_MakeTable(10,10,70,40,3,4,Black,Red,Yellow,1,4,1);
    LT768_Lib.LT768_Print_Outside_Font_String(12,12,Black,Yellow,(unsigned char*)"Tem.");
    LT768_Lib.LT768_Print_Outside_Font_String(82,12,Black,Yellow,(unsigned char*)"Dis.");
    LT768_Lib.LT768_Print_Outside_Font_String(152,12,Black,Yellow,(unsigned char*)"Vol.");
    LT768_Lib.LT768_Print_Outside_Font_String(222,12,Black,Yellow,(unsigned char*)"TemD.");
    
    LT768_Lib.LT768_Print_Outside_Font_String(30,95,Blue2,Yellow,"'C");
    LT768_Lib.LT768_Print_Outside_Font_String(100,95,Blue2,Yellow,"cm");
    LT768_Lib.LT768_Print_Outside_Font_String(175,95,Blue2,Yellow,"V");
    LT768_Lib.LT768_Print_Outside_Font_String(240,95,Blue2,Yellow,"'C");
    LT768_Lib.LT768_Print_Outside_Font_String(35,55,Blue2,Yellow,&NUM[i1][0]);
    LT768_Lib.LT768_Print_Outside_Font_String(105,55,Blue2,Yellow,&NUM[i2][0]);
    LT768_Lib.LT768_Print_Outside_Font_String(175,55,Blue2,Yellow,&NUM[i3][0]);
    LT768_Lib.LT768_Print_Outside_Font_String(245,55,Blue2,Yellow,&NUM[i4][0]);
    
    LT768.Canvas_Image_Start_address(layer4_start_addr);
    LT768.Canvas_image_width(1024);
    LT768_Lib.LT768_MakeTable(10,10,70,40,4,3,Red,Blue2,Yellow,1,4,0);
    LT768_Lib.LT768_Print_Outside_Font_String(12,15,Red,Blue2,(unsigned char*)"Hum.");   //%HR
    LT768_Lib.LT768_Print_Outside_Font_String(12,55,Red,Blue2,(unsigned char*)"Cur.");
    LT768_Lib.LT768_Print_Outside_Font_String(12,95,Red,Blue2,(unsigned char*)"Pre.");
    LT768_Lib.LT768_Print_Outside_Font_String(12,135,Red,Blue2,(unsigned char*)"Tim.");
    
    LT768_Lib.LT768_Print_Outside_Font_String(162,15,Black,Blue2,"%HR");
    LT768_Lib.LT768_Print_Outside_Font_String(168,55,Black,Blue2,"mA");
    LT768_Lib.LT768_Print_Outside_Font_String(175,95,Black,Blue2,"N");
    LT768_Lib.LT768_Print_Outside_Font_String(175,135,Black,Blue2,"S");
    LT768_Lib.LT768_Print_Outside_Font_String(105,15,Black,Blue2,&NUM[i1][0]);
    LT768_Lib.LT768_Print_Outside_Font_String(105,55,Black,Blue2,&NUM[i2][0]);
    LT768_Lib.LT768_Print_Outside_Font_String(105,95,Black,Blue2,&NUM[i3][0]);
    LT768_Lib.LT768_Print_Outside_Font_String(105,135,Black,Blue2,&NUM[i4][0]);
    
    
    LT768_Lib.LT768_BTE_Memory_Copy(layer3_start_addr,1024,6,6,
                          layer3_start_addr,1024,6,6,
                          layer2_start_addr,1024,380,380,
                          0x0c,70*4+9,40*3+9
                         );
    
    LT768_Lib.LT768_BTE_Memory_Copy(layer4_start_addr,1024,6,6,
                          layer4_start_addr,1024,6,6,
                          layer2_start_addr,1024,420,100,
                          0x0c,70*3+9,40*4+9
                         );
                      
    i1++;
    i2++;
    i3++;
    if(i1 > 19) i1 = 0;
    if(i2 > 19) i2 = 0;
    if(i3 > 19) i3 = 0;
    
    count++;
    if(count == 2)
    {
      count = 0;
      i4++;
      if(i4 > 19) i4 = 0;
    }
    
    if(LT768_KEY.Scan_Key_delay(500)) return 1;
  }
}



unsigned char LT768Demo::Draw_Pillar_Demo(void)
{
  unsigned char i = 0;
  unsigned int j1 = 0 , z1 = 0;
  unsigned int j2 = 0 , z2 = 0;
  unsigned int h1 = 0, h2 = 0;
  
  unsigned int count = 0;
  
  LT768.Select_Main_Window_16bpp();
  LT768.Main_Image_Start_Address(layer2_start_addr);        
  LT768.Main_Image_Width(LCD_XSIZE_TFT);
  LT768.Main_Window_Start_XY(0,0);                          
  LT768.Canvas_Image_Start_address(layer2_start_addr);    
  LT768.Canvas_image_width(LCD_XSIZE_TFT);               
  LT768.Active_Window_XY(0,0);
  LT768.Active_Window_WH(LCD_XSIZE_TFT,LCD_YSIZE_TFT);      

  LT768_Lib.LT768_DrawSquare_Fill(0,0,LCD_XSIZE_TFT,LCD_YSIZE_TFT,Blue2);
  
  while(1)
  {
    count = 1;
    while(count--)
    {
      for(i = 0 ; i < 11 ; i++)
      {
        j1 = rand() % 65536;               
        z1 = rand() % 65536;                  
        j2 = rand() % 65536;                  
        z2 = rand() % 65536;                
        h1 = rand() % 400;
        h2 = rand() % 400;
        
        LT768_Lib.BTE_Solid_Fill(0x12c000,1024,40*(i+1)-19,0,Blue2,40,600);
        LT768_Lib.LT768_DrawCylinder(40*(i+1),500,18,9,h1,j1,z1);
        
        LT768_Lib.BTE_Solid_Fill(0x12c000,1024,1000-i*40-24,0,Blue2,41,600);
        LT768_Lib.LT768_DrawQuadrangular(1000-i*40-24,509-h2,    // 1
                               1000-i*40-10,499-h2,    // 2
                               1014-i*40,499-h2,       // 3
                               1000-i*40,509-h2,       // 4
                               1000-i*40,509,          // 5
                               1014-i*40,499,          // 6
                               j2,z2);
        
        if(LT768_KEY.Scan_Key_delay(150)) return 1;
      }
    
      for(i = 11 ; i > 0 ; i--)
      {
        j1 = rand() % 65536;                  
        z1 = rand() % 65536;                 
        j2 = rand() % 65536;                
        z2 = rand() % 65536;                 
        h1 = rand() % 400;
        h2 = rand() % 400;
        
        LT768_Lib.BTE_Solid_Fill(0x12c000,1024,40*(i+1)-19,0,Blue2,41,600);
        LT768_Lib.LT768_DrawCylinder(40*(i+1),500,18,9,h1,j1,z1);
        
        LT768_Lib.BTE_Solid_Fill(0x12c000,1024,1000-i*40-24,0,Blue2,41,600);
        LT768_Lib.LT768_DrawQuadrangular(1000-i*40-24,509-h2,    // 1
                               1000-i*40-10,499-h2,    // 2
                               1014-i*40,499-h2,       // 3
                               1000-i*40,509-h2,       // 4
                               1000-i*40,509,          // 5
                               1014-i*40,499,          // 6
                               j2,z2);
          
        if(LT768_KEY.Scan_Key_delay(150)) return 1;
      }
    }

    count = 10;
    while(count--)
    {
      for(i = 0 ; i < 11 ; i++)
      {
        j1 = rand() % 65536;             
        z1 = rand() % 65536;            
        j2 = rand() % 65536;             
        z2 = rand() % 65536;              
        h1 = rand() % 400;
        h2 = rand() % 400;
        
        LT768_Lib.BTE_Solid_Fill(0x12c000,1024,40*(i+1)-19,0,Blue2,40,600);
        LT768_Lib.LT768_DrawCylinder(40*(i+1),500,18,9,h1,j1,z1);
        
        LT768_Lib.BTE_Solid_Fill(0x12c000,1024,1000-i*40-24,0,Blue2,41,600);
        LT768_Lib.LT768_DrawQuadrangular(1000-i*40-24,509-h2,    // 1
                               1000-i*40-10,499-h2,    // 2
                               1014-i*40,499-h2,       // 3
                               1000-i*40,509-h2,       // 4
                               1000-i*40,509,          // 5
                               1014-i*40,499,          // 6
                               j2,z2);
        
        if(LT768_KEY.Scan_Key_delay(10))  return 1;
      }
    
      for(i = 11 ; i > 0 ; i--)
      {
        j1 = rand() % 65536;             
        z1 = rand() % 65536;            
        j2 = rand() % 65536;             
        z2 = rand() % 65536;                
        h1 = rand() % 400;
        h2 = rand() % 400;
        
        LT768_Lib.BTE_Solid_Fill(0x12c000,1024,40*(i+1)-19,0,Blue2,41,600);
        LT768_Lib.LT768_DrawCylinder(40*(i+1),500,18,9,h1,j1,z1);
        
        LT768_Lib.BTE_Solid_Fill(0x12c000,1024,1000-i*40-24,0,Blue2,41,600);
        LT768_Lib.LT768_DrawQuadrangular(1000-i*40-24,509-h2,    // 1
                               1000-i*40-10,499-h2,    // 2
                               1014-i*40,499-h2,       // 3
                               1000-i*40,509-h2,       // 4
                               1000-i*40,509,          // 5
                               1014-i*40,499,          // 6
                               j2,z2);
          
        if(LT768_KEY.Scan_Key_delay(10))  return 1;
      }
    }
  }
}





unsigned char LT768Demo::DMA_Demo(void)
{
  unsigned int i;
    
  LT768.Select_Main_Window_16bpp();
  LT768.Main_Image_Start_Address(layer2_start_addr);        
  LT768.Main_Image_Width(LCD_XSIZE_TFT);
  LT768.Canvas_Image_Start_address(layer2_start_addr);      
  LT768.Canvas_image_width(LCD_XSIZE_TFT);                
  LT768.Active_Window_XY(0,0);
  LT768.Active_Window_WH(LCD_XSIZE_TFT,LCD_YSIZE_TFT);     
  LT768.Main_Window_Start_XY(0,0);                          

  LT768_Lib.LT768_DrawSquare_Fill(0,0,LCD_XSIZE_TFT,LCD_YSIZE_TFT,White);

  //execute DMA to show 1024x600 picture
  while(1)
  {
    for(i=0;i<4;i++)
    {
      switch(i)
      {
        case 0:LT768_Lib.LT768_DMA_24bit_Block(1,0,0,0,LCD_XSIZE_TFT,LCD_YSIZE_TFT,LCD_XSIZE_TFT,Picture_1_Addr);break;
        case 1:LT768_Lib.LT768_DMA_24bit_Block(1,0,0,0,LCD_XSIZE_TFT,LCD_YSIZE_TFT,LCD_XSIZE_TFT,Picture_2_Addr);break;
        case 2:LT768_Lib.LT768_DMA_24bit_Block(1,0,0,0,LCD_XSIZE_TFT,LCD_YSIZE_TFT,LCD_XSIZE_TFT,Picture_3_Addr);break;
        case 3:LT768_Lib.LT768_DMA_24bit_Block(1,0,0,0,LCD_XSIZE_TFT,LCD_YSIZE_TFT,LCD_XSIZE_TFT,Picture_4_Addr);break;
        default:  break;
      }
      if(LT768_KEY.Scan_Key_delay(100)) return 1;
    }
  }
}


unsigned char LT768Demo::Text_Demo(void)
{
  char c[2] = "0";
  unsigned int i = 0;
  unsigned int x = 0;
  unsigned int y = 0;
  unsigned int z = 0;
  
  LT768.Select_Main_Window_16bpp();
  LT768.Main_Image_Start_Address(layer2_start_addr);        
  LT768.Main_Image_Width(LCD_XSIZE_TFT);
  LT768.Canvas_Image_Start_address(layer2_start_addr);     
  LT768.Canvas_image_width(LCD_XSIZE_TFT);                 
  LT768.Active_Window_XY(0,0);
  LT768.Active_Window_WH(LCD_XSIZE_TFT,LCD_YSIZE_TFT);      
  LT768.Main_Window_Start_XY(0,0);                        
  

  while(1)
  {
    LT768_Lib.LT768_DrawSquare_Fill(0,0,LCD_XSIZE_TFT,LCD_YSIZE_TFT,Blue2);
    
    LT768_Lib.LT768_Select_Internal_Font_Init(16,1,1,0,0);
    LT768_Lib.LT768_Print_Internal_Font_String(10,10,Black,Blue2,"Embedded 8x16 ASCII Character");
    
    LT768_Lib.LT768_Select_Internal_Font_Init(24,1,1,0,0);
    LT768_Lib.LT768_Print_Internal_Font_String(10,30,Blue,Blue2,"Embedded 12x24 ASCII Character");
    
    LT768_Lib.LT768_Select_Internal_Font_Init(32,1,1,0,0);
    LT768_Lib.LT768_Print_Internal_Font_String(10,55,Green,Blue2,"Embedded 16x32 ASCII Character");
    
    LT768_Lib.LT768_Print_Internal_Font_String(10,95,Red,Blue2,"The Text Cursor");
    
    for(i = 0 ; i < 14 ; i++)
    {
      delay(100);
      LT768_Lib.LT768_Text_cursor_Init(1,15,1+i,15-i);
    }
    delay(100);
    LT768_Lib.LT768_Text_cursor_Init(1,15,10,2);
    
    
    c[0] = '0';
    for(i = 0 ; i < 10 ; i++)
    {
      if(LT768_KEY.Scan_Key_delay(40))  return 1;
      LT768_Lib.LT768_Print_Internal_Font_String(10+16*i,135,Red,Blue2,&c[0]);
      c[0]++;
    }
    
    c[0] = 0;
    x = 0;
    y = 175;
    z = 0;
    for(i = 0 ; i < 127 ; i++)
    {
      if(LT768_KEY.Scan_Key_delay(40))  return 1;
      
      x = z * 16;
      z++;
      if(x>1024)
      {
        y = y + 40;
        x = 0;
        z = 0;
      }
      
      LT768_Lib.LT768_Print_Internal_Font_String(x,y,Red,Blue2,&c[0]);
      c[0]++;
    }
    
    i = 0;
    if(LT768_KEY.Scan_Key_delay(40))  return 1;
    LT768_Lib.LT768_Print_Internal_Font_String(10+16*i++,255,Red,Blue2,"T");
    if(LT768_KEY.Scan_Key_delay(40))  return 1;
    LT768_Lib.LT768_Print_Internal_Font_String(10+16*i++,255,Red,Blue2,"h");
    if(LT768_KEY.Scan_Key_delay(40))  return 1;
    LT768_Lib.LT768_Print_Internal_Font_String(10+16*i++,255,Red,Blue2,"e");
    if(LT768_KEY.Scan_Key_delay(40))  return 1;
    LT768_Lib.LT768_Print_Internal_Font_String(10+16*i++,255,Red,Blue2," ");
    if(LT768_KEY.Scan_Key_delay(40))  return 1;
    LT768_Lib.LT768_Print_Internal_Font_String(10+16*i++,255,Red,Blue2,"G");
    if(LT768_KEY.Scan_Key_delay(40))  return 1;
    LT768_Lib.LT768_Print_Internal_Font_String(10+16*i++,255,Red,Blue2,"r");
    if(LT768_KEY.Scan_Key_delay(40))  return 1;
    LT768_Lib.LT768_Print_Internal_Font_String(10+16*i++,255,Red,Blue2,"a");
    if(LT768_KEY.Scan_Key_delay(40))  return 1;
    LT768_Lib.LT768_Print_Internal_Font_String(10+16*i++,255,Red,Blue2,"p");
    if(LT768_KEY.Scan_Key_delay(40))  return 1;
    LT768_Lib.LT768_Print_Internal_Font_String(10+16*i++,255,Red,Blue2,"h");
    if(LT768_KEY.Scan_Key_delay(40))  return 1;
    LT768_Lib.LT768_Print_Internal_Font_String(10+16*i++,255,Red,Blue2,"i");
    if(LT768_KEY.Scan_Key_delay(40))  return 1;
    LT768_Lib.LT768_Print_Internal_Font_String(10+16*i++,255,Red,Blue2,"c");
    if(LT768_KEY.Scan_Key_delay(40))  return 1;
    LT768_Lib.LT768_Print_Internal_Font_String(10+16*i++,255,Red,Blue2," ");
    if(LT768_KEY.Scan_Key_delay(40))  return 1;
    LT768_Lib.LT768_Print_Internal_Font_String(10+16*i++,255,Red,Blue2,"C");
    if(LT768_KEY.Scan_Key_delay(40))  return 1;
    LT768_Lib.LT768_Print_Internal_Font_String(10+16*i++,255,Red,Blue2,"u");
    if(LT768_KEY.Scan_Key_delay(40))  return 1;
    LT768_Lib.LT768_Print_Internal_Font_String(10+16*i++,255,Red,Blue2,"r");
    if(LT768_KEY.Scan_Key_delay(40))  return 1;
    LT768_Lib.LT768_Print_Internal_Font_String(10+16*i++,255,Red,Blue2,"s");
    if(LT768_KEY.Scan_Key_delay(40))  return 1;
    LT768_Lib.LT768_Print_Internal_Font_String(10+16*i++,255,Red,Blue2,"o");
    if(LT768_KEY.Scan_Key_delay(40))  return 1;
    LT768_Lib.LT768_Print_Internal_Font_String(10+16*i++,255,Red,Blue2,"r");
    if(LT768_KEY.Scan_Key_delay(40))  return 1;
    
    LT768_Lib.LT768_DMA_24bit_Block(1,0,200,300,600,280,1024,Picture_3_Addr);
    
    LT768_Lib.LT768_Graphic_cursor_Init(1,0xff,0x00,0,0,(unsigned char*)gImage_pen_il);
    LT768_Lib.LT768_Graphic_cursor_Init(2,0xff,0x00,0,0,(unsigned char*)gImage_arrow_il);
    LT768_Lib.LT768_Graphic_cursor_Init(3,0xff,0x00,0,0,(unsigned char*)gImage_busy_im);
    LT768_Lib.LT768_Graphic_cursor_Init(4,0xff,0x00,0,0,(unsigned char*)gImage_no_im);
    
    
    LT768_Lib.LT768_Set_Graphic_cursor_Pos(1,100,300);
    if(LT768_KEY.Scan_Key_delay(500)) return 1;
    LT768_Lib.LT768_Set_Graphic_cursor_Pos(2,100,300);
    if(LT768_KEY.Scan_Key_delay(500)) return 1;
    LT768_Lib.LT768_Set_Graphic_cursor_Pos(3,100,300);
    if(LT768_KEY.Scan_Key_delay(500)) return 1;
    LT768_Lib.LT768_Set_Graphic_cursor_Pos(4,100,300);
    if(LT768_KEY.Scan_Key_delay(500)) return 1;
    LT768_Lib.LT768_Set_Graphic_cursor_Pos(1,100,300);
    
    for(i = 100 ; i < 924 ; i++)
    {
      LT768_Lib.LT768_Set_Graphic_cursor_Pos(1,i,90);
      if(LT768_KEY.Scan_Key_delay(2)) return 1;
    }
    
    for(i = 200 ; i < 800 ; i++)
    {
      LT768_Lib.LT768_Set_Graphic_cursor_Pos(2,i,i-200);
      if(LT768_KEY.Scan_Key_delay(2)) return 1;
    }
    
    for(i = 800 ; i > 100 ; i--)
    {
      LT768_Lib.LT768_Set_Graphic_cursor_Pos(3,i,800-i);
      if(LT768_KEY.Scan_Key_delay(2)) return 1;
    }
    
    for(i = 924 ; i > 100 ; i--)
    {
      LT768_Lib.LT768_Set_Graphic_cursor_Pos(4,i,400);
      if(LT768_KEY.Scan_Key_delay(2)) return 1;
    }
    
    if(LT768_KEY.Scan_Key_delay(1000))  return 1;
    
    LT768_Lib.LT768_Disable_Text_Cursor();  
    LT768_Lib.LT768_Disable_Graphic_Cursor();
  }
}




unsigned char LT768Demo::Outside_Font(void)
{
  LT768.Select_Main_Window_16bpp();
  LT768.Main_Image_Start_Address(layer2_start_addr);       
  LT768.Main_Image_Width(LCD_XSIZE_TFT);
  LT768.Canvas_Image_Start_address(layer2_start_addr);    
  LT768.Canvas_image_width(LCD_XSIZE_TFT);                
  LT768.Active_Window_XY(0,0);
  LT768.Active_Window_WH(LCD_XSIZE_TFT,LCD_YSIZE_TFT);   
  LT768.Main_Window_Start_XY(0,0);                          
  
  while(1)
  {
    LT768_Lib.LT768_DrawSquare_Fill(0,0,LCD_XSIZE_TFT,LCD_YSIZE_TFT,White);
    LT768_Lib.LT768_Select_Outside_Font_Init(1,0,FLASH_ADDR_16,MEMORY_ADDR_16,SIZE_16_NUM,16,1,1,0,0);
    if(LT768_KEY.Scan_Key_delay(500)) return 1;
    LT768_Lib.LT768_Print_Outside_Font_String(425,50,Red,White,(unsigned char*)"16X16΢���ź�����");
    if(LT768_KEY.Scan_Key_delay(500)) return 1;
    LT768.Font_Width_X2();
    LT768.Font_Height_X2();
    LT768_Lib.LT768_Print_Outside_Font_String(250,75,Grey-1200,White,(unsigned char*)"16X16΢���ź����峤������1��");
    if(LT768_KEY.Scan_Key_delay(500)) return 1;
    LT768.Font_Width_X3();
    LT768.Font_Height_X3();
    LT768_Lib.LT768_Print_Outside_Font_String(150,120,Blue,White,(unsigned char*)"16X16΢���ź����峤������2��");
    if(LT768_KEY.Scan_Key_delay(500)) return 1;
    LT768.Font_Width_X4();
    LT768.Font_Height_X4();
    LT768_Lib.LT768_Print_Outside_Font_String(60,178,Magenta,White,(unsigned char*)"16X16΢���ź����峤������3��");

    LT768_Lib.LT768_Select_Outside_Font_Init(1,0,FLASH_ADDR_24,MEMORY_ADDR_24,SIZE_24_NUM,24,1,1,0,0);
    if(LT768_KEY.Scan_Key_delay(500)) return 1;
    LT768_Lib.LT768_Print_Outside_Font_String(445,280,Red,White,(unsigned char*)"24X24����");
    if(LT768_KEY.Scan_Key_delay(500)) return 1;
    LT768.Font_Width_X2();
    LT768.Font_Height_X2();
    LT768_Lib.LT768_Print_Outside_Font_String(260,315,Green,White,(unsigned char*)"24X24���峤������1��");
    if(LT768_KEY.Scan_Key_delay(500)) return 1;
    LT768.Font_Width_X3();
    LT768.Font_Height_X3();
    LT768_Lib.LT768_Print_Outside_Font_String(150,375,Cyan,White,(unsigned char*)"24X24���峤������2��");
    if(LT768_KEY.Scan_Key_delay(500)) return 1;
    LT768.Font_Width_X4();
    LT768.Font_Height_X4();
    LT768_Lib.LT768_Print_Outside_Font_String(30,455,Yellow,White,(unsigned char*)"24X24���峤������3��");

    LT768_Lib.LT768_Select_Outside_Font_Init(1,0,FLASH_ADDR_32,MEMORY_ADDR_32,SIZE_32_NUM,32,1,1,0,0);
    if(LT768_KEY.Scan_Key_delay(1000))  return 1;
    
    LT768_Lib.LT768_DrawSquare_Fill(0,0,LCD_XSIZE_TFT,LCD_YSIZE_TFT,White);
    LT768_Lib.LT768_Print_Outside_Font_String(430,105,Red,White,(unsigned char*)"32X32����");
    if(LT768_KEY.Scan_Key_delay(500)) return 1;
    LT768.Font_Width_X2();
    LT768.Font_Height_X2();
    LT768_Lib.LT768_Print_Outside_Font_String(360,165,Green,White,(unsigned char*)"32X32����");
    if(LT768_KEY.Scan_Key_delay(500)) return 1;
    LT768.Font_Width_X3();
    LT768.Font_Height_X3();
    LT768_Lib.LT768_Print_Outside_Font_String(285,250,Blue,White,(unsigned char*)"32X32����");
    if(LT768_KEY.Scan_Key_delay(500)) return 1;
    LT768.Font_Width_X4();
    LT768.Font_Height_X4();
    LT768_Lib.LT768_Print_Outside_Font_String(220,360,Yellow,White,(unsigned char*)"32X32����");
    
    if(LT768_KEY.Scan_Key_delay(2500))  return 1;
    LT768.Font_Width_X1();
    LT768.Font_Height_X1();
    LT768_Lib.LT768_DrawSquare_Fill(0,0,LCD_XSIZE_TFT,LCD_YSIZE_TFT,White);
    LT768_Lib.LT768_Print_Outside_Font_String(460,10,Red,White,(unsigned char*)"32X32����");
    LT768_Lib.LT768_Print_Outside_Font_String(64,50,Blue,White,(unsigned char*)"LT768 ������ʹ���ߴ������λ���ţ����Դ�����ǣ�8*16��12*24��16*32 dots������ȫ�ǣ�16*16��24*24��32*32 dots�������λ���ţ��˹���֧�� 32768 ����ֻ� 32768 ȫ���֣�������α��뷶Χ���� 0000h ~ 7FFFh����ȫ�����α��뷶Χ���� 8000h ~ FFFFh����ʹ���������ַ��룬�� LT768 ���Ὣ���������ⲿ SDRAM �ַ��ռ䣬���ҽ����λ�������ݴ浽��ʾ�ڴ�����䡣");
    LT768_Lib.LT768_Print_Outside_Font_String(64,260,Red,White,(unsigned char*)"LT768�����������¼������ܣ�");
    LT768_Lib.LT768_Print_Outside_Font_String(0,300,Green,White,(unsigned char*)"1��LT768 ֧��������ת���ܣ�����ʾ�ַ�������ʱ����ת 90 �ȡ�");
    LT768_Lib.LT768_Print_Outside_Font_String(0,340,Green,White,(unsigned char*)"2��LT768 �ṩ�������ԷŴ�Ĺ��ܡ�");
    LT768_Lib.LT768_Print_Outside_Font_String(0,380,Green,White,(unsigned char*)"3��LT768 �ṩ����͸�����ܡ�");
    LT768_Lib.LT768_Print_Outside_Font_String(0,420,Green,White,(unsigned char*)"4��LT768 �ṩ�����Զ����й��ܣ������������Ӵ���Եʱ���Զ����С�");
    LT768_Lib.LT768_Print_Outside_Font_String(0,460,Green,White,(unsigned char*)"5��LT768�ṩ���ֶ��빦�ܣ���LCD�ڰ����֡�ȫ���ֽ���������¿�����ʾ�ıȽ����롣");

    if(LT768_KEY.Scan_Key_delay(3000))  return 1;
    
  }
}


unsigned char LT768Demo::PIP_Demo(void)
{
  unsigned int i;

  LT768_Lib.LT768_DMA_24bit_Block(1,0,0,LCD_YSIZE_TFT,LCD_XSIZE_TFT,LCD_YSIZE_TFT,LCD_XSIZE_TFT,Picture_2_Addr);
  LT768_Lib.LT768_DMA_24bit_Block(1,0,0,LCD_YSIZE_TFT*4,LCD_XSIZE_TFT,LCD_YSIZE_TFT,LCD_XSIZE_TFT,Picture_3_Addr);
  LT768_Lib.LT768_DMA_24bit_Block(1,0,0,LCD_YSIZE_TFT*5,LCD_XSIZE_TFT,LCD_YSIZE_TFT,LCD_XSIZE_TFT,Picture_4_Addr);
  
  LT768_Lib.BTE_Solid_Fill(0x258000,1024,0,0,Red,1024,600);
  LT768_Lib.BTE_Solid_Fill(0x384000,1024,0,0,Blue,1024,600);
  
  LT768.Select_Main_Window_16bpp();
  LT768.Main_Image_Start_Address(layer2_start_addr);         
  LT768.Main_Image_Width(LCD_XSIZE_TFT);
  LT768.Canvas_Image_Start_address(layer2_start_addr);       
  LT768.Canvas_image_width(LCD_XSIZE_TFT);                   
  LT768.Active_Window_XY(0,0);
  LT768.Active_Window_WH(LCD_XSIZE_TFT,LCD_YSIZE_TFT);      
  LT768.Main_Window_Start_XY(0,0);                          
  
  
  while(1)
  { 
    LT768_Lib.LT768_PIP_Init(1,1,0x258000,250,250,1024,0,175,250,250);
    LT768_Lib.LT768_PIP_Init(1,2,0x384000,300,300,1024,774,150,300,300);
    
    for(i=0;i<550;i=i+2)
    {     
      LT768_Lib.LT768_Set_DisWindowPos(1,1,i,175);
      LT768_Lib.LT768_Set_DisWindowPos(1,2,734-i,150);
      delay(5);
      
      if(LT768_KEY.Scan_Key() != 0)   return 1;
    }

    for(i=0;i<550;i=i+2)
    {
      LT768_Lib.LT768_Set_DisWindowPos(1,1,550-i,175);
      LT768_Lib.LT768_Set_DisWindowPos(1,2,734-550+i,150);
      delay(5);
      if(LT768_KEY.Scan_Key() != 0)   return 1;
    }

    if(LT768_KEY.Scan_Key_delay(1000))  return 1;
    
    LT768_Lib.LT768_PIP_Init(1,1,0x4b0000,250,250,1024,0,175,250,250);
    LT768_Lib.LT768_PIP_Init(1,2,0x5dc000,300,300,1024,774,150,300,300);
    
    for(i=0;i<550;i=i+2)
    {     
      LT768_Lib.LT768_Set_DisWindowPos(1,1,i,175);
      LT768_Lib.LT768_Set_DisWindowPos(1,2,734-i,150);
      delay(5);
      
      if(LT768_KEY.Scan_Key() != 0)   return 1;
    }

    for(i=0;i<550;i=i+2)
    {
      LT768_Lib.LT768_Set_DisWindowPos(1,1,550-i,175);
      LT768_Lib.LT768_Set_DisWindowPos(1,2,734-550+i,150);
      delay(5);
      if(LT768_KEY.Scan_Key() != 0)   return 1;
    }

    if(LT768_KEY.Scan_Key_delay(1000))  return 1;
  }
}





#define grid_width 801
#define grid_high  600
#define grid_gap   50

unsigned char LT768Demo::App_Demo_BTE(void)
{
  unsigned int i,h;

  unsigned int point1y,point2y;
  unsigned int point21y,point22y;
  unsigned int point31y,point32y;
  point2y = 0;  //initial value
  point22y = 0; //initial value
  point32y = 0; //initial value
  
  LT768.Select_Main_Window_16bpp();
  LT768.Main_Image_Start_Address(layer2_start_addr);     
  LT768.Main_Image_Width(LCD_XSIZE_TFT);
  LT768.Canvas_Image_Start_address(layer2_start_addr);       
  LT768.Canvas_image_width(LCD_XSIZE_TFT);                
  LT768.Active_Window_XY(0,0);
  LT768.Active_Window_WH(LCD_XSIZE_TFT,LCD_YSIZE_TFT);    
  LT768.Main_Window_Start_XY(0,0);                      
  
  LT768_Lib.LT768_DrawSquare_Fill(0,0,LCD_XSIZE_TFT,LCD_YSIZE_TFT,Blue2);

  //creat grid 500*400 to layer2 used geometric draw 
  LT768.Canvas_Image_Start_address(layer3_start_addr);  //Layer 3
  LT768_Lib.LT768_DrawSquare_Fill(0,0,LCD_XSIZE_TFT,LCD_YSIZE_TFT,Black);

  for(i=0;i<=grid_width;i+=grid_gap)
  {
      LT768_Lib.LT768_DrawLine(i,0,i,grid_high-1,color65k_grayscale12);
  }

  for(i=0;i<=grid_high;i+=grid_gap)
  {
     LT768_Lib.LT768_DrawLine(0,i,grid_width-1,i,color65k_grayscale12);
  }
  
  LT768.Canvas_Image_Start_address(layer4_start_addr);  //Layer 4
  LT768_Lib.LT768_DMA_24bit_Block(1,0,0,0,LCD_XSIZE_TFT,LCD_YSIZE_TFT,LCD_XSIZE_TFT,Picture_3_Addr);
  
  LT768.Canvas_Image_Start_address(layer5_start_addr);  //Layer 5
  LT768_Lib.LT768_DMA_24bit_Block(1,0,0,0,LCD_XSIZE_TFT,LCD_YSIZE_TFT,LCD_XSIZE_TFT,Picture_4_Addr);
  
  LT768.Canvas_Image_Start_address(layer6_start_addr);  //Layer 6
  LT768_Lib.LT768_DMA_24bit_Block(1,0,0,0,LCD_XSIZE_TFT,LCD_YSIZE_TFT,LCD_XSIZE_TFT,Picture_1_Addr);
  
  LT768_Lib.LT768_BTE_Memory_Copy(layer3_start_addr,1024,0,0,layer3_start_addr,1024,0,0,layer2_start_addr,1024,112,0,0x0c,801,600);

  LT768.Canvas_Image_Start_address(layer2_start_addr);//Layer 2
  
  while(1)
  {
    h=0;
    while(h<5)
    {
      for(i=0;i<800;i+=4)
      {
        LT768_Lib.LT768_BTE_Memory_Copy(layer3_start_addr,1024,i,0,layer3_start_addr,1024,0,0,layer2_start_addr,1024,112+i,0,0x0c,2,600);

        point1y = point2y;
        point2y = rand()%90;//

        point21y = point22y;
        point22y = rand()%99;//

        point31y = point32y;
        point32y = rand()%67;//

        LT768_Lib.LT768_DrawLine(i+112,point1y+80,i+1+112,point2y+80,color65k_yellow);
        LT768_Lib.LT768_DrawLine(i+112,point21y+260,i+1+112,point22y+260,color65k_purple);
        LT768_Lib.LT768_DrawLine(i+112,point31y+440,i+1+112,point32y+440,color65k_green);

        delayMicroseconds(100);

        if(LT768_KEY.Scan_Key() != 0) return 1;
      }
        
      h++;
    }
    
    
    for(i = 0 ; i < 16 ; i+=2)
    {
      LT768_Lib.LT768_BTE_Memory_Copy(layer4_start_addr,1024,i*64,0,layer4_start_addr,1024,0,0,layer2_start_addr,1024,i*64,0,0x0c,64,600);
      if(LT768_KEY.Scan_Key_delay(200)) return 1;
    }
    for(i = 0 ; i < 16 ; i+=2)
    {
      LT768_Lib.LT768_BTE_Memory_Copy(layer4_start_addr,1024,i*64+64,0,layer4_start_addr,1024,0,0,layer2_start_addr,1024,i*64+64,0,0x0c,64,600);
      if(LT768_KEY.Scan_Key_delay(200)) return 1;
    }
    
    for(i = 1 ; i < 17 ; i++)
    {
      LT768_Lib.LT768_BTE_Memory_Copy(layer5_start_addr,1024,1024-i*64,0,layer5_start_addr,1024,0,0,layer2_start_addr,1024,1024-i*64,0,0x0c,64,600);
      if(LT768_KEY.Scan_Key_delay(200)) return 1;
    }
    
    for(i = 0 ; i < 16 ; i++)
    {
      if(i%2==0)  LT768_Lib.LT768_BTE_Memory_Copy(layer4_start_addr,1024,i*64,0,layer4_start_addr,1024,0,0,layer2_start_addr,1024,i*64,0,0x0c,64,600);
      else        LT768_Lib.LT768_BTE_Memory_Copy(layer6_start_addr,1024,i*64,0,layer6_start_addr,1024,0,0,layer2_start_addr,1024,i*64,0,0x0c,64,600);
      if(LT768_KEY.Scan_Key_delay(200)) return 1;
    }
    
    for(i = 0 ; i < 10 ; i++)
    {
      if(i%2==0)  LT768_Lib.LT768_BTE_Memory_Copy(layer5_start_addr,1024,0,i*60,layer5_start_addr,1024,0,0,layer2_start_addr,1024,0,i*60,0x0c,1024,60);
      if(LT768_KEY.Scan_Key_delay(200)) return 1;
    }
    
    if(LT768_KEY.Scan_Key_delay(200)) return 1;
    LT768_Lib.LT768_DrawSquare_Fill(0,0,LCD_XSIZE_TFT,LCD_YSIZE_TFT,Blue2);
    LT768_Lib.LT768_BTE_Memory_Copy(layer3_start_addr,1024,0,0,layer3_start_addr,1024,0,0,layer2_start_addr,1024,112,0,0x0c,801,600);
    
  }
  
}


unsigned char LT768Demo::App_Demo_Alpha_Blending(void)
{
  unsigned int i;

  LT768.Select_Main_Window_16bpp();
  LT768.Main_Image_Start_Address(layer2_start_addr);
  LT768.Main_Image_Width(LCD_XSIZE_TFT);
  LT768.Main_Window_Start_XY(0,0);

  LT768.Canvas_Image_Start_address(layer2_start_addr);
  LT768.Canvas_image_width(LCD_XSIZE_TFT);
  LT768.Active_Window_XY(0,0);
  LT768.Active_Window_WH(LCD_XSIZE_TFT,LCD_YSIZE_TFT);
  
  LT768_Lib.LT768_DrawSquare_Fill(0,0,LCD_XSIZE_TFT,LCD_YSIZE_TFT,Blue2);
  
  LT768_Lib.LT768_DMA_24bit_Block(1,0,0,LCD_YSIZE_TFT*1,LCD_XSIZE_TFT,LCD_YSIZE_TFT,LCD_XSIZE_TFT,Picture_3_Addr);
  LT768_Lib.LT768_DMA_24bit_Block(1,0,0,LCD_YSIZE_TFT*2,LCD_XSIZE_TFT,LCD_YSIZE_TFT,LCD_XSIZE_TFT,Picture_4_Addr);
  
  while(1)
  {
    for(i=0;i<32;i++)
    {
      LT768_Lib.BTE_Alpha_Blending(0x258000,1024,0,0,
                         0x384000,1024,0,0,
                         0x12c000,1024,0,0,
                         LCD_XSIZE_TFT,LCD_YSIZE_TFT,i);
        
      if(LT768_KEY.Scan_Key_delay(100)) return 1;
    }
    if(LT768_KEY.Scan_Key_delay(2500))  return 1;

    for(i=32;i>0;i--)
    {
      LT768_Lib.BTE_Alpha_Blending(0x258000,1024,0,0,
                         0x384000,1024,0,0,
                         0x12c000,1024,0,0,
                         LCD_XSIZE_TFT,LCD_YSIZE_TFT,i);
      if(LT768_KEY.Scan_Key_delay(100)) return 1;
    }
    if(LT768_KEY.Scan_Key_delay(2500))  return 1;
  }
}


unsigned char LT768Demo::App_Demo_slide_frame_buffer(void)
{
  unsigned int i,j;

  LT768.Select_Main_Window_16bpp();
  LT768.Main_Image_Start_Address(layer2_start_addr);       
  LT768.Main_Image_Width(LCD_XSIZE_TFT*2);
  LT768.Canvas_Image_Start_address(layer2_start_addr);      
  LT768.Canvas_image_width(LCD_XSIZE_TFT*2);              
  LT768.Active_Window_XY(0,0);
  LT768.Active_Window_WH(LCD_XSIZE_TFT,LCD_YSIZE_TFT);      
  LT768.Main_Window_Start_XY(0,0);                      
  
  LT768_Lib.LT768_DrawSquare_Fill(0,0,LCD_XSIZE_TFT,LCD_YSIZE_TFT,Blue2);
  LT768_Lib.LT768_DMA_24bit_Block(1,0,0,0,LCD_XSIZE_TFT,LCD_YSIZE_TFT,LCD_XSIZE_TFT,Picture_1_Addr);
  LT768_Lib.LT768_DMA_24bit_Block(1,0,LCD_XSIZE_TFT,0,LCD_XSIZE_TFT,LCD_YSIZE_TFT,LCD_XSIZE_TFT,Picture_2_Addr);
  LT768_Lib.LT768_DMA_24bit_Block(1,0,0,LCD_YSIZE_TFT,LCD_XSIZE_TFT,LCD_YSIZE_TFT,LCD_XSIZE_TFT,Picture_3_Addr);
  LT768_Lib.LT768_DMA_24bit_Block(1,0,LCD_XSIZE_TFT,LCD_YSIZE_TFT,LCD_XSIZE_TFT,LCD_YSIZE_TFT,LCD_XSIZE_TFT,Picture_4_Addr);

  while(1)
  {
    LT768.Main_Window_Start_XY(0,0);
    if(LT768_KEY.Scan_Key_delay(250)) return 1;
    LT768.Main_Window_Start_XY(LCD_XSIZE_TFT,0);
    if(LT768_KEY.Scan_Key_delay(250)) return 1;
    LT768.Main_Window_Start_XY(0,LCD_YSIZE_TFT);
    if(LT768_KEY.Scan_Key_delay(250)) return 1;
    LT768.Main_Window_Start_XY(LCD_XSIZE_TFT,LCD_YSIZE_TFT);
    if(LT768_KEY.Scan_Key_delay(250)) return 1;
    LT768.Main_Window_Start_XY(0,0);
    if(LT768_KEY.Scan_Key_delay(250)) return 1;

    for(i=0;i<LCD_XSIZE_TFT+1;i++)
    {
      LT768.Main_Window_Start_XY(i,0);
      delay(1);
      if(LT768_KEY.Scan_Key() != 0) return 1;
    }
    
    if(LT768_KEY.Scan_Key_delay(200)) return 1;

    for(j=0;j<LCD_YSIZE_TFT+1;j++)
    {
      LT768.Main_Window_Start_XY(LCD_XSIZE_TFT,j);
      delay(1);
      if(LT768_KEY.Scan_Key() != 0) return 1;
    }
    
    if(LT768_KEY.Scan_Key_delay(200)) return 1;

    for(i=LCD_XSIZE_TFT;i>0;i--)
    {
      LT768.Main_Window_Start_XY(i,LCD_YSIZE_TFT);
      delay(1);
      if(LT768_KEY.Scan_Key() != 0) return 1;
    }
    LT768.Main_Window_Start_XY(0,LCD_YSIZE_TFT);
    
    if(LT768_KEY.Scan_Key_delay(200)) return 1;

    for(j=LCD_YSIZE_TFT;j>0;j--)
    {
      LT768.Main_Window_Start_XY(0,j);
      delay(1);
      if(LT768_KEY.Scan_Key() != 0) return 1;
    }
    LT768.Main_Window_Start_XY(0,0);
    
    if(LT768_KEY.Scan_Key_delay(200)) return 1;
  }
}





void LT768Demo::Show_Temperature(int val)
{
  int len,aLen;
  unsigned int rV,bV,cV;

  len = 559 - 367;
  aLen = (len*val)/100;

  LT768_Lib.LT768_DrawSquare_Fill(920,367,944,559 - aLen,0xDEDB);

  rV = val/3;
  if(rV>31) rV = 31;

  bV = 31- rV;

  cV = ((rV<<11)&0xF800)|((bV<<5)&0x07E0);

  LT768_Lib.LT768_DrawSquare_Fill(920,559 - aLen,944,559,cV);
}

void LT768Demo::Show_Progress1(int val)
{
  int i;

  for(i=0;i<val;i++)
  {
    LT768_Lib.LT768_DrawSquare_Fill(44+i*29 ,90,64+i*29,129,0xFCCD);
  }

  for(i=val;i<10;i++)
  {
    LT768_Lib.LT768_DrawSquare_Fill(44+i*29 ,90,64+i*29,129,0x5ACB);
  }
}

void LT768Demo::Show_Progress2(int val)
{
  int i;

  for(i=0;i<val;i++)
  {
    LT768_Lib.LT768_DrawSquare_Fill(44+i*29,211,64+i*29,250,0xFFE0);
  }

  for(i=val;i<10;i++)
  {
    LT768_Lib.LT768_DrawSquare_Fill(44+i*29,211,64+i*29,250,0x5ACB);
  }
}

void LT768Demo::Button_ON_OFF(int val)
{
  if(val)
  {
    // Voltage Level
    LT768_Lib.LT768_DrawTriangle_Fill(377,454,308,449,377,444,0xBDF7);   
    LT768_Lib.LT768_DrawTriangle_Fill(372,449,377,380,382,449,0xF81F);   

    // Strength
    LT768_Lib.LT768_DrawCircle_Fill(618,466,10,0xBDF7);  
    LT768_Lib.LT768_DrawCircle_Fill(635,437,10,0xF800);  

    
    LT768_Lib.LT768_DrawCircle_Fill(112,463,40,0xF800);  
    
    LT768_Lib.LT768_BTE_Memory_Copy(layer4_start_addr,88,0,0,layer4_start_addr,88,0,0,layer2_start_addr,LCD_XSIZE_TFT,68,525,0x0c,88,62);
  }
  else
  {
    // Voltage Level
    LT768_Lib.LT768_DrawTriangle_Fill(372,449,377,380,382,449,0xBDF7);  
    LT768_Lib.LT768_DrawTriangle_Fill(377,454,308,449,377,444,0xF81F);  

    // Strength
    LT768_Lib.LT768_DrawCircle_Fill(618,466,10,0x3800);   
    LT768_Lib.LT768_DrawCircle_Fill(635,437,10,0xBDF7);  

   
    LT768_Lib.LT768_DrawCircle_Fill(112,463,40,0x3800); 
    
    
    LT768_Lib.LT768_BTE_Memory_Copy(layer4_start_addr,88,0,62,layer4_start_addr,88,0,0,layer2_start_addr,LCD_XSIZE_TFT,68,525,0x0c,88,62);
  }
}

void LT768Demo::Show_Text(int index)
{
  LT768.CGROM_Select_Internal_CGROM();
  LT768.Foreground_color_65k(0x001F);
  LT768.Background_color_65k(0xF79E);
  LT768.Font_Select_8x16_16x16();
  LT768.Goto_Text_XY(689+3,60+index*20);
  switch(index)
  {
    case 1: LT768.Show_String("AM07:50 Level=10"); break;
    case 2: LT768.Show_String("AM07:50 Level=20"); break;
    case 3: LT768.Show_String("AM07:50 Level=30"); break;
    case 4: LT768.Show_String("AM07:50 Level=40"); break;
    case 5: LT768.Show_String("AM07:50 Level=50"); break;
    case 6: LT768.Show_String("AM07:50 Level=60"); break;
    case 7: LT768.Show_String("AM07:50 Level=70"); break;
    case 8: LT768.Show_String("AM07:50 Level=80"); break;
    case 9: LT768.Show_String("AM07:50 Level=90"); break;
    default: break;
  }
}



#define FanW 228
#define FanH 228
#define DLTIME 60

#include <math.h>

void LT768Demo::TEST_DoubleTriangle(unsigned int x,unsigned int y,unsigned int h,unsigned int h1,unsigned int l,unsigned int a,unsigned int color1,unsigned int color2)
{ 
  float cos_x = 0;
  float sin_y = 0;
  
  unsigned int x1,y1,x2,y2,x3,y3,x4,y4;
  
  if(a<=90)     // 1
  {
    cos_x = cos(a*(3.1415926/180));
    sin_y = sin(a*(3.1415926/180));
    x1 = x - h*cos_x;
    y1 = y - h*sin_y;
    
    x2 = x - l*sin_y;
    y2 = y + l*cos_x;
    
    x3 = x + l*sin_y;
    y3 = y - l*cos_x;
    
    x4 = x + h1*cos_x;
    y4 = y + h1*sin_y;
  }
  
  else if((a>90)&&(a<180))  // 2
  {
    a = 180 - a;
    cos_x = cos(a*(3.1415926/180));
    sin_y = sin(a*(3.1415926/180));
    
    x1 = x + h*cos_x;
    y1 = y - h*sin_y;

    x2 = x - l*sin_y;
    y2 = y - l*cos_x;
    
    x3 = x + l*sin_y;
    y3 = y + l*cos_x;
    
    x4 = x - h1*cos_x;
    y4 = y + h1*sin_y;
  }
   
  else if((a>=180)&&(a<270))  // 3
  {
    a = a - 180;
    cos_x = cos(a*(3.1415926/180));
    sin_y = sin(a*(3.1415926/180));
    
    x1 = x + h*cos_x;
    y1 = y + h*sin_y;

    x2 = x + l*sin_y;
    y2 = y - l*cos_x;
    
    x3 = x - l*sin_y;
    y3 = y + l*cos_x;
    
    x4 = x - h1*cos_x;
    y4 = y - h1*sin_y;
  }
  
  else if((a>=270)&&(a<360))  // 4
  {
    a = 360 - a;
    cos_x = cos(a*(3.1415926/180));
    sin_y = sin(a*(3.1415926/180));
    
    x1 = x - h*cos_x;
    y1 = y + h*sin_y;

    x2 = x + l*sin_y;
    y2 = y + l*cos_x;
    
    x3 = x - l*sin_y;
    y3 = y - l*cos_x;
    
    x4 = x + h1*cos_x;
    y4 = y - h1*sin_y;
  }
  
  LT768_Lib.LT768_DrawTriangle_Fill(x1,y1,x2,y2,x4,y4,color1);
  LT768_Lib.LT768_DrawTriangle_Fill(x1,y1,x3,y3,x4,y4,color2);
  
  LT768_Lib.LT768_DrawCircle_Fill(x,y,3,Red);
}


void LT768Demo::Pointer_Show(unsigned int a)
{
  unsigned int a1 = 0;
  unsigned int a2 = 0;
  
  if(a < 13)
  {
    a1 = 320 + 3 * a;
  }
  else
  {
    a1 = (a - 13) * 3;
  }
  
  a2 = (a * 70) / 90 + 12;
  
  LT768.Canvas_Image_Start_address(layer6_start_addr);//
  LT768.Canvas_image_width(580);
  
  LT768_Lib.LT768_BTE_Memory_Copy(layer5_start_addr,1024,240,310,
                        layer5_start_addr,1024,240,310,
                        layer6_start_addr,580,0,0,
                        0x0c,580,250
                       );
  TEST_DoubleTriangle(136,140,70,15,7,a1,0x001f,0x031f); 
      
  TEST_DoubleTriangle(433,165,65,15,7,2*a2,0x001f,0x031f); 
      
  LT768_Lib.LT768_BTE_Memory_Copy(layer6_start_addr,580,0,0,
                        layer6_start_addr,580,0,0,
                        layer2_start_addr,1024,240,310,
                        0x0c,580,250
                       );
  
  LT768.Canvas_Image_Start_address(layer2_start_addr);//
  LT768.Canvas_image_width(1024);
}

void LT768Demo::Controller_Demo(void)
{
  int  fanIndex = 0,proIndex1 = 0, proIndex2 = 0,tempIndex = 0;
  int  totalIndex = 0 , on_off_index = 1;
  int  textIndex = 0;

  LT768.Select_Main_Window_16bpp();
  LT768.Main_Image_Start_Address(layer2_start_addr);         
  LT768.Main_Image_Width(LCD_XSIZE_TFT);
  LT768.Canvas_Image_Start_address(layer2_start_addr);     
  LT768.Canvas_image_width(LCD_XSIZE_TFT);               
  LT768.Active_Window_XY(0,0);
  LT768.Active_Window_WH(LCD_XSIZE_TFT,LCD_YSIZE_TFT);     
  LT768.Main_Window_Start_XY(0,0);                        
  LT768_Lib.LT768_DMA_24bit_Block(1,0,0,0,LCD_XSIZE_TFT,LCD_YSIZE_TFT,LCD_XSIZE_TFT,Picture_5_Addr);
  

  //Fan data from Flash
  LT768.Canvas_Image_Start_address(layer3_start_addr);
  LT768.Canvas_image_width(FanW);
  LT768_Lib.LT768_DMA_24bit_Block(1,0,0,0,FanW,FanH*6,FanW,0x5dc000);   

  //ON/OFF button from Flash
  LT768.Canvas_Image_Start_address(layer4_start_addr);
  LT768.Canvas_image_width(88);
  LT768_Lib.LT768_DMA_24bit_Block(1,0,0,0,88,62*2,88,0x5dc000+0x984c0);  
  
  
  
  LT768.Canvas_Image_Start_address(layer5_start_addr);
  LT768.Canvas_image_width(1024);
  LT768_Lib.LT768_DMA_24bit_Block(1,0,0,0,1024,600,1024,Picture_5_Addr);
  
  
  

  LT768.Canvas_Image_Start_address(layer2_start_addr);       
  LT768.Canvas_image_width(LCD_XSIZE_TFT);
  LT768.Active_Window_XY(0,0);

  //Progress
  LT768_Demo.Show_Progress1(proIndex1);  
  LT768_Demo.Show_Progress2(proIndex2);   

  //Temperature
  LT768_Demo.Show_Temperature(tempIndex);

  //POWER Button
  LT768_Lib.LT768_DrawCircle(112,463,50,0x8DBC);

  LT768_Demo.Button_ON_OFF(on_off_index);

  while(LT768_KEY.Scan_Key() == 0)     
  {
    LT768_Lib.LT768_BTE_Memory_Copy(layer3_start_addr,FanW,0,FanH*fanIndex,layer3_start_addr,FanW,0,FanH*fanIndex,layer2_start_addr,LCD_XSIZE_TFT,410,54,0X0C,FanW,FanH);

    delay(DLTIME);
    if(on_off_index==0) delay(DLTIME);
    fanIndex++;
    if(fanIndex>=6) fanIndex = 0;
    totalIndex++;

    textIndex = totalIndex/10;  
    if(textIndex==0)            
    {
      LT768_Lib.LT768_DrawSquare_Fill(689,71,977,265,0xF79E); 
    }
    else Show_Text(textIndex);

    LT768_Demo.Show_Progress1(totalIndex/10); 

    proIndex2++;
    if(proIndex2>18) proIndex2 =0 ;

    LT768_Demo.Show_Progress2(proIndex2 /2);

    //Temperature
    LT768_Demo.Show_Temperature(totalIndex);

    if(totalIndex>=90)
    {
       totalIndex = 0;
       if(on_off_index==1) on_off_index = 0;
       else on_off_index = 1;
       Button_ON_OFF(on_off_index);
    }
  }
}



unsigned char LT768Demo::Cartoon_Show(void)
{
  unsigned char i = 0;
  unsigned char temp = 0;
  
  LT768.Select_Main_Window_16bpp();
  LT768.Main_Image_Start_Address(layer2_start_addr);        
  LT768.Main_Image_Width(LCD_XSIZE_TFT);
  LT768.Main_Window_Start_XY(0,0);                          
  LT768.Canvas_Image_Start_address(layer2_start_addr);       
  LT768.Canvas_image_width(LCD_XSIZE_TFT);                
  LT768.Active_Window_XY(0,0);
  LT768.Active_Window_WH(LCD_XSIZE_TFT,LCD_YSIZE_TFT);       
  LT768_Lib.LT768_DrawSquare_Fill(0,0,LCD_XSIZE_TFT,LCD_YSIZE_TFT,Blue2);
  LT768_Lib.LT768_DMA_24bit_Block(1,0,0,0,LCD_XSIZE_TFT,LCD_YSIZE_TFT,LCD_XSIZE_TFT,Picture_3_Addr);
  
  LT768.Canvas_image_width(320);
  LT768.Canvas_Image_Start_address(layer3_start_addr);
  LT768_Lib.LT768_DMA_24bit_Block(1,0,0,0,320,240*25,320,Cartoon_Addr);
                        
  while(1)
  {
    for(i = 0 ; i < 25 ; i++)
    {
      LT768_Lib.LT768_BTE_Memory_Copy(layer3_start_addr,320,0,240*i,
                            layer3_start_addr,320,0,240*i,
                            layer2_start_addr,LCD_XSIZE_TFT,100,35,0X0C,320,240);
      
      LT768_Lib.LT768_BTE_Memory_Copy(layer3_start_addr,320,0,240*i,
                            layer3_start_addr,320,0,240*i,
                            layer2_start_addr,LCD_XSIZE_TFT,100,320,0X0C,320,240);
      
      temp = i + 10;
      if(temp > 24) temp = temp - 24;
      
      LT768_Lib.LT768_BTE_Memory_Copy(layer3_start_addr,320,0,240*temp,
                            layer3_start_addr,320,0,240*temp,
                            layer2_start_addr,LCD_XSIZE_TFT,600,35,0X0C,320,240);
      
      LT768_Lib.LT768_BTE_Memory_Copy(layer3_start_addr,320,0,240*temp,
                            layer3_start_addr,320,0,240*temp,
                            layer2_start_addr,LCD_XSIZE_TFT,600,320,0X0C,320,240);
        
      if(LT768_KEY.Scan_Key_delay(100)) return 1;
    }
  }
}

#define Main_UI_Lay 0xbb8000

unsigned char Point = 1;

#define LIST_NUM 16

#define FirstRow_X1   40
#define FirstRow_Y1   110
#define FirstRow_X2   460
#define FirstRow_Y2   144

#define SecondRow_X1  560
#define SecondRow_Y1  110
#define SecondRow_X2  980
#define SecondRow_Y2  144

#define Offset        3
void LT768Demo::Main_GUI(void)
{
  LT768.Select_Main_Window_16bpp();
  LT768.Main_Image_Start_Address(layer1_start_addr);         
  LT768.Main_Image_Width(LCD_XSIZE_TFT);
  LT768.Main_Window_Start_XY(0,0);                        
  LT768.Canvas_Image_Start_address(layer1_start_addr);      
  LT768.Canvas_image_width(LCD_XSIZE_TFT);              
  LT768.Active_Window_XY(0,0);
  LT768.Active_Window_WH(LCD_XSIZE_TFT,LCD_YSIZE_TFT);      
  LT768_Lib.LT768_DrawSquare_Fill(0,0,LCD_XSIZE_TFT,LCD_YSIZE_TFT,Blue2);
  
  LT768_Lib.LT768_Select_Outside_Font_Init(1,0,FLASH_ADDR_32,MEMORY_ADDR_32,SIZE_32_NUM,32,2,2,0,0);

  LT768_Lib.LT768_Print_Outside_Font_String(180,15,Red,Blue2,(unsigned char*)"LT768_DEMO(128Mbit)");
  LT768_Lib.LT768_DrawSquare_Fill(180,82,775,85,Red);

  LT768.Font_Width_X1();
  LT768.Font_Height_X1();
  
  LT768_Lib.LT768_DrawSquare_Width(FirstRow_X1,FirstRow_Y1    ,FirstRow_X2,FirstRow_Y2    ,Black,Blue2,3);   // 1
  LT768_Lib.LT768_DrawSquare_Width(FirstRow_X1,FirstRow_Y1+60 ,FirstRow_X2,FirstRow_Y2+60 ,Black,Blue2,3);   // 2
  LT768_Lib.LT768_DrawSquare_Width(FirstRow_X1,FirstRow_Y1+120,FirstRow_X2,FirstRow_Y2+120,Black,Blue2,3);   // 3
  LT768_Lib.LT768_DrawSquare_Width(FirstRow_X1,FirstRow_Y1+180,FirstRow_X2,FirstRow_Y2+180,Black,Blue2,3);   // 4
  LT768_Lib.LT768_DrawSquare_Width(FirstRow_X1,FirstRow_Y1+240,FirstRow_X2,FirstRow_Y2+240,Black,Blue2,3);   // 5
  LT768_Lib.LT768_DrawSquare_Width(FirstRow_X1,FirstRow_Y1+300,FirstRow_X2,FirstRow_Y2+300,Black,Blue2,3);   // 6
  LT768_Lib.LT768_DrawSquare_Width(FirstRow_X1,FirstRow_Y1+360,FirstRow_X2,FirstRow_Y2+360,Black,Blue2,3);   // 7
  LT768_Lib.LT768_DrawSquare_Width(FirstRow_X1,FirstRow_Y1+420,FirstRow_X2,FirstRow_Y2+420,Black,Blue2,3);   // 8

  LT768_Lib.LT768_DrawSquare_Width(SecondRow_X1,SecondRow_Y1    ,SecondRow_X2,SecondRow_Y2,   Black,Blue2,3); // 9
  LT768_Lib.LT768_DrawSquare_Width(SecondRow_X1,SecondRow_Y1+60 ,SecondRow_X2,SecondRow_Y2+60,Black,Blue2,3); // 10
  LT768_Lib.LT768_DrawSquare_Width(SecondRow_X1,SecondRow_Y1+120,SecondRow_X2,SecondRow_Y2+120,Black,Blue2,3); // 11
  LT768_Lib.LT768_DrawSquare_Width(SecondRow_X1,SecondRow_Y1+180,SecondRow_X2,SecondRow_Y2+180,Black,Blue2,3); // 12
  LT768_Lib.LT768_DrawSquare_Width(SecondRow_X1,SecondRow_Y1+240,SecondRow_X2,SecondRow_Y2+240,Black,Blue2,3); // 13
  LT768_Lib.LT768_DrawSquare_Width(SecondRow_X1,SecondRow_Y1+300,SecondRow_X2,SecondRow_Y2+300,Black,Blue2,3); // 14
  LT768_Lib.LT768_DrawSquare_Width(SecondRow_X1,SecondRow_Y1+360,SecondRow_X2,SecondRow_Y2+360,Black,Blue2,3); // 15
  LT768_Lib.LT768_DrawSquare_Width(SecondRow_X1,SecondRow_Y1+420,SecondRow_X2,SecondRow_Y2+420,Black,Blue2,3); // 16

  LT768_Lib.LT768_Print_Outside_Font_String(FirstRow_X1+Offset,FirstRow_Y1    ,White,Blue2,(unsigned char*)"1.Display_Levetop");
  LT768_Lib.LT768_Print_Outside_Font_String(FirstRow_X1+Offset,FirstRow_Y1+60 ,White,Blue2,(unsigned char*)"2.Draw_Circle_Ellipse");
  LT768_Lib.LT768_Print_Outside_Font_String(FirstRow_X1+Offset,FirstRow_Y1+120,White,Blue2,(unsigned char*)"3.Draw_Line_Curve");
  LT768_Lib.LT768_Print_Outside_Font_String(FirstRow_X1+Offset,FirstRow_Y1+180,White,Blue2,(unsigned char*)"4.Draw_Rectangle");
  LT768_Lib.LT768_Print_Outside_Font_String(FirstRow_X1+Offset,FirstRow_Y1+240,White,Blue2,(unsigned char*)"5.Draw_Polygon");
  LT768_Lib.LT768_Print_Outside_Font_String(FirstRow_X1+Offset,FirstRow_Y1+300,White,Blue2,(unsigned char*)"6.Draw_Table");   
  LT768_Lib.LT768_Print_Outside_Font_String(FirstRow_X1+Offset,FirstRow_Y1+360,White,Blue2,(unsigned char*)"7.Draw_Pillar_Demo");
  LT768_Lib.LT768_Print_Outside_Font_String(FirstRow_X1+Offset,FirstRow_Y1+420,White,Blue2,(unsigned char*)"8.DMA_Demo");

  LT768_Lib.LT768_Print_Outside_Font_String(SecondRow_X1+Offset,SecondRow_Y1    ,White,Blue2,(unsigned char*)"9.Slide_frame_buffer");
  LT768_Lib.LT768_Print_Outside_Font_String(SecondRow_X1+Offset,SecondRow_Y1+60 ,White,Blue2,(unsigned char*)"10.Text_Demo");
  LT768_Lib.LT768_Print_Outside_Font_String(SecondRow_X1+Offset,SecondRow_Y1+120,White,Blue2,(unsigned char*)"11.Outside_Font");
  LT768_Lib.LT768_Print_Outside_Font_String(SecondRow_X1+Offset,SecondRow_Y1+180,White,Blue2,(unsigned char*)"12.PIP_Demo");
  LT768_Lib.LT768_Print_Outside_Font_String(SecondRow_X1+Offset,SecondRow_Y1+240,White,Blue2,(unsigned char*)"13.App_Demo_BTE");
  LT768_Lib.LT768_Print_Outside_Font_String(SecondRow_X1+Offset,SecondRow_Y1+300,White,Blue2,(unsigned char*)"14.App_Demo_Alpha_Blending");
  LT768_Lib.LT768_Print_Outside_Font_String(SecondRow_X1+Offset,SecondRow_Y1+360,White,Blue2,(unsigned char*)"15.Controller_Demo");
  LT768_Lib.LT768_Print_Outside_Font_String(SecondRow_X1+Offset,SecondRow_Y1+420,White,Blue2,(unsigned char*)"16.Cartoon_Show");

}


unsigned char LT768Demo::Select_Function(void)
{
  unsigned char key = 0;
  unsigned char first = 0;
  unsigned char function = 0;
  unsigned char flag = 0;
  
  LT768.Select_Main_Window_16bpp();
  LT768.Main_Image_Start_Address(layer1_start_addr);        
  LT768.Main_Image_Width(LCD_XSIZE_TFT);
  LT768.Canvas_Image_Start_address(layer1_start_addr);    
  LT768.Canvas_image_width(LCD_XSIZE_TFT);               
  LT768.Active_Window_XY(0,0);
  LT768.Active_Window_WH(LCD_XSIZE_TFT,LCD_YSIZE_TFT);  
  LT768.Main_Window_Start_XY(0,0);                    
  
  LT768_Lib.LT768_Select_Outside_Font_Init(1,0,FLASH_ADDR_32,MEMORY_ADDR_32,SIZE_32_NUM,32,1,1,0,0);
  
  while(1)
  {
    if(first == 1)
    {
      key = LT768_KEY.Scan_FunctionKey();
    
      if(key == 2)  
      {
        Point--;
        if(Point<1) Point = 16;
      }
      else if(key == 1)
      {
        Point++;
        if(Point>16)  Point = 1;
      }
      else
      {
        function = 1;
      }
    }
    else
    {
      first = 1;
    }
    
    
      
      
      switch(Point)
      {
        case 1: LT768_Lib.LT768_DrawSquare_Width(SecondRow_X1,SecondRow_Y1+420,SecondRow_X2,SecondRow_Y2+420,Black,Blue2,3); // 16
                LT768_Lib.LT768_Print_Outside_Font_String(SecondRow_X1+Offset,SecondRow_Y1+420,White,Blue2,(unsigned char*)"16.Cartoon_Show");
                LT768_Lib.LT768_DrawSquare_Width(FirstRow_X1,FirstRow_Y1+60,FirstRow_X2,FirstRow_Y2+60,Black,Blue2,3);   // 2
                LT768_Lib.LT768_Print_Outside_Font_String(FirstRow_X1+Offset,FirstRow_Y1+60,White,Blue2,(unsigned char*)"2.Draw_Circle_Ellipse");
                LT768_Lib.LT768_DrawSquare_Width(FirstRow_X1,FirstRow_Y1,FirstRow_X2,FirstRow_Y2,Black,Blue,3);   // 1
                LT768_Lib.LT768_Print_Outside_Font_String(FirstRow_X1+Offset,FirstRow_Y1,Green,Blue,(unsigned char*)"1.Display_Levetop");
                if(function == 1)
                {
                  LT768_Demo.Display_Levetop();
                  return 1;
                }
                break;

        case 2: LT768_Lib.LT768_DrawSquare_Width(FirstRow_X1,FirstRow_Y1,FirstRow_X2,FirstRow_Y2,Black,Blue2,3);   // 1
                LT768_Lib.LT768_Print_Outside_Font_String(FirstRow_X1+Offset,FirstRow_Y1,White,Blue2,(unsigned char*)"1.Display_Levetop");
                LT768_Lib.LT768_DrawSquare_Width(FirstRow_X1,FirstRow_Y1+120,FirstRow_X2,FirstRow_Y2+120,Black,Blue2,3);   // 3             
                LT768_Lib.LT768_Print_Outside_Font_String(FirstRow_X1+Offset,FirstRow_Y1+120,White,Blue2,(unsigned char*)"3.Draw_Line_Curve");
                LT768_Lib.LT768_DrawSquare_Width(FirstRow_X1,FirstRow_Y1+60,FirstRow_X2,FirstRow_Y2+60,Black,Blue,3);   // 2
                LT768_Lib.LT768_Print_Outside_Font_String(FirstRow_X1+Offset,FirstRow_Y1+60,Green,Blue,(unsigned char*)"2.Draw_Circle_Ellipse");
                if(function == 1)
                {
                  LT768_Demo.Draw_Circle_Ellipse();
                  return 1;
                }
                break;

        case 3: LT768_Lib.LT768_DrawSquare_Width(FirstRow_X1,FirstRow_Y1+60,FirstRow_X2,FirstRow_Y2+60,Black,Blue2,3);   // 2
                LT768_Lib.LT768_Print_Outside_Font_String(FirstRow_X1+Offset,FirstRow_Y1+60,White,Blue2,(unsigned char*)"2.Draw_Circle_Ellipse");
                LT768_Lib.LT768_DrawSquare_Width(FirstRow_X1,FirstRow_Y1+180,FirstRow_X2,FirstRow_Y2+180,Black,Blue2,3);   // 4
                LT768_Lib.LT768_Print_Outside_Font_String(FirstRow_X1+Offset,FirstRow_Y1+180,White,Blue2,(unsigned char*)"4.Draw_Rectangle");
                LT768_Lib.LT768_DrawSquare_Width(FirstRow_X1,FirstRow_Y1+120,FirstRow_X2,FirstRow_Y2+120,Black,Blue,3);   // 3
                LT768_Lib.LT768_Print_Outside_Font_String(FirstRow_X1+Offset,FirstRow_Y1+120,Green,Blue,(unsigned char*)"3.Draw_Line_Curve");
                if(function == 1)
                {
                  LT768_Demo.Draw_Line_Curve();  
                  return 1;
                }
            break;

        case 4: LT768_Lib.LT768_DrawSquare_Width(FirstRow_X1,FirstRow_Y1+120,FirstRow_X2,FirstRow_Y2+120,Black,Blue2,3);   // 3             
                LT768_Lib.LT768_Print_Outside_Font_String(FirstRow_X1+Offset,FirstRow_Y1+120,White,Blue2,(unsigned char*)"3.Draw_Line_Curve");
                LT768_Lib.LT768_DrawSquare_Width(FirstRow_X1,FirstRow_Y1+240,FirstRow_X2,FirstRow_Y2+240,Black,Blue2,3);   // 5
                LT768_Lib.LT768_Print_Outside_Font_String(FirstRow_X1+Offset,FirstRow_Y1+240,White,Blue2,(unsigned char*)"5.Draw_Polygon");
                LT768_Lib.LT768_DrawSquare_Width(FirstRow_X1,FirstRow_Y1+180,FirstRow_X2,FirstRow_Y2+180,Black,Blue,3);   // 4
                LT768_Lib.LT768_Print_Outside_Font_String(FirstRow_X1+Offset,FirstRow_Y1+180,Green,Blue,(unsigned char*)"4.Draw_Rectangle");
                if(function == 1)
                {
                  LT768_Demo.Draw_Rectangle();
                  return 1;
                }
                break;

        case 5: LT768_Lib.LT768_DrawSquare_Width(FirstRow_X1,FirstRow_Y1+180,FirstRow_X2,FirstRow_Y2+180,Black,Blue2,3);   // 4
                LT768_Lib.LT768_Print_Outside_Font_String(FirstRow_X1+Offset,FirstRow_Y1+180,White,Blue2,(unsigned char*)"4.Draw_Rectangle");
                LT768_Lib.LT768_DrawSquare_Width(FirstRow_X1,FirstRow_Y1+300,FirstRow_X2,FirstRow_Y2+300,Black,Blue2,3);   // 6             
                LT768_Lib.LT768_Print_Outside_Font_String(FirstRow_X1+Offset,FirstRow_Y1+300,White,Blue2,(unsigned char*)"6.Draw_Table");
                LT768_Lib.LT768_DrawSquare_Width(FirstRow_X1,FirstRow_Y1+240,FirstRow_X2,FirstRow_Y2+240,Black,Blue,3);   // 5
                LT768_Lib.LT768_Print_Outside_Font_String(FirstRow_X1+Offset,FirstRow_Y1+240,Green,Blue,(unsigned char*)"5.Draw_Polygon");
                if(function == 1)
                {
                  LT768_Demo.Draw_Polygon();
                  return 1;
                }
                break;

        case 6: LT768_Lib.LT768_DrawSquare_Width(FirstRow_X1,FirstRow_Y1+240,FirstRow_X2,FirstRow_Y2+240,Black,Blue2,3);   // 5
                LT768_Lib.LT768_Print_Outside_Font_String(FirstRow_X1+Offset,FirstRow_Y1+240,White,Blue2,(unsigned char*)"5.Draw_Polygon");
                LT768_Lib.LT768_DrawSquare_Width(FirstRow_X1,FirstRow_Y1+360,FirstRow_X2,FirstRow_Y2+360,Black,Blue2,3);   // 7
                LT768_Lib.LT768_Print_Outside_Font_String(FirstRow_X1+Offset,FirstRow_Y1+360,White,Blue2,(unsigned char*)"7.Draw_Pillar_Demo");
                LT768_Lib.LT768_DrawSquare_Width(FirstRow_X1,FirstRow_Y1+300,FirstRow_X2,FirstRow_Y2+300,Black,Blue,3);   // 6
                LT768_Lib.LT768_Print_Outside_Font_String(FirstRow_X1+Offset,FirstRow_Y1+300,Green,Blue,(unsigned char*)"6.Draw_Table");
                if(function == 1)
                {
                  LT768_Demo.Draw_Table();
                  return 1;
                }
                break;

        case 7: LT768_Lib.LT768_DrawSquare_Width(FirstRow_X1,FirstRow_Y1+300,FirstRow_X2,FirstRow_Y2+300,Black,Blue2,3);   // 6             
                LT768_Lib.LT768_Print_Outside_Font_String(FirstRow_X1+Offset,FirstRow_Y1+300,White,Blue2,(unsigned char*)"6.Draw_Table");
                LT768_Lib.LT768_DrawSquare_Width(FirstRow_X1,FirstRow_Y1+420,FirstRow_X2,FirstRow_Y2+420,Black,Blue2,3);   // 8
                LT768_Lib.LT768_Print_Outside_Font_String(FirstRow_X1+Offset,FirstRow_Y1+420,White,Blue2,(unsigned char*)"8.DMA_Demo");
                LT768_Lib.LT768_DrawSquare_Width(FirstRow_X1,FirstRow_Y1+360,FirstRow_X2,FirstRow_Y2+360,Black,Blue,3);   // 7
                LT768_Lib.LT768_Print_Outside_Font_String(FirstRow_X1+Offset,FirstRow_Y1+360,Green,Blue,(unsigned char*)"7.Draw_Pillar_Demo");
                if(function == 1)
                {
                  LT768_Demo.Draw_Pillar_Demo();
                  return 1;
                }
                break;

        case 8: LT768_Lib.LT768_DrawSquare_Width(FirstRow_X1,FirstRow_Y1+360,FirstRow_X2,FirstRow_Y2+360,Black,Blue2,3);   // 7
                LT768_Lib.LT768_Print_Outside_Font_String(FirstRow_X1+Offset,FirstRow_Y1+360,White,Blue2,(unsigned char*)"7.Draw_Pillar_Demo");
                LT768_Lib.LT768_DrawSquare_Width(SecondRow_X1,SecondRow_Y1,SecondRow_X2,SecondRow_Y2,Black,Blue2,3); // 9                
                LT768_Lib.LT768_Print_Outside_Font_String(SecondRow_X1+Offset,SecondRow_Y1,White,Blue2,(unsigned char*)"9.Slide_frame_buffer");
                LT768_Lib.LT768_DrawSquare_Width(FirstRow_X1,FirstRow_Y1+420,FirstRow_X2,FirstRow_Y2+420,Black,Blue,3);   // 8
                LT768_Lib.LT768_Print_Outside_Font_String(FirstRow_X1+Offset,FirstRow_Y1+420,Green,Blue,(unsigned char*)"8.DMA_Demo");
                if(function == 1)
                {
                  LT768_Demo.DMA_Demo();
                  return 1;
                }
                break;

        case 9: LT768_Lib.LT768_DrawSquare_Width(FirstRow_X1,FirstRow_Y1+420,FirstRow_X2,FirstRow_Y2+420,Black,Blue2,3);   // 8
                LT768_Lib.LT768_Print_Outside_Font_String(FirstRow_X1+Offset,FirstRow_Y1+420,White,Blue2,(unsigned char*)"8.DMA_Demo");
                LT768_Lib.LT768_DrawSquare_Width(SecondRow_X1,SecondRow_Y1+60,SecondRow_X2,SecondRow_Y2+60,Black,Blue2,3); // 10
                LT768_Lib.LT768_Print_Outside_Font_String(SecondRow_X1+Offset,SecondRow_Y1+60,White,Blue2,(unsigned char*)"10.Text_Demo");
                LT768_Lib.LT768_DrawSquare_Width(SecondRow_X1,SecondRow_Y1,SecondRow_X2,SecondRow_Y2,Black,Blue,3); // 9
                LT768_Lib.LT768_Print_Outside_Font_String(SecondRow_X1+Offset,SecondRow_Y1,Green,Blue,(unsigned char*)"9.Slide_frame_buffer");
                if(function == 1)
                {
                  LT768_Demo.App_Demo_slide_frame_buffer();
                  return 1;
                }
                break;

        case 10: LT768_Lib.LT768_DrawSquare_Width(SecondRow_X1,SecondRow_Y1,SecondRow_X2,SecondRow_Y2,Black,Blue2,3); // 9                 
                 LT768_Lib.LT768_Print_Outside_Font_String(SecondRow_X1+Offset,SecondRow_Y1,White,Blue2,(unsigned char*)"9.Slide_frame_buffer");
                 LT768_Lib.LT768_DrawSquare_Width(SecondRow_X1,SecondRow_Y1+120,SecondRow_X2,SecondRow_Y2+120,Black,Blue2,3); // 11
                 LT768_Lib.LT768_Print_Outside_Font_String(SecondRow_X1+Offset,SecondRow_Y1+120,White,Blue2,(unsigned char*)"11.Outside_Font");
                 LT768_Lib.LT768_DrawSquare_Width(SecondRow_X1,SecondRow_Y1+60,SecondRow_X2,SecondRow_Y2+60,Black,Blue,3); // 10
                 LT768_Lib.LT768_Print_Outside_Font_String(SecondRow_X1+Offset,SecondRow_Y1+60,Green,Blue,(unsigned char*)"10.Text_Demo");
                if(function == 1)
                 {
                   LT768_Demo.Text_Demo();
                   LT768_Lib.LT768_Disable_Text_Cursor(); 
                   LT768_Lib.LT768_Disable_Graphic_Cursor();
                   return 1;
                 }
                 break;

        case 11: LT768_Lib.LT768_DrawSquare_Width(SecondRow_X1,SecondRow_Y1+60,SecondRow_X2,SecondRow_Y2+60,Black,Blue2,3); // 10
                 LT768_Lib.LT768_Print_Outside_Font_String(SecondRow_X1+Offset,SecondRow_Y1+60,White,Blue2,(unsigned char*)"10.Text_Demo");
                 LT768_Lib.LT768_DrawSquare_Width(SecondRow_X1,SecondRow_Y1+180,SecondRow_X2,SecondRow_Y2+180,Black,Blue2,3); // 12                
                 LT768_Lib.LT768_Print_Outside_Font_String(SecondRow_X1+Offset,SecondRow_Y1+180,White,Blue2,(unsigned char*)"12.PIP_Demo");
                 LT768_Lib.LT768_DrawSquare_Width(SecondRow_X1,SecondRow_Y1+120,SecondRow_X2,SecondRow_Y2+120,Black,Blue,3); // 11
                 LT768_Lib.LT768_Print_Outside_Font_String(SecondRow_X1+Offset,SecondRow_Y1+120,Green,Blue,(unsigned char*)"11.Outside_Font");
                 if(function == 1)
                 {
                   LT768_Demo.Outside_Font();
                   return 1;
                 }
                 break;

        case 12: LT768_Lib.LT768_DrawSquare_Width(SecondRow_X1,SecondRow_Y1+120,SecondRow_X2,SecondRow_Y2+120,Black,Blue2,3); // 11
                 LT768_Lib.LT768_Print_Outside_Font_String(SecondRow_X1+Offset,SecondRow_Y1+120,White,Blue2,(unsigned char*)"11.Outside_Font");
                 LT768_Lib.LT768_DrawSquare_Width(SecondRow_X1,SecondRow_Y1+240,SecondRow_X2,SecondRow_Y2+240,Black,Blue2,3); // 13         
                 LT768_Lib.LT768_Print_Outside_Font_String(SecondRow_X1+Offset,SecondRow_Y1+240,White,Blue2,(unsigned char*)"13.App_Demo_BTE");
                 LT768_Lib.LT768_DrawSquare_Width(SecondRow_X1,SecondRow_Y1+180,SecondRow_X2,SecondRow_Y2+180,Black,Blue,3); // 12
                 LT768_Lib.LT768_Print_Outside_Font_String(SecondRow_X1+Offset,SecondRow_Y1+180,Green,Blue,(unsigned char*)"12.PIP_Demo");
                 if(function == 1)
                 {
                   LT768_Demo.PIP_Demo();
                   LT768.Disable_PIP1();  
                   LT768.Disable_PIP2();
                   return 1;
                 }
                 break;

        case 13: LT768_Lib.LT768_DrawSquare_Width(SecondRow_X1,SecondRow_Y1+180,SecondRow_X2,SecondRow_Y2+180,Black,Blue2,3); // 12                
                 LT768_Lib.LT768_Print_Outside_Font_String(SecondRow_X1+Offset,SecondRow_Y1+180,White,Blue2,(unsigned char*)"12.PIP_Demo");
                 LT768_Lib.LT768_DrawSquare_Width(SecondRow_X1,SecondRow_Y1+300,SecondRow_X2,SecondRow_Y2+300,Black,Blue2,3); // 14
                 LT768_Lib.LT768_Print_Outside_Font_String(SecondRow_X1+Offset,SecondRow_Y1+300,White,Blue2,(unsigned char*)"14.App_Demo_Alpha_Blending");
                 LT768_Lib.LT768_DrawSquare_Width(SecondRow_X1,SecondRow_Y1+240,SecondRow_X2,SecondRow_Y2+240,Black,Blue,3); // 13
                 LT768_Lib.LT768_Print_Outside_Font_String(SecondRow_X1+Offset,SecondRow_Y1+240,Green,Blue,(unsigned char*)"13.App_Demo_BTE");
                 if(function == 1)
                 {
                   LT768_Demo.App_Demo_BTE();
                   return 1;
                 }
                 break;

        case 14: LT768_Lib.LT768_DrawSquare_Width(SecondRow_X1,SecondRow_Y1+240,SecondRow_X2,SecondRow_Y2+240,Black,Blue2,3); // 13         
                 LT768_Lib.LT768_Print_Outside_Font_String(SecondRow_X1+Offset,SecondRow_Y1+240,White,Blue2,(unsigned char*)"13.App_Demo_BTE");
                 LT768_Lib.LT768_DrawSquare_Width(SecondRow_X1,SecondRow_Y1+360,SecondRow_X2,SecondRow_Y2+360,Black,Blue2,3); // 15
                 LT768_Lib.LT768_Print_Outside_Font_String(SecondRow_X1+Offset,SecondRow_Y1+360,White,Blue2,(unsigned char*)"15.Controller_Demo");
                 LT768_Lib.LT768_DrawSquare_Width(SecondRow_X1,SecondRow_Y1+300,SecondRow_X2,SecondRow_Y2+300,Black,Blue,3); // 14
                 LT768_Lib.LT768_Print_Outside_Font_String(SecondRow_X1+Offset,SecondRow_Y1+300,Green,Blue,(unsigned char*)"14.App_Demo_Alpha_Blending");
                 if(function == 1)
                 {
                   LT768_Demo.App_Demo_Alpha_Blending();
                   return 1;
                 }
                 break;

        case 15: LT768_Lib.LT768_DrawSquare_Width(SecondRow_X1,SecondRow_Y1+300,SecondRow_X2,SecondRow_Y2+300,Black,Blue2,3); // 14
                 LT768_Lib.LT768_Print_Outside_Font_String(SecondRow_X1+Offset,SecondRow_Y1+300,White,Blue2,(unsigned char*)"14.App_Demo_Alpha_Blending");
                 LT768_Lib.LT768_DrawSquare_Width(SecondRow_X1,SecondRow_Y1+420,SecondRow_X2,SecondRow_Y2+420,Black,Blue2,3); // 16
                 LT768_Lib.LT768_Print_Outside_Font_String(SecondRow_X1+Offset,SecondRow_Y1+420,White,Blue2,(unsigned char*)"16.Cartoon_Show");
                 LT768_Lib.LT768_DrawSquare_Width(SecondRow_X1,SecondRow_Y1+360,SecondRow_X2,SecondRow_Y2+360,Black,Blue,3); // 15
                 LT768_Lib.LT768_Print_Outside_Font_String(SecondRow_X1+Offset,SecondRow_Y1+360,Green,Blue,(unsigned char*)"15.Controller_Demo");
                 if(function == 1)
                 {
                   LT768_Demo.Controller_Demo();
                   return 1;
                 }
                 break;

        case 16: LT768_Lib.LT768_DrawSquare_Width(SecondRow_X1,SecondRow_Y1+360,SecondRow_X2,SecondRow_Y2+360,Black,Blue2,3); // 15
                 LT768_Lib.LT768_Print_Outside_Font_String(SecondRow_X1+Offset,SecondRow_Y1+360,White,Blue2,(unsigned char*)"15.Controller_Demo");
                 LT768_Lib.LT768_DrawSquare_Width(FirstRow_X1,FirstRow_Y1,FirstRow_X2,FirstRow_Y2,Black,Blue2,3);   // 1
                 LT768_Lib.LT768_Print_Outside_Font_String(FirstRow_X1+Offset,FirstRow_Y1,White,Blue2,(unsigned char*)"1.Display_Levetop");
                 LT768_Lib.LT768_DrawSquare_Width(SecondRow_X1,SecondRow_Y1+420,SecondRow_X2,SecondRow_Y2+420,Black,Blue,3); // 16
                 LT768_Lib.LT768_Print_Outside_Font_String(SecondRow_X1+Offset,SecondRow_Y1+420,Green,Blue,(unsigned char*)"16.Cartoon_Show");               
                 if(function == 1)
                 {        
                   LT768_Demo.Cartoon_Show();                 
                   return 1;
                 }
                 break;

        default:
                break;
      }

  }
}

LT768Demo LT768_Demo=LT768Demo();