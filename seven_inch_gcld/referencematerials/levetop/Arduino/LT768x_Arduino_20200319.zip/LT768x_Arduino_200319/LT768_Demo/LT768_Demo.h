#ifndef LT768_Demo_h
#define LT768_Demo_h

#include "Arduino.h"
#include "LT768_LCD.h"
#include "LT768.h"
#include "LT768_Lib.h"
#include "LT768_KEY.h"
#include <SPI.h>
#include <Wire.h>

#define LCD_XSIZE_TFT    1024
#define LCD_YSIZE_TFT    600

#define FLASH_ADDR_16   0x00829150
#define FLASH_ADDR_24   0x0078DC20
#define FLASH_ADDR_32   0x00679A10

#define SIZE_16_NUM     0x00045080
#define SIZE_24_NUM     0x0009B520
#define SIZE_32_NUM     0x00114200

#define MEMORY_ADDR_32  0x5dc000
#define MEMORY_ADDR_24  (MEMORY_ADDR_32+0x0009B520)
#define MEMORY_ADDR_16  (MEMORY_ADDR_24+0x00045080)

#define Picture_1_Addr  0
#define Picture_2_Addr  0x12c000//(LCD_XSIZE_TFT*LCD_YSIZE_TFT*2);
#define Picture_3_Addr  0x258000//(LCD_XSIZE_TFT*LCD_YSIZE_TFT*2*2);
#define Picture_4_Addr  0x384000//(LCD_XSIZE_TFT*LCD_YSIZE_TFT*2*3);
#define Picture_5_Addr  0x4b0000//(LCD_XSIZE_TFT*LCD_YSIZE_TFT*2*4);

#define Cartoon_Addr  0x0086E0E1

#define layer1_start_addr 0
#define layer2_start_addr 0x12c000//LCD_XSIZE_TFT*LCD_YSIZE_TFT*2
#define layer3_start_addr 0x258000//LCD_XSIZE_TFT*LCD_YSIZE_TFT*2*2
#define layer4_start_addr 0x384000//LCD_XSIZE_TFT*LCD_YSIZE_TFT*2*3
#define layer5_start_addr 0x4b0000//LCD_XSIZE_TFT*LCD_YSIZE_TFT*2*4
#define layer6_start_addr 0x5dc000//LCD_XSIZE_TFT*LCD_YSIZE_TFT*2*5
#define layer7_start_addr 0x708000//LCD_XSIZE_TFT*LCD_YSIZE_TFT*2*6

#define Resolution  (LCD_XSIZE_TFT*LCD_YSIZE_TFT)  

/* ----color256----- */
#define color256_black   0x00
#define color256_white   0xff
#define color256_red     0xe0
#define color256_green   0x1c
#define color256_blue    0x03
#define color256_yellow  color256_red|color256_green
#define color256_cyan    color256_green|color256_blue
#define color256_purple  color256_red|color256_blue

/*color65k*/
#define White          0xFFFF
#define Black          0x0000
#define Grey           0xF7DE
#define Blue           0x001F
#define Blue2          0x051F
#define Red            0xF800
#define Magenta        0xF81F
#define Green          0x07E0
#define Cyan           0x7FFF
#define Yellow         0xFFE0
#define color65k_black   0x0000
#define color65k_white   0xffff
#define color65k_red     0xf800
#define color65k_green   0x07e0
#define color65k_blue    0x001f
#define color65k_yellow  color65k_red|color65k_green
#define color65k_cyan    color65k_green|color65k_blue
#define color65k_purple  color65k_red|color65k_blue

#define color65k_grayscale1    2113
#define color65k_grayscale2    2113*2
#define color65k_grayscale3    2113*3
#define color65k_grayscale4    2113*4
#define color65k_grayscale5    2113*5
#define color65k_grayscale6    2113*6
#define color65k_grayscale7    2113*7
#define color65k_grayscale8    2113*8
#define color65k_grayscale9    2113*9
#define color65k_grayscale10   2113*10
#define color65k_grayscale11   2113*11
#define color65k_grayscale12   2113*12
#define color65k_grayscale13   2113*13
#define color65k_grayscale14   2113*14
#define color65k_grayscale15   2113*15
#define color65k_grayscale16   2113*16
#define color65k_grayscale17   2113*17
#define color65k_grayscale18   2113*18
#define color65k_grayscale19   2113*19
#define color65k_grayscale20   2113*20
#define color65k_grayscale21   2113*21
#define color65k_grayscale22   2113*22
#define color65k_grayscale23   2113*23
#define color65k_grayscale24   2113*24
#define color65k_grayscale25   2113*25
#define color65k_grayscale26   2113*26
#define color65k_grayscale27   2113*27
#define color65k_grayscale28   2113*28
#define color65k_grayscale29   2113*29
#define color65k_grayscale30   2113*30

/*color16M*/
#define color16M_black   0x00000000
#define color16M_white   0x00ffffff
#define color16M_red     0x00ff0000
#define color16M_green   0x0000ff00
#define color16M_blue    0x000000ff
#define color16M_yellow  color16M_red|color16M_green
#define color16M_cyan    color16M_green|color16M_blue
#define color16M_purple  color16M_red|color16M_blue

#define Line0          0
#define Line1          24
#define Line2          48
#define Line3          72
#define Line4          96
#define Line5          120
#define Line6          144
#define Line7          168
#define Line8          192
#define Line9          216
#define Line10         240
#define Line11         264
#define Line12         288
#define Line13         312
#define Line14         336
#define Line15         360
#define Line16         384
#define Line17         408
#define Line18         432
#define Line19         456
#define Line20         480
#define Line21         504
#define Line22         528
#define Line23         552
#define Line24         576
#define Line25         600


class LT768Demo
{
	private:
		
	public:
	void StartUp_picture(void);
	void Display_Levetop(void);
	unsigned char Draw_Circle_Ellipse(void);
	unsigned char Draw_Line_Curve(void);
	unsigned short abs1(int val);
	unsigned char Draw_Rectangle(void);
	unsigned char Draw_Pentagon(void);
	unsigned char Draw_Triangle(void);
	unsigned char Draw_Polygon(void);
	unsigned char Draw_Table(void);
	unsigned char Draw_Pillar_Demo(void);
	unsigned char DMA_Demo(void);
	unsigned char Text_Demo(void);
	unsigned char Outside_Font(void);
	unsigned char PIP_Demo(void);
	unsigned char App_Demo_BTE(void);
	unsigned char App_Demo_Alpha_Blending(void);
	unsigned char App_Demo_slide_frame_buffer(void);
	void Show_Temperature(int val);
	void Show_Progress1(int val);
	void Show_Progress2(int val);
	void Button_ON_OFF(int val);
	void Show_Text(int index);
	void TEST_DoubleTriangle(unsigned int x,unsigned int y,unsigned int h,unsigned int h1,unsigned int l,unsigned int a,unsigned int color1,unsigned int color2);
	void Pointer_Show(unsigned int a);
	void Controller_Demo(void);
	unsigned char Cartoon_Show(void);
	void Main_GUI(void);
	unsigned char Select_Function(void);
};
extern LT768Demo LT768_Demo;
#endif
